<?php
// DEV ROUTER for php -S local testing only.
// Emulates the Apache .htaccess rewrite: real files are served
// directly, everything else goes to index.php.
// NOT needed on Apache - safe to delete.

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if ($uri !== '/' && is_file(__DIR__ . $uri)) {
    return false; // serve the real file directly (like RewriteCond !-f)
}

chdir(__DIR__);
require __DIR__ . '/index.php';
