<?php
/**
 * ===========================
 * ENTITY PANEL AUTH (LOCAL)
 * ===========================
 * - NO remote API (jsonbin.io removed): panel login credentials
 *   are defined LOCALLY in KarmaEntity/config/config.php
 *     panel_username / panel_password
 * - Same signed cookie (entity_auth) as before, fully compatible
 *   with auth/entityGuard.php (the secret below must stay the same)
 * - All panel login attempts (success + failed) are saved to
 *   logs/entity_login_logs.txt
 */

header("Content-Type: application/json");

// local config
$config = require __DIR__ . '/../../config/config.php';

$PANEL_USER = (string)($config['panel_username'] ?? 'admin');
$PANEL_PASS = (string)($config['panel_password'] ?? 'admin123');

// must match the secret in auth/entityGuard.php
$SECRET = "Entity-2026!";

$logTxt = $config['log_to_txt'] ?? true;

$data = json_decode(file_get_contents("php://input"), true);
$data = is_array($data) ? $data : [];

$user = (string)($data["username"] ?? "");
$pass = (string)($data["password"] ?? "");

$valid = ($user !== "" && $pass !== "" && $user === $PANEL_USER && $pass === $PANEL_PASS);

// ---- log every panel login attempt ----
if ($logTxt) {
    require_once __DIR__ . '/../../../core/LoginLogger.php';

    EntityLogLogin('PANEL LOGIN', [
        'Username' => $user !== '' ? $user : '(empty)',
        'Result'   => $valid ? 'SUCCESS' : 'FAILED',
    ]);
}

if ($valid) {
    $payload   = "auth|" . time();
    $signature = hash_hmac("sha256", $payload, $SECRET);
    $token     = base64_encode($payload . "|" . $signature);

    setcookie("entity_auth", $token, [
        "expires"  => time() + 3600,
        "path"     => "/",
        "httponly" => true,
        "secure"   => isset($_SERVER["HTTPS"]),
        "samesite" => "Strict"
    ]);

    echo json_encode(["success" => true]);
    exit;
}

http_response_code(401);
echo json_encode([
    "success" => false,
    "message" => "Invalid username or password"
]);
