<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes"
/>
<link rel="stylesheet" href="/public/assets/css/entity-styles.css?v=<?= time() ?>">
<link rel="shortcut icon" href="/public/assets/img/mic.ico">
<link rel="apple-touch-icon" sizes="57x57" href="/public/assets/img/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/public/assets/img/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="76x76" href="/public/assets/img/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/public/assets/img/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/public/assets/img/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/public/assets/img/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/public/assets/img/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/public/assets/img/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/public/assets/img/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/public/assets/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/public/assets/img/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/public/assets/img/favicon-16x16.png">
<link rel="manifest" href="/public/assets/img/manifest.json">