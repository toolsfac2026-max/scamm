<?php require __DIR__ . '/../../core/EntityVariables.php'; ?>
<html
	lang="en-us"
	class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember a-ember-modern-display a-ember-modern-text"
	data-19ax5a9jf="dingo"
	data-aui-build-date="3.25.9-2025-11-29"
	data-useragent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
	data-platform="Win32"
>
	<head>
	<body
		class="a-m-us a-aui_72554-c a-aui_killswitch_csa_logger_372963-t1 a-aui_template_weblab_cache_333406-c a-bw_aui_cxc_alert_measurement_1074111-c a-bw_aui_stepper_enable_strategies_1_1330429-t1 a-meter-animate"
	>
		<div id="a-page">
			<header
				id="navbar-main"
				class="nav-opt-sprite nav-flex nav-locale-us nav-lang-en nav-ssl nav-unrec nav-progressive-attribute"
			>
				<div
					id="navbar"
					cel_widget_id="Navigation-desktop-navbar"
					role="navigation"
					class="nav-sprite-v1 celwidget nav-bluebeacon nav-a11y-t1 bold-focus-hover layout2 nav-flex layout3 layout3-alt nav-packard-glow hamburger nav-progressive-attribute"
					aria-label="Primary"
					data-csa-c-id="5k9o91-rj1q11-aalsv1-cl872w"
					data-cel-widget="Navigation-desktop-navbar"
				>
					<div id="nav-belt" style="top: 0px; width: 100%" class="">
						<div class="nav-left">
							<div id="nav-logo">
								<a
									href="#"
									id="nav-logo-sprites"
									class="nav-logo-link nav-progressive-attribute"
									aria-label="Amazon"
									lang="en"
								>
									<span class="nav-sprite nav-logo-base"></span>
									<span
										id="logo-ext"
										class="nav-sprite nav-logo-ext nav-progressive-content"
									></span>
									<span class="nav-logo-locale">.us</span>
								</a>
							</div>

							<div id="nav-global-location-slot">
								<span
									id="nav-global-location-data-modal-action"
									class="a-declarative nav-progressive-attribute"
									data-a-modal='{"width":375, "closeButton":"true","popoverLabel":"Choose your location", "ajaxHeaders":{"anti-csrftoken-a2z":"hBB0FpmJHEYYiCF6aBMQx7PJ9ZJ9d+YzMfwpxRkKHPs1AAAAAGk3oW0AAAAB"}, "name":"glow-modal", "url":"/portal-migration/hz/glow/get-rendered-address-selections?deviceType=desktop&amp;pageType=Gateway&amp;storeContext=NoStoreName&amp;actionSource=desktop-modal", "footer":"&lt;span class=\"a-declarative\" data-action=\"a-popover-close\" data-a-popover-close=\"{}\"&gt;&lt;span class=\"a-button a-button-primary\"&gt;&lt;span class=\"a-button-inner\"&gt;&lt;button name=\"glowDoneButton\" class=\"a-button-text\" type=\"button\"&gt;Done&lt;/button&gt;&lt;/span&gt;&lt;/span&gt;&lt;/span&gt;","header":"Choose your location"}'
									data-action="a-modal"
								>
									<a
										id="nav-global-location-popover-link"
										role="button"
										tabindex="0"
										class="nav-a nav-a-2 a-popover-trigger a-declarative nav-progressive-attribute"
										href="#"
									>
										<div
											class="nav-sprite nav-progressive-attribute"
											id="nav-packard-glow-loc-icon"
										></div>
										<div id="glow-ingress-block">
											<span
												class="nav-line-1 nav-progressive-content"
												id="glow-ingress-line1"
											>
												Delivering to
											</span>
											<span
												class="nav-line-2 nav-progressive-content"
												id="glow-ingress-line2"
											>
												<?php echo $country ? $country : "Select your country"; ?>
											</span>
										</div>
									</a>
								</span>
							</div>
						</div>
						<div class="nav-fill" id="nav-fill-search">
							<div id="nav-search" style="left: 0px; right: 0px">
								<div id="nav-bar-left"></div>
								<form
									id="nav-search-bar-form"
									accept-charset="utf-8"
									action="#"
									class="nav-searchbar nav-progressive-attribute"
								>
									<div class="nav-left">
										<div id="nav-search-dropdown-card">
											<div class="nav-search-scope nav-sprite">
												<div
													class="nav-search-facade"
													data-value="search-alias=aps"
												>
													<span
														id="nav-search-label-id"
														class="nav-search-label nav-progressive-content"
														style="width: auto"
														>All</span
													>
													<i class="nav-icon"></i>
												</div>
											</div>
										</div>
									</div>
									<div class="nav-fill">
										<div class="nav-search-field">
											<label for="twotabsearchtextbox" style="display: none"
												>Search Amazon</label
											>
											<input
												type="text"
												id="twotabsearchtextbox"
												value=""
												name="field-keywords"
												autocomplete="off"
												placeholder="Search Amazon"
												class="nav-input nav-progressive-attribute"
												dir="auto"
												tabindex="0"
												aria-label="Search Amazon"
												role="searchbox"
												aria-autocomplete="list"
												aria-controls="sac-autocomplete-results-container"
												aria-expanded="false"
												aria-haspopup="grid"
												spellcheck="false"
											/>
										</div>
										<div id="nav-iss-attach"></div>
									</div>
									<div class="nav-right">
										<div class="nav-search-submit nav-sprite">
											<span
												id="nav-search-submit-text"
												class="nav-search-submit-text nav-sprite nav-progressive-attribute"
												aria-label="Go"
											>
												<input
													id="nav-search-submit-button"
													type="submit"
													class="nav-input nav-progressive-attribute"
													value="Go"
													tabindex="0"
												/>
											</span>
										</div>
									</div>
								</form>
							</div>
						</div>
						<div class="nav-right">
							<div id="nav-tools" class="layoutToolbarPadding">
								<div class="nav-div" id="icp-nav-flyout">
									<a
										href="#"
										class="nav-a nav-a-2 icp-link-style-2"
										aria-label="Choose a language for shopping in Amazon United States. The current selection is English (EN).
"
									>
										<span class="icp-nav-link-inner">
											<span class="nav-line-1"> </span>
											<span class="nav-line-2">
												<span
													class="icp-nav-flag icp-nav-flag-us icp-nav-flag-lop"
													role="img"
													aria-label="United States"
												></span>
												<div>EN</div>
											</span>
										</span>
									</a>
									<button
										class="nav-flyout-button nav-icon nav-arrow"
										aria-label="Expand to Change Language or Country"
										tabindex="0"
										style="visibility: visible"
									></button>
								</div>

								<div class="nav-div" id="nav-link-accountList">
									<a
										href="#"
										class="nav-a nav-a-2 nav-progressive-attribute"
										data-nav-ref="nav_ya_signin"
										data-nav-role="signin"
										data-ux-jq-mouseenter="true"
										tabindex="0"
										data-csa-c-type="link"
										data-csa-c-slot-id="nav-link-accountList"
										data-csa-c-content-id="nav_ya_signin"
										aria-controls="nav-flyout-accountList"
										data-csa-c-id="h4tysi-9eu81m-tqmsq7-800tda"
									>
										<div class="nav-line-1-container">
											<span
												id="nav-link-accountList-nav-line-1"
												class="nav-line-1 nav-progressive-content"
												>Hello, 
                                                    <?php 
                                                        if (isset($_SESSION["entity_email"])) {
                                                            $name = explode('@', $_SESSION["entity_email"])[0];
                                                            echo ucfirst(trim($name));
                                                        } else {
                                                            echo "Sign in";
                                                        }
                                                    ?>
                                            </span>
										</div>
                                        <div class="font-karma-bold">
										    <span class="nav-line-2">Account &amp; Lists </span>
                                        </div>
									</a>
									<button
										class="nav-flyout-button nav-icon nav-arrow"
										aria-label="Expand Account and Lists"
										tabindex="0"
										style="visibility: visible"
									></button>
								</div>

								<a
									href="#"
									class="nav-a nav-a-2 nav-progressive-attribute"
									id="nav-orders"
									tabindex="0"
								>
									<span class="nav-line-1">Returns</span>
                                    
                                    <div class="font-karma-bold">
                                        <span class="nav-line-2"
                                            >&amp; Orders<span class="nav-icon nav-arrow"></span
                                        ></span>
                                    </div>
								</a>

								<a
									href="#"
									aria-label="0 items in cart"
									class="nav-a nav-a-2 nav-progressive-attribute"
									id="nav-cart"
								>
									<div id="nav-cart-count-container">
										<span
											id="nav-cart-count"
											aria-hidden="true"
											class="nav-cart-count nav-cart-0 nav-progressive-attribute nav-progressive-content"
											>0</span
										>
										<span class="nav-cart-icon nav-sprite"></span>
									</div>
									<div
										id="nav-cart-text-container"
										class="nav-progressive-attribute"
									>
										<span aria-hidden="true" class="nav-line-1"> </span>
                                        
                                        <div class="font-karma-bold">
                                            <span aria-hidden="true" class="nav-line-2">
                                                Cart
                                                <span class="nav-icon nav-arrow"></span>
                                            </span>
                                        </div>
									</div>
								</a>
							</div>
						</div>
					</div>
					<div id="nav-belt-search" class="nav-fill"></div>
					<div id="nav-main" class="nav-sprite">
						<div class="nav-left">
							<a
								href="javascript: void(0)"
								id="nav-hamburger-menu"
								role="button"
								aria-label="Open All Categories Menu"
								aria-expanded="false"
								data-csa-c-type="widget"
								data-csa-c-slot-id="HamburgerMenuDesktop"
								data-csa-c-interaction-events="click"
								data-csa-c-id="pp9ljs-utx6jk-lwfqbg-pkh057"
							>
								<i class="hm-icon nav-sprite"></i>
								<span class="hm-icon-label">All</span>
							</a>

							<div id="nav-shop"></div>
						</div>
						<div class="nav-fill">
							<div id="nav-xshop-container">
								<div id="nav-xshop" class="nav-progressive-content">
									<ul class="nav-ul">
										<li class="nav-li">
											<div class="nav-div font-karma-bold">
												<a
													id="nav-holiday"
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_0"
													data-csa-c-content-id="nav_cs_events_holi_shop_desktop"
													data-csa-c-id="1ljd1t-si6e0w-mhkcyi-7vqenc"
													>Holiday Shop</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_1"
													data-csa-c-content-id="nav_cs_hul_disb"
													data-csa-c-id="mk1sfr-e34agv-o2g416-wtklcz"
													>Amazon Haul</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal" id="nav_link_allhealthingress">
												<a
													href="#"
													class="nav-a"
													data-ux-jq-mouseenter="true"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_link_allhealthingress"
													data-csa-c-content-id="nav_cs_all_health_ingress_onem_h"
													data-csa-c-id="rchfuu-23pcrd-q6ii8-yfmyur"
													><span>Medical Care</span>
												</a>
												<button
													aria-expanded="false"
													class="nav-flyout-button nav-icon nav-arrow"
													aria-label="Medical Care Details"
													tabindex="0"
													style="visibility: visible"
												></button>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_3"
													data-csa-c-content-id="nav_cs_luxury_disc"
													data-csa-c-id="71x54i-whi2hu-cbbp1c-26ft50"
													>Luxury</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_4"
													data-csa-c-content-id="nav_cs_bestsellers"
													data-csa-c-id="vkadze-kufwcn-u9xglr-920d10"
													>Best Sellers</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_5"
													data-csa-c-content-id="nav_cs_amazonbasics"
													data-csa-c-id="dat1kt-env1x2-n5fwj5-vix68j"
													>Amazon Basics</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_6"
													data-csa-c-content-id="nav_cs_gb"
													data-csa-c-id="e0reu8-c7bmsv-c7zcdo-x5dqle"
													>Today's Deals</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_7"
													data-csa-c-content-id="nav_cs_books"
													data-csa-c-id="vrmp8x-24j116-id9a41-rn39h1"
													>Books</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_8"
													data-csa-c-content-id="nav_cs_newreleases"
													data-csa-c-id="jogwy6-2tye8x-emegvk-ms44pm"
													>New Releases</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal">
												<a
													href="#"
													class="nav-a"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_cs_9"
													data-csa-c-content-id="nav_cs_registry"
													data-csa-c-id="bj6uld-fd3jae-no2aom-o99sa4"
													>Registry</a
												>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal" id="nav-link-groceries">
												<a
													href="#"
													class="nav-a"
													data-ux-jq-mouseenter="true"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav-link-groceries"
													data-csa-c-content-id="nav_cs_groceries"
													data-csa-c-id="pxb8zl-cgp0ok-il23yw-p05oyf"
													><span>Groceries</span>
												</a>
												<button
													aria-expanded="false"
													class="nav-flyout-button nav-icon nav-arrow"
													aria-label="Groceries Details"
													tabindex="0"
													style="visibility: visible"
												></button>
											</div>
										</li>

										<li class="nav-li">
											<div class="nav-div font-karma-normal" id="nav_link_gift_cards">
												<a
													href="#"
													class="nav-a"
													data-ux-jq-mouseenter="true"
													tabindex="0"
													data-csa-c-type="link"
													data-csa-c-slot-id="nav_link_gift_cards"
													data-csa-c-content-id="nav_cs_gc"
													data-csa-c-id="2qlr1g-7axmcs-z4i0x1-1q23lz"
													><span>Gift Cards</span>
												</a>
												<button
													aria-expanded="false"
													class="nav-flyout-button nav-icon nav-arrow"
													aria-label="Gift Cards Details"
													tabindex="0"
													style="visibility: visible"
												></button>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="nav-right">
							<div id="nav-swmslot">
								<div
									class="nav-swm-countdown-wrapper"
									style="height: 39px; width: 350px"
									data-cel-widget="nav_sitewide_msg"
								>
									<div
										id="hveNavSwmCountdownWidget-526cac18-3e04-47f2-9f4d-d1becc5a60ae"
										style="height: 100%; width: 100%"
									>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
	</body>
</html>
