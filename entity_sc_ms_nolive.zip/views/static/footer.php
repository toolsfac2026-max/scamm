<div
	class="navLeftFooter nav-sprite-v1"
	id="navFooter"
	style="min-height: 60.9vh"
>
	<a id="navBackToTop" aria-label="Back to top" role="button">
		<div class="navFooterBackToTop">
			<span class="navFooterBackToTopText"> Back to top </span>
		</div>
	</a>

	<div class="navFooterVerticalColumn navAccessibility" role="presentation">
		<div class="navFooterVerticalRow navAccessibility">
			<div class="navFooterLinkCol navAccessibility">
				<div class="navFooterColHead" role="heading" aria-level="6">
					Get to Know Us
				</div>
				<ul>
					<li class="nav_first">
						<a href="#" class="nav_a">Careers</a>
					</li>
					<li>
						<a href="#" class="nav_a">Blog</a>
					</li>
					<li>
						<a href="#" class="nav_a">About Amazon</a>
					</li>
					<li>
						<a href="#" class="nav_a">Investor Relations</a>
					</li>
					<li>
						<a href="#" class="nav_a">Amazon Devices</a>
					</li>
					<li class="nav_last">
						<a href="#" class="nav_a">Amazon Science</a>
					</li>
				</ul>
			</div>
			<div class="navFooterColSpacerInner navAccessibility"></div>
			<div class="navFooterLinkCol navAccessibility">
				<div class="navFooterColHead" role="heading" aria-level="6">
					Make Money with Us
				</div>
				<ul>
					<li class="nav_first">
						<a href="#" class="nav_a">Sell products on Amazon</a>
					</li>
					<li>
						<a href="#" class="nav_a">Sell on Amazon Business</a>
					</li>
					<li>
						<a href="#" class="nav_a">Sell apps on Amazon</a>
					</li>
					<li>
						<a href="#" class="nav_a">Become an Affiliate</a>
					</li>
					<li>
						<a href="#" class="nav_a">Advertise Your Products</a>
					</li>
					<li>
						<a href="#" class="nav_a">Self-Publish with Us</a>
					</li>
					<li>
						<a href="#" class="nav_a">Host an Amazon Hub</a>
					</li>
					<li class="nav_last nav_a_carat">
						<span class="nav_a_carat" aria-hidden="true">›</span
						><a href="#" class="nav_a">See More Make Money with Us</a>
					</li>
				</ul>
			</div>
			<div class="navFooterColSpacerInner navAccessibility"></div>
			<div class="navFooterLinkCol navAccessibility">
				<div class="navFooterColHead" role="heading" aria-level="6">
					Amazon Payment Products
				</div>
				<ul>
					<li class="nav_first">
						<a href="#" class="nav_a">Amazon Business Card</a>
					</li>
					<li>
						<a href="#" class="nav_a">Shop with Points</a>
					</li>
					<li>
						<a href="#" class="nav_a">Reload Your Balance</a>
					</li>
					<li class="nav_last">
						<a href="#" class="nav_a">Amazon Currency Converter</a>
					</li>
				</ul>
			</div>
			<div class="navFooterColSpacerInner navAccessibility"></div>
			<div class="navFooterLinkCol navAccessibility">
				<div class="navFooterColHead" role="heading" aria-level="6">
					Let Us Help You
				</div>
				<ul>
					<li class="nav_first">
						<a href="#" class="nav_a">Amazon and COVID-19</a>
					</li>
					<li>
						<a href="#" class="nav_a">Your Account</a>
					</li>
					<li>
						<a href="#" class="nav_a">Your Orders</a>
					</li>
					<li>
						<a href="#" class="nav_a">Shipping Rates &amp; Policies</a>
					</li>
					<li>
						<a href="#" class="nav_a">Returns &amp; Replacements</a>
					</li>
					<li>
						<a href="#" class="nav_a">Manage Your Content and Devices</a>
					</li>
					<li class="nav_last">
						<a href="#" class="nav_a">Help</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<div class="nav-footer-line"></div>

	<div class="navFooterLine navFooterLinkLine navFooterPadItemLine">
		<span>
			<div class="navFooterLine navFooterLogoLine">
				<a aria-label="Amazon US Home" lang="en" href="#">
					<div class="nav-logo-base nav-sprite"></div>
				</a>
			</div>
		</span>

		<span class="icp-container-desktop"
			><div class="navFooterLine">
				<style type="text/css">
					#icp-touch-link-language {
						display: none;
					}
				</style>

				<div class="icp-button" id="icp-touch-link-language">
					<a
						href="#"
						class="icp-language-link"
						aria-label="Choose a language for shopping. Current selection is English. "
					>
						<div class="icp-nav-globe-img-2 icp-button-globe-2"></div>
						<span class="icp-color-base">English</span>
					</a>
					<button
						class="nav-arrow icp-up-down-arrow"
						aria-controls="nav-flyout-icp-footer-flyout"
						aria-label="Expand to Change Language or Country"
					></button>
				</div>

				<style type="text/css">
					#icp-touch-link-cop {
						display: none;
					}
				</style>

                <?php if (itsUs($visitorInfo)) { ?>
                    <a href="#" class="icp-button" id="icp-touch-link-cop">
                        <span class="icp-currency-symbol">$</span
                        ><span class="icp-color-base">USD - U.S. Dollar</span>
                    </a>

                    <style type="text/css">
                        #icp-touch-link-country {
                            display: none;
                        }
                    </style>
                    <a
                        href="#"
                        role="button"
                        aria-label="Choose a country/region for shopping. The current selection is United States."
                        class="icp-button"
                        id="icp-touch-link-country"
                    >
                        <span class="icp-flag-3 icp-flag-3-us"></span
                        ><span class="icp-color-base">United States</span>
                    </a>
                <?php } ?>
			</div></span
		>
	</div>

	<div
		class="navFooterLine navFooterLinkLine navFooterDescLine"
		role="navigation"
		aria-label="More on Amazon"
	>
		<div
			class="navFooterMoreOnAmazon navFooterMoreOnAmazonWrapper"
			aria-label="More on Amazon"
		>
			<ul>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Amazon Music</h5>
						<span class="navFooterDescText"
							>Stream millions<br />of songs</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Amazon Ads</h5>
						<span class="navFooterDescText"
							>Reach customers<br />wherever they<br />spend their time</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">6pm</h5>
						<span class="navFooterDescText"
							>Score deals<br />on fashion brands</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">AbeBooks</h5>
						<span class="navFooterDescText"
							>Books, art<br />&amp; collectibles</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">ACX</h5>
						<span class="navFooterDescText"
							>Audiobook Publishing<br />Made Easy</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Sell on Amazon</h5>
						<span class="navFooterDescText">Start a Selling Account</span></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Veeqo</h5>
						<span class="navFooterDescText"
							>Shipping Software<br />Inventory Management</span
						></a
					>
				</li>
			</ul>

			<ul>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Amazon Business</h5>
						<span class="navFooterDescText"
							>Everything For<br />Your Business</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">AmazonGlobal</h5>
						<span class="navFooterDescText"
							>Ship Orders<br />Internationally</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Amazon Web Services</h5>
						<span class="navFooterDescText"
							>Scalable Cloud<br />Computing Services</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Audible</h5>
						<span class="navFooterDescText"
							>Listen to Books &amp; Original<br />Audio Performances</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Box Office Mojo</h5>
						<span class="navFooterDescText"
							>Find Movie<br />Box Office Data</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Goodreads</h5>
						<span class="navFooterDescText"
							>Book reviews<br />&amp; recommendations</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">IMDb</h5>
						<span class="navFooterDescText"
							>Movies, TV<br />&amp; Celebrities</span
						></a
					>
				</li>
			</ul>

			<ul>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">IMDbPro</h5>
						<span class="navFooterDescText"
							>Get Info Entertainment<br />Professionals Need</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Kindle Direct Publishing</h5>
						<span class="navFooterDescText"
							>Indie Digital &amp; Print Publishing<br />Made Easy
						</span></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Prime Video Direct</h5>
						<span class="navFooterDescText"
							>Video Distribution<br />Made Easy</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Shopbop</h5>
						<span class="navFooterDescText"
							>Designer<br />Fashion Brands</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Woot!</h5>
						<span class="navFooterDescText"
							>Deals and <br />Shenanigans</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Zappos</h5>
						<span class="navFooterDescText">Shoes &amp;<br />Clothing</span></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Ring</h5>
						<span class="navFooterDescText"
							>Smart Home<br />Security Systems
						</span></a
					>
				</li>
			</ul>

			<ul>
				<li class="navFooterDescItem" aria-hidden="true">&nbsp;</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">eero WiFi</h5>
						<span class="navFooterDescText"
							>Stream 4K Video<br />in Every Room</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Blink</h5>
						<span class="navFooterDescText"
							>Smart Security<br />for Every Home
						</span></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">Neighbors App</h5>
						<span class="navFooterDescText">
							Real-Time Crime<br />&amp; Safety Alerts
						</span></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">
							Amazon Subscription Boxes
						</h5>
						<span class="navFooterDescText"
							>Top subscription boxes – right to your door</span
						></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem">
					<a href="#" class="nav_a"
						><h5 class="navFooterDescItem_heading">PillPack</h5>
						<span class="navFooterDescText">Pharmacy Simplified</span></a
					>
				</li>
				<li
					class="navFooterDescSpacer"
					aria-hidden="true"
					style="width: 3%"
				></li>
				<li class="navFooterDescItem" aria-hidden="true">&nbsp;</li>
			</ul>
		</div>
	</div>

	<div
		class="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright"
	>
		<ul>
			<li class="nav_first">
				<a href="#" id="" class="nav_a">Conditions of Use</a>
			</li>
			<li>
				<a href="#" id="" class="nav_a">Privacy Notice</a>
			</li>
			<li>
				<a href="#" id="" class="nav_a"
					>Consumer Health Data Privacy Disclosure</a
				>
			</li>
			<li>
				<a href="#" id="" class="nav_a">Your Ads Privacy Choices</a>
			</li>
			<li class="nav_last">
				<span id="nav-icon-ccba" class="nav-sprite"></span>
			</li>
		</ul>
		<span>&copy; 1996-2026, Amazon.com, Inc. or its affiliates</span>
	</div>
</div>
