<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/public/css/karma-styles.css?v=<?= time() ?>">
<link rel="shortcut icon" href="/public/images/favicon.ico">
<link rel="apple-touch-icon" sizes="57x57" href="/public/images/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/public/images/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="76x76" href="/public/images/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/public/images/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/public/images/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/public/images/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/public/images/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/public/images/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/public/images/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/public/images/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/public/images/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/public/images/favicon-16x16.png">
<link rel="manifest" href="/public/images/manifest.json">