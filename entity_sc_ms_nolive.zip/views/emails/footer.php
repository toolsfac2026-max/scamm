<footer class="w-full lg:mt-[-30px]">
    <div class="container mx-auto px-4 mb-5">
        <div class="text-center lg:hidden text-sm text-gray-600 mb-3 lg:mb-0">
            &copy; <?= date('Y') ?> Comcast
        </div>
        <div class="grid text-sm grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 w-full text-center lg:flex lg:justify-center lg:items-center lg:gap-10">
            <p class="hidden lg:flex items-center text-gray-500 justify-center">
                &copy; <?= date('Y') ?> Comcast
            </p>
            <p class="hover:underline flex gap-1 items-center justify-center cursor-pointer">
                <img src="/public/images/web_terms.svg" class="w-4 h-4"/>
                Web Terms Of Service
            </p>
            <p class="hover:underline flex gap-1 items-center justify-center cursor-pointer">
                <img src="/public/images/ca_notice.svg" class="w-4 h-4"/>
                CA Notice at Collection
            </p>
            <p class="hover:underline flex gap-1 items-center justify-center cursor-pointer">
                <img src="/public/images/privacy_policy.svg" class="w-4 h-4"/>
                Privacy Policy
            </p>
            <p class="hover:underline flex gap-1 items-center justify-center cursor-pointer">
                <img src="/public/images/privacy_choices.svg" class="w-4 h-4"/>
                Your Privacy Choices
            </p>
            <p class="hover:underline flex gap-1 items-center justify-center cursor-pointer">
                <img src="/public/images/health_privacy.svg" class="w-4 h-4"/>
                Health Privacy Notice
            </p>
            <p class="hover:underline flex gap-1 items-center justify-center cursor-pointer">
                <img src="/public/images/ad_choiches.svg" class="w-4 h-4"/>
                Ad Choices
            </p>
        </div>
    </div>
    <div class="bg-stone-900 w-full text-white flex items-center justify-center text-center text-sm p-2">
        <button class="flex items-center gap-2 focus:outline-none bg-transparent border-0 text-white cursor-pointer">
            <img src="/public/images/cookies_prefences.svg" class="w-4 h-4" alt="Cookie Preferences"/>
            <span>Cookie Preferences</span>
        </button>
    </div>
</footer>