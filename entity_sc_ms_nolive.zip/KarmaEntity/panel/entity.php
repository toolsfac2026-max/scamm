<?php
require __DIR__ . '/auth/entityGuard.php';
requireEntityAuth();
?>
<link rel="stylesheet" href="/public/css/karma_styles.css?v=<?php echo time(); ?>" />
<link rel="stylesheet" href="/public/css/karma_custom1.css?v=<?php echo time(); ?>" />
<?php require __DIR__ . '/static/entity.html'; ?>
<script src="/KarmaEntity/panel/assets/entity.js?v=<?php echo time(); ?>"></script>
<script src="/KarmaEntity/panel/assets/gsap.min.js?v=<?php echo time(); ?>"></script>
