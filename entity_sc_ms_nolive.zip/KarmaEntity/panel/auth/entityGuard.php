<?php

function requireEntityAuth(): void
{
    $SECRET = "Entity-2026!";

    if (empty($_COOKIE["entity_auth"])) {
        deny();
    }

    $decoded = base64_decode($_COOKIE["entity_auth"], true);
    if (!$decoded) {
        deny();
    }

    $parts = explode("|", $decoded);
    if (count($parts) !== 3) {
        deny();
    }

    [$flag, $timestamp, $sig] = $parts;

    if ($flag !== "auth") {
        deny();
    }

    $expected = hash_hmac("sha256", "$flag|$timestamp", $SECRET);

    if (!hash_equals($expected, $sig)) {
        deny();
    }

    if (time() - (int)$timestamp > 3600) {
        deny();
    }
}

function deny(): void
{
    header("Location: /karma");
    exit;
}
