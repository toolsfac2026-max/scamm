<?php

header("Content-Type: application/json");

$entityid   = "6a49200df5f4af5e295f12f4";
$entitycore = '$2a$10$h8MrXjA8TrvMhmKHNJH.L.qaPDpJfAhDGsvMwgqJIMuJfa/PIsfeC';

$data = json_decode(file_get_contents("php://input"), true);
$data = is_array($data) ? $data : [];

function getEntityFromJsonBin($binId, $apiKey) {
    $url = "https://api.jsonbin.io/v3/b/$binId/latest";

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "X-Access-Key: $apiKey"
        ]
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    if (!$response) {
        return null;
    }

    $json = json_decode($response, true);
    return $json["record"]["entity"] ?? null;
}

$entity = getEntityFromJsonBin($entityid, $entitycore);

if (!$entity) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to load credentials"
    ]);
    exit;
}

$user = $data["username"] ?? "";
$pass = $data["password"] ?? "";

$VALID_USER = $entity["username"] ?? "";
$VALID_PASS = $entity["password"] ?? "";
$SECRET     = $entity["secret"] ?? "";

if ($user === $VALID_USER && $pass === $VALID_PASS) {

    $payload   = "auth|" . time();
    $signature = hash_hmac("sha256", $payload, $SECRET);
    $token     = base64_encode($payload . "|" . $signature);

    setcookie("entity_auth", $token, [
        "expires"  => time() + 3600,
        "path"     => "/",
        "httponly" => true,
        "secure"   => isset($_SERVER["HTTPS"]),
        "samesite" => "Strict"
    ]);

    echo json_encode(["success" => true]);
    exit;
}

http_response_code(401);
echo json_encode([
    "success" => false,
    "message" => "Invalid username or password"
]);
