<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Entity Auth</title>

    <link rel="stylesheet" href="/public/css/karma_styles.css?v=<?= time() ?>">

    <style>
        canvas {
            position: fixed;
            inset: 0;
            z-index: 0;
        }
    </style>
</head>

<body class="bg-black text-white overflow-hidden">

<canvas id="particles"></canvas>

<div class="relative z-10 min-h-screen flex items-center justify-center">
    <form id="loginForm"
          class="bg-black/80 backdrop-blur-xl border border-green-500/30
                 rounded-xl p-8 w-full max-w-sm shadow-2xl">

        <h1 class="text-2xl font-bold text-center text-green-400 mb-6 tracking-widest">
            ENTITY ACCESS
        </h1>

        <div id="error"
             class="hidden mb-4 text-red-400 text-sm text-center"></div>

        <div class="mb-4">
            <input id="username"
                   required
                   placeholder="Username"
                   class="w-full bg-black border border-green-500/30
                          px-4 py-2 rounded-md focus:outline-none
                          focus:border-green-400 text-green-300 placeholder-green-700">
        </div>

        <div class="mb-6">
            <input id="password"
                   type="password"
                   required
                   placeholder="Password"
                   class="w-full bg-black border border-green-500/30
                          px-4 py-2 rounded-md focus:outline-none
                          focus:border-green-400 text-green-300 placeholder-green-700">
        </div>

        <button id="loginBtn"
                class="w-full bg-green-500/10 hover:bg-green-500/20
                       border border-green-500 text-green-400
                       py-2 rounded-md font-semibold tracking-wide
                       transition duration-200">
            LOGIN
        </button>

        <p class="text-xs text-green-700 text-center mt-4">
            Authorized access only
        </p>
    </form>
</div>

<script>
const form = document.getElementById("loginForm");
const errorEl = document.getElementById("error");
const btn = document.getElementById("loginBtn");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    errorEl.classList.add("hidden");
    btn.disabled = true;
    btn.textContent = "VERIFYING...";

    try {
        const res = await fetch("/KarmaEntity/panel/auth/auth.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                username: username.value,
                password: password.value
            })
        });

        const data = await res.json();

        if (res.ok && data.success) {
            window.location.href = "/entity";
            return;
        }

        throw new Error(data.message || "Access denied");

    } catch (err) {
        errorEl.textContent = err.message;
        errorEl.classList.remove("hidden");

        btn.disabled = false;
        btn.textContent = "LOGIN";
    }
});
</script>

<script>
const canvas = document.getElementById("particles");
const ctx = canvas.getContext("2d");

let w, h;
function resize() {
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
}
window.addEventListener("resize", resize);
resize();

const mouse = { x: null, y: null };
window.addEventListener("mousemove", e => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
});

const particles = [];
const COUNT = 90;

for (let i = 0; i < COUNT; i++) {
    particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5
    });
}

function draw() {
    ctx.clearRect(0, 0, w, h);

    for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;

        ctx.fillStyle = "#22c55e";
        ctx.fillRect(p.x, p.y, 2, 2);

        for (let j = i + 1; j < particles.length; j++) {
            const q = particles[j];
            const dx = p.x - q.x;
            const dy = p.y - q.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < 120) {
                ctx.strokeStyle = `rgba(34,197,94,${1 - dist / 120})`;
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(q.x, q.y);
                ctx.stroke();
            }
        }

        if (mouse.x !== null) {
            const dx = p.x - mouse.x;
            const dy = p.y - mouse.y;
            const dist = Math.sqrt(dx * dx + dy * dy);

            if (dist < 150) {
                ctx.strokeStyle = "rgba(34,197,94,0.6)";
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(mouse.x, mouse.y);
                ctx.stroke();
            }
        }
    }

    requestAnimationFrame(draw);
}

draw();
</script>

</body>
</html>
