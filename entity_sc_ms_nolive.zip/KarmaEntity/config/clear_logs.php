<?php
$logFile = __DIR__ . '/../../logs/entity_visitors.jsonl';

if (file_exists($logFile)) {
    file_put_contents($logFile, '');
}

http_response_code(200);
echo json_encode(['status' => 'success']);
?>
