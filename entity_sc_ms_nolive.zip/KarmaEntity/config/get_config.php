<?php
header('Content-Type: application/json');

$config = require __DIR__ . '/config.php';
echo json_encode($config);
