<?php
require_once __DIR__ . '/EntityFunctions.php';
$ip = $_SERVER['REMOTE_ADDR'] ?? '8.8.8.8';
if ($ip === '::1') {
    $ip = '103.156.164.111';
}
$karma_ip = $ip;
$random_entity_id = bin2hex(random_bytes(32));
$quote = KarmaGetRandomQuote();
$visitorInfo = EntityInfo($karma_ip);
$karma_user_agent = $_SERVER['HTTP_USER_AGENT'];

$userAgent = $visitorInfo['userAgent'];
$time      = $visitorInfo['time'];
$country   = $visitorInfo['visitorCountry'];
$city      = $visitorInfo['location']['city'];
$region    = $visitorInfo['location']['region'];
$latitude  = $visitorInfo['location']['latitude'];
$longitude = $visitorInfo['location']['longitude'];
$isp       = $visitorInfo['isp'];
$asn       = $visitorInfo['org'];
$timezone  = $visitorInfo['timezone'];
$device    = isMobile() ? 'mobile' : 'desktop';

?>
