<?php
namespace Core;

class EntityIpCheck {
    private $ipApiUrl = 'http://ip-api.com/json/';

    public function lookup($ip) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->ipApiUrl . urlencode($ip));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: application/json',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.5993.117 Safari/537.36'
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        if ($response === false) {
            return null;
        }

        $data = json_decode($response, true);

        if (!$data || $data['status'] !== 'success') {
            return null;
        }

        return $data;
    }

    public function log($message, $ipData, $logFile = null) {
        $logDir = dirname(__DIR__) . '/logs';
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
        }

        $logFile = $logFile ?? $logDir . '/ip_log.json';

        $logEntry = [
            'message' => $message,
            'timestamp' => date('c'),
            'data' => $ipData
        ];

        $existing = [];
        if (file_exists($logFile)) {
            $existing = json_decode(file_get_contents($logFile), true) ?? [];
        }

        $existing[] = $logEntry;

        file_put_contents($logFile, json_encode($existing, JSON_PRETTY_PRINT));
    }
}
?>