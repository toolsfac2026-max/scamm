<?php
/**
 * ===========================
 * ENTITY LIVE TRUE LOGIN
 * ===========================
 */

class HttpClient
{
    public static function get(string $url, array $headers = [], string $cookies = ''): string
    {
        return self::request('GET', $url, null, $headers, $cookies);
    }

    public static function post(string $url, array $data, array $headers = [], string $cookies = ''): string
    {
        return self::request('POST', $url, json_encode($data), $headers, $cookies);
    }

    private static function request(
        string $method,
        string $url,
        ?string $body,
        array $headers,
        string $cookies
    ): string {
        $ch = curl_init();

        $defaultHeaders = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/148.0.0.0 Safari/537.36',
            'Accept: */*',
        ];

        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => '',
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => array_merge($defaultHeaders, $headers),
            CURLOPT_COOKIE => $cookies,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }

        $response = curl_exec($ch);

        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException($error);
        }

        curl_close($ch);

        return $response;
    }
}

class MicrosoftAuth
{
    public function __construct(private string $cookies) {}

    public function fetchAuthorizePage(): string
    {
        return HttpClient::get(
            $this->buildAuthorizeUrl(),
            [
                'Referer: https://account.microsoft.com/'
            ],
            $this->cookies
        );
    }

    public function extractConfigValue(string $html, string $key): ?string
    {
        $patterns = [
            "/{$key}\s*:\s*\"([^\"]+)\"/i",
            "/\"{$key}\"\s*:\s*\"([^\"]+)\"/i",
            "/\$Config\s*=\s*\{.*?{$key}\s*:\s*\"([^\"]+)\"/is",
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $html, $m)) {
                return $m[1];
            }
        }

        return null;
    }

    public function getCredentialType(
        string $username,
        string $originalRequest,
        string $flowToken,
        string $canary,
        string $clientRequestId
    ): array {
        $url = "https://login.microsoftonline.com/common/GetCredentialType?mkt=en-US";

        $payload = [
            "username" => $username,
            "isOtherIdpSupported" => true,
            "checkPhones" => false,
            "isRemoteNGCSupported" => true,
            "isCookieBannerShown" => false,
            "isFidoSupported" => true,
            "originalRequest" => $originalRequest,
            "country" => "ID",
            "flowToken" => $flowToken,
            "isAccessPassSupported" => true,
            "isQrCodePinSupported" => true
        ];

        $response = HttpClient::post(
            $url,
            $payload,
            [
                "canary: $canary",
                "client-request-id: $clientRequestId",
                "Referer: https://account.microsoft.com/"
            ],
            $this->cookies
        );

        return [
            "success" => true,
            "response" => $response
        ];
    }

    private function buildAuthorizeUrl(): string
    {
        return 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?' . http_build_query([
            'scope' => 'service::account.microsoft.com::MBI_SSL openid profile offline_access',
            'response_type' => 'code',
            'client_id' => '81feaced-5ddd-41e7-8bef-3e20a2689bb7',
            'redirect_uri' => 'https://account.microsoft.com/auth/complete-signin-oauth',
            'client-request-id' => 'aff7c945-cc53-4785-99f7-caf4dd513edc',
            'x-client-SKU' => 'MSAL.Desktop',
            'x-client-Ver' => '4.79.2.0',
            'prompt' => 'login',
            'client_info' => 1,
            'msaoauth2' => 'true',
            'instance_aware' => 'true',
            'lc' => 1033,
        ]);
    }
}

class EntityTrueLogin
{
    public static function check(string $username): array
    {
        $cookies = 'x-ms-gateway-slice=estsfd; stsservicecookie=estsfd; AADSSO=NA|NoExtension; flight-msaoauth2=true; brcap=0; esctx-taWpqouK5o=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAAouIadyOqR4YKL0ngMlHrh-yF8K2cQc1mvJZo15XaBbmu-y1mW9HZEoEc6TvAYCJX6rI36_7ypUovQFIFqw4pOrJ7m726nwmxc2i3o2H5nwX2-gl9uC-wbnGI3_f6I2qSBD3S34UBNEdub065dItWWCAA; esctx-T7tMMphBNCY=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAA4SY5IlNzfXXAvMFPdOsc7ySpbE8C0NWiKwIvnZ_AyYbnk_IkUurm-R4YoCTEQsn20Su1IknYCVatHNEqc4V3P3vUALtWfj8Ej07CrCiJpSaxZOQFV0rdfssVmE4TYBF3lT1BdO80Zlo5ynWPoS30HiAA; esctx-75uJvBnAaY=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAAulkt0SoR_pz4UtryC3V9b1KqKhUwB_PcznsX6oeRi5UjGd8E_vdke8AIABlw3oKahpwF9pq5L9Z5WJTQhs7sJhXUat2tF6EyLlS0NfWfwMjKVvW7dMhYtlosT9SdTkgGw2tw11vJ_zJEpe-ZmH6TFCAA; esctx-Hhuul38AKs=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAArLpgc8p0g8jLwriWXVe2ymmVyahuskOBlYLpcOb9GiYkF7dNOeWSBfV0BQqVpGU_fvLrl-hJh7NObvJtiJx35ciUXryP0ymeKPX6lSheTtYFVLugYLimCFj0wcpquPpKV8cHh9vARDR8BE4nyfXosiAA; esctx-qyDBQwaKPPY=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAA6eOrKLeT4kBAl_rTDSErrm9ic3rxHwBEX-fIcId2ETh8kEHCt4R5TgLus3rN6gxGmvv5xOPr_KzjEAQgDpWGOMAYMpIa-vd7QiBlVcoR0KS43zYPPffXflTKMPfN69woAe3QVXgY_-ZSjClTlpzT0SAA; esctx-7HzfpHMuBVs=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAAwsC2nmjk_bExoip7VVJ-RjlCE987seoOEi1et_c_4X7hvXFWEwhFHo7DnwXrKDtWQPyNbUQKPfni6N9ozxd0xMUmFjce8NUYgjS-AI_o0gYxykKhPGn_0DKjYFniNTFf-vOorQE8KMcoINJ-V0C81yAA; esctx-f9wopcVZ6VY=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAAWUd6ZakWlkDoK11skCXUOeDPU8tawZPEg13Wnl38sNPD_oGuzD-swEdeezOLEOcyri2isSbtgS2JlqVh5Sz7TNmsuY6FElKjAqdwbbbUBDrDxNoevSFD-dOlAmz5MGxi8MEShuxq2VUXTKP9NmfmzyAA; ESTSWCTXFLOWTOKEN=BgABIQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzAQAAAAAAd9Wc4quBGzUgTzJoWCxmClaS-8Gk8hmzppZ_epsNRV0ynYfj2hOLb3DD4sieOBzM8NAZeg4ydBhJ7F9uRhpxWSXZ3PI57Vmo7XucxkDvj6_u91bjLIALfHPE3hSEEtdq60l2JF51R4qK3WziFHkYQnkPkwy-AuFszdO32JeL1IcN56OVAZjdFq28BPwWECCb14DTxnYQgp9WEJqnCjjboXohaPpZtfVAbg3aYxE84Z2x_RtkDy_89Pz89BAB8_Z77KDrZ8QmFFNbpv6eOXt3dw6ks6msBGAgEAm0kjiYO9s0HoAkTibFheKRd23qB4AWio2EJyYZgwJPccuc9itvBJEYpvn3vWpahroQH7pWHQThTpV00ZIhSEDZg0oc4z6BfHeqYjweCwjtyoY522HvkzHO2CcwJP6EtBeOVtSpUbnZOONFRReEE6XrN5uisojjw93uLdBPzZNQ99VLN7G_rZNhcVqnz-cwI7HJN5Ja-3DKCV7YXLVF4F2jATpaUiPsNT_FSFpUbE6ZHviYt_hbVhyBUcxMFFlAjIxzWJ6lF3Z9LcVGVnrz2xaNhLSb0Z0lreJmsZ-hyniCEd0Zl-X3BnD7Rreapdkau1EeKEoRTnefPCq09JfkeyqCqTbQkuuWQW853RPxHZkhIBT-eNnfXk4z_vLxTROvomiRCtKApKBFi1ouu0ik6Qawc4a4kRuTiQuZppBpeA-i84yPzCySXuo0KOA2cEQ3sVOmM8-dCnU8ag4R-4OV-O3ICyUCK8XEn0-YFhlVMZi6M4EVdPLYh4nDrAAfLMKyzotuZJ2bWRVYXoa8wtPADeHtrVkauBaskAZqDoGCqwNrWpbA20nfDtnOKcSULWYR4onq5IDwq9DdBrzcd6N0y0ZYQh1MdHvCBWe7Amo_XMZv5vSk35gIlRkJ9wQE2oNPEzSCEjbDbTXTQXaBCMZ6M4F8gUQ1KsiNL17CCJUJQ-qlNSqxWzZIa9EAbhuRElZTYFftNjtemtdcatniu0ZRJ4hFFPCe5rIWqSWjY-Zz9EZQx5OAmPMP12oJWDIbGMPNY9yoH7DuIx1DgziSzJcR4nnbGbn0qH1OLjNwuo39Qro70BfVdLnf9CAA; esctx-P1M4rEDBCHE=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAArF0iSenZ1IDKOeUMFPvqRWjOLWKVXep8l23mc4HoBcFc-wCI8dLsOkvjyLIDebfyeC8QrFqDVeVyvmOJuVuZUmYSIT5N3Q0tDWIoKnvYKpJ2GsL9Nf5VYcGouW8E-_s4wtTMixpoV8dRCEz4KQqLFSAA; esctx-2mv6KuOXpic=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAAw0HraxNvomolTHuixBcj46j3RXnZ17JbEj_E0qNszMOrN8YkjWNewZsUHQd-3adNJM2bbeJpfIbz-li3QwtfA7_KA5N9gf9lSa79q-NvQNFMEXT9b-hsfLAU3njnAIQMvXXkewg4LfcKuV6TsZzmGSAA; buid=1.AT4AMe_N-B6jSkuT5F9XHpElWu2s_oHdXedBi-8-IKJom7cAAAA-AA.AQABGgEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzAwAAAAAAad4kH6KB_nOwdzl_KjveqCQPdK3TB5zrPrwc1rXc_VzAXtJWPYlEsAQ5hpErKf-mPJtM4p7XD2Jlrw-PGbs6LDXgOgAvzea1HCygUYWfThYgAA; esctx=PAQABBwEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAARN_kGS5gawd4-SRZFtyv9v_ADMXFypYu680vqm8EnUJRoPhn7urliAX8TQW_t2iCWS3uzBxGVxqh34Wdrc0cR43uHs9AtRnPi_Vk1j8c0qbs0vyVEFGPNkBCLALyAaKM_ium1vwnTdpdNY5avBS2QRCPi2RpDehTnmq82eAvDkUgAA; esctx-nlZD4AcBiBE=AQABCQEAAAAdDD7nC9b5Q7JPd_okEQRFRXZvU3RzQXJ0aWZhY3RzDQAAAAAAs9LA84d65IfKHHEBs-j0FCNj4NUKl9MTSVeMTy7JugeB9I9S2ptBgWwMp-kAqx0VyX5ex9QUU64UiDO4Rc_acH3ECrK9HNZgDwBS9a_nskQTlGOIPv3vYimtTXAp3V9rIoSpKAvhOWgay-glQd8gfyAA; fpc=AgWtZlKfyZlHvDTvzApYheY9oINCAwAAAB5LtOEOAAAA';

        $auth = new MicrosoftAuth($cookies);
        $html = $auth->fetchAuthorizePage();
        $sft = $auth->extractConfigValue($html, 'sFT');
        $sctx = $auth->extractConfigValue($html, 'sCtx');

        $result = $auth->getCredentialType(
            $username,
            $sctx ?? '',
            $sft ?? '',
            $sctx ?? '',
            "aff7c945-cc53-4785-99f7-caf4dd513edc"
        );

        $data = json_decode($result['response'], true);

        $statusMap = [
            "IfExistsResult" => [
                5 => true,
                1 => false,
            ],
            "ThrottleStatus" => [
                0 => false,
                1 => true,
            ]
        ];

        $live = $statusMap["IfExistsResult"][$data["IfExistsResult"]] ?? "Unknown result";
        $throttled = $statusMap["ThrottleStatus"][$data["ThrottleStatus"]] ?? "Unknown status";

        return [
            'live' => $live,
            'throttled' => $throttled,
            'raw_data' => $data
        ];
    }
}

if (php_sapi_name() === 'cli') {

    if ($argc < 2) {
        echo "Usage:\n";
        echo "php {$argv[0]} email@example.com\n";
        exit(1);
    }

    $email = trim($argv[1]);

    try {
        $result = EntityTrueLogin::check($email);

        echo json_encode(
            $result,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
        ) . PHP_EOL;

    } catch (Throwable $e) {
        fwrite(STDERR, $e->getMessage() . PHP_EOL);
        exit(1);
    }
}