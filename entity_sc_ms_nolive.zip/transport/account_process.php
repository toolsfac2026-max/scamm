<?php
ini_set('display_errors', '0');
header("Content-Type: application/json");
require_once __DIR__ . "/../core/EntityVariables.php";
require_once __DIR__ . "/entity_true_login.php";

$data  = json_decode(file_get_contents("php://input"), true);
$email = $data["entity_email"] ?? null;

$_SESSION['entity_email'] = $email;

$result = EntityTrueLogin::check($email);
$live = $result['live'] ?? false;

if (!$live) {
    $_SESSION['dead'] = true;

    echo json_encode([
        'success' => false,
        'message' => 'User not found'
    ]);
    exit;
}

echo json_encode([
    "success"  => true,
    "redirect" => "loginAuth?entityId=$random_entity_id",
]);

exit;
?>